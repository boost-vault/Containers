/////////////////////////////////////////////////////////////////
//
//          Copyright Vadim Stadnik 2011.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//
/////////////////////////////////////////////////////////////////
//
//  See folder "container_bptree" for documentation
//
/////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include <boost/test/minimal.hpp>
#include "test_containers.hpp"


int test_main ( int , char * [ ] )
{
    const size_t    sz_test  = 128 ; // >= 8
    const size_t    num_dupl = 2   ; // >= 2

    test_bpt::adapters         ( sz_test , num_dupl ) ;
    test_bpt::adapters_idx     ( sz_test , num_dupl ) ;
    test_bpt::adapters_idx_acc ( sz_test , num_dupl ) ;

    return 0 ;
}
