///----------------------------------------------------------------------------
// FILE : Benchmark_set.cpp
//
// DESCRIPTION : This program is for to compare the speed of the std::set
//  with the cntree::set, and std::multiset with cntree::multiset
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 0
#include <iostream>
#include <stdlib.h>
#include <set>
#include <time.h>

#include <boost/countertree/set.hpp>

#define NELEM 1000000

using std::cout ;
using std::endl;


int A[NELEM];

void Prueba ( void ) ;
int  main ( void)
{   //---------------------- Variables----------------------------
    int i;

    //------------------------ Inicio -----------------------------
    cout<<"Insertion of "<< NELEM<<" elements\n\n\n" ;
    cout<<"Many elements , sorted elements\n";
    for ( i = 0 ; i < NELEM ; i ++) A[i] = NELEM +i ;
    Prueba() ;

    cout<<"Many elements , few repeated\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = ((rand()%65000) *(rand() %65000) + (rand()%65000)) ;
    Prueba() ;

    cout<<"Many elements , quite repeated\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = ((rand()%65000) *(rand() %65000) + (rand()%65000))  % (NELEM/2);
    Prueba() ;

    cout<<"Many element many repeated\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = rand() %10000;
    Prueba() ;

    cout<<"Equal elements\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = NELEM;
    Prueba() ;
    return 0 ;
};

void Prueba ( void )
{   //----------------------------- Inicio ------------------------
    double duracion ;
	clock_t start, finish;
    int i, k;

    cout<<"STL set ---> ";
    start = clock();
    // Prueba con la estructura STL
    for (  k = 0 ; k < 20 ; k ++)
    {
        std::set <int> S1 ;

        for (  i = 0 ; i < NELEM; i ++ )
        {    S1.insert ( A[i] );
        };

    };
    finish = clock() ;
	//duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";


    // Prueba con la estructura arbol
    cout<<"COUNTERTREE set ---> ";
    start = clock();
    for ( k = 0 ; k < 20 ; k ++)
    {
        cntree::set<int> M1 ;

        for ( i = 0 ; i < NELEM; i ++ )
        {    M1.insert( A[i] );
        };

    };
    finish = clock() ;
    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";


    cout<<"STL multiset --> ";
    start = clock();
    // Prueba con la estructura STL
    for (  k = 0 ; k < 20 ; k ++)
    {
        std::multiset <int, std::less <int> > S1 ;

        for (  i = 0 ; i < NELEM; i ++ )
        {    S1.insert ( A[i] );
        };

    };
    finish = clock() ;
	//duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";


    // Prueba con la estructura arbol
    cout<<"COUNTERTREE multiset---> ";
    start = clock();
    for ( k = 0 ; k < 20 ; k ++)
    {
        cntree::multiset<int> M1 ;

        for ( i = 0 ; i < NELEM; i ++ )
        {    M1.insert ( A[i] );
        };

    };
    finish = clock() ;
    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"Time spent :"<<duracion<<" seconds\n";

    cout<<"---------------------------------------------------\n\n";
};

