///----------------------------------------------------------------------------
// FILE : Benchmark_vector_tree_01.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco Jos� Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define  __DEBUG_MODE 0
#include <iostream>
#include <stdlib.h>
#include <deque>
#include <time.h>
#include <boost/countertree/vector_tree.hpp>


#define NELEM 1000000

using std::cout ;
using std::endl;


int  main ( void)
{   //---------------------- Variables----------------------------
	double duracion ;
	clock_t start, finish;
    int i , A[NELEM];
    int  min , nivel ;
    //------------------------ Inicio -----------------------------
    // Carga de los numeros aleatorios en A
    for ( i =0 ; i < NELEM ; i ++ ) A[i] = rand() ;

    // Examen de la desviacion m�xima
    min = 100 ;
    nivel = 0 ;
    for ( i = 0; i < NELEM ; i ++ )
    {   if ( (A[i] & 1)   == 0 )  nivel++;
        else
        {   nivel--;
            if ( nivel < min )
            {   A[i] &= ~1 ;
                nivel += 2 ;
            };
        };
    };

    cout<<"=============================================================\n";
    cout<<"    INSERCION SUPRESION DE "<<NELEM<<" ENTEROS\n";
    cout<<"=============================================================\n";

    //******************************************************************
    //
    //    C O M P A R A T I V A S   C O N    D E Q U E
    //
    //******************************************************************
    {
        //----------- Definicion de los datos------------------------
        cout<<"-----------------------------------------------------\n";
        cout<<" Insercion y supresion al inicio y al final \n";
        cout<<" Elementos simples ( enteros )\n";
        cout<<" Estructuras con "<<min <<" elementos \n";
        cout<<"-----------------------------------------------------\n";
        cntree::vector_tree <int> AP ;
        std::deque<int > S ;
        for ( i = 0 ; i < min ; i ++ ) AP.push_back(i) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   switch ( A[i] & 3)
            {   case 0:
                    AP.push_front (A[i]) ;
                    break;
                case 1:
                    AP.pop_front () ;
                    break ;
                case 2 :
                    AP.push_back(A[i] ) ;
                    break;
                case 3 :
                    AP.pop_back() ;
                    break;
            };
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"vector_tree - Tiempo empleado :"<<duracion<<" segundos\n";


        for ( i = 0 ; i < min ; i ++ ) S.push_back(i) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   switch ( A[i] &3)
            {   case 0:
                    S.push_front (A[i]) ;
                    break;
                case 1:
                    S.pop_front () ;
                    break ;
                case 2 :
                    S.push_back(A[i] ) ;
                    break;
                case 3 :
                    S.pop_back() ;
                    break;
            };
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"deque - Tiempo empleado :"<<duracion<<" segundos\n\n";
   };
    {   //----------------------------------------------------------------
        // Inserci�n y supresion de NELEM elementos simples ( enteros)
        // con estructuras con muchos datos  (NELEM / 2)
        //----------------------------------------------------------------
        cout<<"-----------------------------------------------------\n";
        cout<<" Insercion y supresion al inicio y al final \n";
        cout<<" Elementos simples ( enteros )\n";
        cout<<" Estructuras con "<<(NELEM)<<" elementos\n";
        cout<<"-----------------------------------------------------\n";

        //----------- Definicion de los datos------------------------
        cntree::vector_tree <int> AP ;
        std::deque<int> S ;
        for ( i = 0 ; i < NELEM ; i ++ ) AP.push_back(i) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   switch ( A[i] &3)
            {   case 0:
                    AP.push_front (A[i]) ;
                    break;
                case 1:
                    AP.pop_front () ;
                    break ;
                case 2 :
                    AP.push_back(A[i] ) ;
                    break;
                case 3 :
                    AP.pop_back() ;
                    break;
            };
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"vector_tree - Tiempo empleado :"<<duracion<<" segundos\n";

        for ( i = 0 ; i < NELEM/2 ; i ++ ) S.push_back(i) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   switch ( A[i] %4)
            {   case 0:
                    S.push_front (A[i]) ;
                    break;
                case 1:
                    S.pop_front () ;
                    break ;
                case 2 :
                    S.push_back(A[i] ) ;
                    break;
                case 3 :
                    S.pop_back() ;
                    break;
            };
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"deque - Tiempo empleado :"<<duracion<<" segundos\n\n";
    };
    {   //----------------------------------------------------------------
        // Inserci�n y supresion de 1000000 elementos simples ( enteros)
        // con estructuras con muy pocos datos en posiciones aleatorias
        //----------------------------------------------------------------
        cout<<"-----------------------------------------------------\n";
        cout<<" Insercion y supresion en posiciones aleatorias \n";
        cout<<" Elementos simples ( enteros )\n";
        cout<<" Estructuras con "<<min<<" elementos \n";
        cout<<"-----------------------------------------------------\n";

        //----------- Definicion de los datos------------------------
        cntree::vector_tree <int> AP ;
        std::deque<int > S ;

        for ( i = 0 ; i < min+1 ; i ++ ) AP.push_back(i) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( A[i] %2==0)
                AP.insert_pos (A[i],A[i] % AP.size()) ;
            else
                AP.erase_pos(A[i]%AP.size()) ;
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"vector_tree - Tiempo empleado :"<<duracion<<" segundos\n";

        for ( i = 0 ; i < min+1 ; i ++ ) S.push_back(i) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( A[i] %2==0)
                S.insert ( S.begin() + ( A[i]% S.size() ) , A[i] ) ;
            else
                S.erase (S.begin() + ( A[i] % S.size() ) );
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"deque - Tiempo empleado :"<<duracion<<" segundos\n\n";
    };
    {   //----------------------------------------------------------------
        // Inserci�n y supresion de NELEM elementos simples ( enteros)
        // con estructuras con muchos datos en posiciones aleatorias
        //----------------------------------------------------------------
        cout<<"-----------------------------------------------------\n";
        cout<<" Insercion y supresion en posiciones aleatorias \n";
        cout<<" Elementos simples ( enteros )\n";
        cout<<" Estructuras con "<<(NELEM)<<" elementos\n";
        cout<<"-----------------------------------------------------\n";

        //----------- Definicion de los datos------------------------
        cntree::vector_tree <int> AP ;
        std::deque<int > S ;

        for ( i = 0 ; i < NELEM ; i ++ ) AP.push_back(i) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( A[i] %2==0)
                AP.insert_pos (A[i],A[i] % AP.size()) ;
            else
                AP.erase_pos (A[i]%AP.size()) ;
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"vector_tree - Tiempo empleado :"<<duracion<<" segundos\n";

        for ( i = 0 ; i < NELEM ; i ++ ) S.push_back(i) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( A[i] %2==0)
                S.insert ( S.begin() + ( A[i]% S.size() ) , A[i] ) ;
            else
                S.erase (S.begin() + ( A[i] % S.size() ) );
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"deque - Tiempo empleado :"<<duracion<<" segundos\n\n";
    };

    return 0 ;
};



