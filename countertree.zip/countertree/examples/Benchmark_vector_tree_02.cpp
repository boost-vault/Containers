///----------------------------------------------------------------------------
// FILE : Benchmark_vector_tree_02.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco Jos� Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define  __DEBUG_MODE 0
#include <iostream>
#include <time.h>
#include <stdlib.h>
#include <vector>
#include <deque>
#include <stack>
#include <set>

#include <boost/countertree/vector_tree.hpp>

#define NELEM 10000

using std::cout;
using std::endl;

int  main ( void)
{   //---------------------- Variables----------------------------
    double duracion ;
	clock_t start, finish;
    int i , A[NELEM];
    int  min , nivel ;

    // Set STL de 100 elementos
    typedef std::set <int , std::less <int> > Sint ;
    Sint S1 ;
    for ( i = 0; i < 100 ; i ++ ) S1.insert ( i ) ;
    cout<<"=============================================================================\n";
    cout<<"             INSERTION / DELETION "<<NELEM <<"  OPERATIONS\n";
    cout<<"=============================================================================\n";

    //------------------------ Inicio -----------------------------
    // Carga de los numeros aleatorios en A
    for ( i =0 ; i < NELEM ; i ++ ) A[i] = rand() ;

    // Examen de la desviacion m�xima
    min = 100 ;
    nivel = 0 ;
    for ( i = 0; i < NELEM ; i ++ )
    {   if ( (A[i] & 1)   == 0 )  nivel++;
        else
        {   nivel--;
            if ( nivel < min )
            {   A[i] &= 1 ;
                nivel += 2 ;
            };
        };
    };

    //******************************************************************
    //
    //    C O M P A R A T I V A S   C O N    D E Q U E
    //
    //******************************************************************
    {   cout<<"-----------------------------------------------------\n";
        cout<<" Insercion y supresion al inicio y al final \n";
        cout<<" "<<NELEM <<"  Inserciones y supresiones\n";
        cout<<" Elementos complejos ( set de 100 elementos)\n";
        cout<<" Estructuras con "<< min<<" elementos \n";
        cout<<"-----------------------------------------------------\n";
        cntree::vector_tree <Sint> AP ;
        std::deque<Sint > S ;
        for ( i = 0 ; i < min ; i ++ ) AP.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   switch ( A[i] & 3)
            {   case 0:
                    AP.push_front (S1) ;
                    break;
                case 1:
                    AP.pop_front () ;
                    break ;
                case 2 :
                    AP.push_back(S1 ) ;
                    break;
                case 3 :
                    AP.pop_back() ;
                    break;
            };
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"vector_tree - Tiempo empleado :"<<duracion<<" segundos\n";


        for ( i = 0 ; i < min ; i ++ ) S.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   switch ( A[i] &3)
            {   case 0:
                    S.push_front (S1) ;
                    break;
                case 1:
                    S.pop_front () ;
                    break ;
                case 2 :
                    S.push_back(S1 ) ;
                    break;
                case 3 :
                    S.pop_back() ;
                    break;
            };
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"deque - Tiempo empleado :"<<duracion<<" segundos\n";
    };

    {   cout<<"-----------------------------------------------------\n";
        cout<<" Insercion y supresion al inicio y al final \n";
        cout<<" "<<NELEM <<"  Inserciones y supresiones\n";
        cout<<" Elementos complejos ( set de 100 elementos)\n";
        cout<<" Estructuras con "<<(NELEM)<<" elementos\n";
        cout<<"-----------------------------------------------------\n";

        //----------- Definicion de los datos------------------------
        cntree::vector_tree <Sint> AP ;
        std::deque<Sint> S ;
        for ( i = 0 ; i < NELEM ; i ++ ) AP.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   switch ( A[i] &3)
            {   case 0:
                    AP.push_front (S1) ;
                    break;
                case 1:
                    AP.pop_front() ;
                    break ;
                case 2 :
                    AP.push_back(S1 ) ;
                    break;
                case 3 :
                    AP.pop_back() ;
                    break;
            };
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"vector_tree - Tiempo empleado :"<<duracion<<" segundos\n";

        for ( i = 0 ; i < NELEM ; i ++ ) S.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   switch ( A[i] &3)
            {   case 0:
                    S.push_front (S1) ;
                    break;
                case 1:
                    S.pop_front () ;
                    break ;
                case 2 :
                    S.push_back(S1 ) ;
                    break;
                case 3 :
                    S.pop_back() ;
                    break;
            };
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"deque - Tiempo empleado :"<<duracion<<" segundos\n";
    };
    {   cout<<"-----------------------------------------------------\n";
        cout<<" Insercion y supresion en posiciones aleatorias \n";
        cout<<" "<<NELEM <<"  Inserciones y supresiones\n";
        cout<<" Elementos complejos ( set de 100 elementos)\n";
        cout<<" Estructuras con "<<min <<" elementos \n";
        cout<<"-----------------------------------------------------\n";

        //----------- Definicion de los datos------------------------
        cntree::vector_tree <Sint> AP ;
        std::deque<Sint > S ;

        for ( i = 0 ; i < min ; i ++ ) AP.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( (A[i] & 1)==0)
                AP.insert_pos (S1,A[i] % AP.size()) ;
            else
                AP.erase_pos (A[i]%AP.size()) ;
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"vector_tree - Tiempo empleado :"<<duracion<<" segundos\n";

        for ( i = 0 ; i < min+1 ; i ++ ) S.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( (A[i] & 1)==0)
                S.insert ( S.begin() + ( A[i]% S.size() ) , S1 ) ;
            else
                S.erase (S.begin() + ( A[i] % S.size() ) );
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"deque - Tiempo empleado :"<<duracion<<" segundos\n";
    };
    {   cout<<"-----------------------------------------------------\n";
        cout<<" Insercion y supresion en posiciones aleatorias \n";
        cout<<" "<<NELEM <<"  Inserciones y supresiones\n";
        cout<<" Elementos complejos ( set de 100 elementos)\n";
        cout<<" Estructuras con "<<(NELEM)<<" elementos\n";
        cout<<"-----------------------------------------------------\n";

        //----------- Definicion de los datos------------------------
        cntree::vector_tree <Sint> AP ;
        std::deque<Sint > S ;

        for ( i = 0 ; i < NELEM ; i ++ ) AP.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( A[i] % 2==0)
                AP.insert_pos (S1,A[i] % AP.size()) ;
            else
                AP.erase_pos (A[i] % AP.size()) ;
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"vector_tree - Tiempo empleado :"<<duracion<<" segundos\n";
        AP.clear() ;

        for ( i = 0 ; i < NELEM ; i ++ ) S.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( ( A[i] & 1 )==0)
                S.insert ( S.begin() + ( A[i]% S.size() ) , S1 ) ;
            else
                S.erase (S.begin() + ( A[i] % S.size() ) );
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"deque - Tiempo empleado :"<<duracion<<" segundos\n";
    };
    cout<<"-----------------------------------------------------\n";
    return 0 ;
};
