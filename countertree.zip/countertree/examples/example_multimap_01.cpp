#include <iostream>
#include <stdlib.h>
#include <boost/countertree/map.hpp>

typedef std::pair<const int, double> PID ;

std::ostream & operator << ( std::ostream &salida, const PID &P)
{   salida<<"("<<P.first<<" , "<<P.second<<") ";
    return salida ;
};

int  main ( void)
{   //-------------------------- begin--------------------
    cntree::multimap<int, double> M1;
    for ( int i = 1000 ; i < 3000 ; i+= 2) M1.insert (PID(i, rand()));

    cntree::multimap<int,double>::iterator Gamma, Beta  ;
    Gamma = M1.lower_bound( 2000);
    Beta = M1.end() - 50 ;

    for ( int i = Gamma.pos() ; i < Beta.pos() ; ++i)
        std::cout<<M1.at(i)<<std::endl;
    return 0 ;
};
