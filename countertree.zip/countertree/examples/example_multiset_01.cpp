#include <stdlib.h>
#include <boost/countertree/set.hpp>
#include <iostream>

int main ( void )
{   //------------------------ begin --------------------
    cntree::multiset<int> A ;
    for ( int i = 0 ; i< 100 ; ++i)  A.insert(i);
    cntree::multiset<int>::iterator Alfa, Beta ;

    Alfa = A.lower_bound( 45 );
    Beta = A.end() - 10 ;
    for ( int i = Alfa.pos() ; i < Beta.pos() ; ++i)
        std::cout<<A.at(i)<<" , ";
    std::cout<<std::endl;
    return 0 ;
};
