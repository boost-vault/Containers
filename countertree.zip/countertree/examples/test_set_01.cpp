///----------------------------------------------------------------------------
// FILE : TestSet_01.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#include <stdlib.h>
#include <boost/countertree/set.hpp>
#include <iostream>

#define NELEM   100

using std::ostream ;
using std::endl ;
using std::cout ;


ostream & operator <<( ostream &salida , const cntree::set<int> & S)
{   //---------------------------- begin -----------------------------------
    salida<<"Number of Nodes "<<S.size()<<endl;
    cntree::set<int>::iterator Alfa ;
    for ( Alfa = S.begin() ; Alfa != S.end() ; Alfa ++)
        salida<<(*Alfa)<<"   ";
    salida<<endl ;
    return salida ;
};
std::ostream & operator <<( ostream &salida , const cntree::multiset<int> & S)
{   //---------------------------- begin -----------------------------------
    salida<<"Number of Nodes "<<S.size()<<endl;
    cntree::set<int>::iterator Alfa ;
    for ( Alfa = S.begin() ; Alfa != S.end() ; Alfa ++)
        salida<<(*Alfa)<<"   ";
    salida<<endl ;
    return salida ;
};
void ConRepeticiones ( void );
void SinRepeticiones ( void) ;

int main ( void )
{   SinRepeticiones() ;
    ConRepeticiones() ;
    return 0 ;
};

void SinRepeticiones ( void)
{   //------------------------------------ begin ---------------------------------
    int V[NELEM];

    for ( int i = 0 ; i < NELEM ; i ++)
        V[i] =rand() ;

    cntree::set<int> A ;
    for ( int i = 0 ; i< NELEM ; ++i)
        A.insert( V[i] );

    cntree::set<int> B(A) ;
    cntree::set<int> C ( B.begin() + 20 , B.end() -20);
    B = C ;
    cout<<B<<endl;

    cntree::set<int>::iterator Alfa = A.begin() ;
    for (int  i = 0 ; Alfa != A.end() ; ++Alfa, ++i )
    {   if ( (*Alfa) != A.at(i) )cout<<"Error Discordancia en el set\n";
    };
    B.clear();
    B.insert(C.begin()+10 , C.end() -10);
    cout<<B<<endl;
    for ( int i = 0 ; i < NELEM ; ++i)
    {   if ( A.find( V[i]) == A.end())
            cout<<"Error en la busqueda\n";
    };
    if ( A.find( A.at(0) -1) != A.end())
        cout<<"Error en la operacion find\n";

    cntree::set<int>::iterator Beta ;
    Alfa = A.lower_bound( *(A.begin() +10)-1 );
    Beta = A.upper_bound ( A.at ( A.size() -10) +1);
    while ( Alfa != Beta)
    {   cout<<(*Alfa)<<"   " ;
        ++Alfa;
    };
    cout<<endl<<endl;

    std::pair<cntree::set<int>::iterator,cntree::set<int>::iterator> Gama ;
    Gama = A.equal_range(*(A.begin() +10) -1);
    while ( Gama.first != Gama.second)
    {   cout<<(*Gama.first)<<endl;
        ++ Gama.first;
    };

    Gama = A.equal_range( A.at(10) );
    while ( Gama.first != Gama.second)
    {   cout<<(*Gama.first)<<endl;
        ++ Gama.first;
    };
    cout<<endl;

};

void ConRepeticiones ( void)
{   //------------------------------------ begin ---------------------------------
    int V[NELEM];

    for ( int i = 0 ; i < NELEM ; i ++)
        V[i] =rand() ;

    cntree::multiset<int> A ;
    for ( int i = 0 ; i< NELEM ; ++i)
    {   A.insert( V[i] );
        A.insert( V[i] );
        A.insert( V[i] );
    };

    cntree::multiset<int> B(A) ;
    cntree::multiset<int> C ( B.begin() + 20 , B.end() -20);
    B = C ;
    cout<<B<<endl;

    cntree::multiset<int>::iterator Alfa = A.begin() ;
    for (int  i = 0 ; Alfa != A.end() ; ++Alfa, ++i )
    {   if ( (*Alfa) != A.at(i) )cout<<"Error Discordancia en el set\n";
    };
    B.clear();
    B.insert(C.begin()+10 , C.end() -10);
    cout<<B<<endl;
    for ( int i = 0 ; i < NELEM ; ++i)
    {   if ( A.find( V[i]) == A.end())
            cout<<"Error en la busqueda\n";
    };
    if ( A.find( A.at(0) -1) != A.end())
        cout<<"Error en la operacion find\n";

    cntree::multiset<int>::iterator Beta ;
    Alfa = A.lower_bound( *(A.begin() +10)-1 );
    Beta = A.upper_bound ( A.at ( A.size() -10) +1);
    while ( Alfa != Beta)
    {   cout<<(*Alfa)<<"   " ;
        ++Alfa;
    };
    cout<<endl<<endl;

    std::pair<cntree::multiset<int>::iterator,cntree::multiset<int>::iterator> Gama ;
    Gama = A.equal_range(*(A.begin() +10) -1);
    while ( Gama.first != Gama.second)
    {   cout<<(*Gama.first)<<endl;
        ++ Gama.first;
    };

    Gama = A.equal_range( A.at(10) );
    while ( Gama.first != Gama.second)
    {   cout<<(*Gama.first)<<endl;
        ++ Gama.first;
    };
    cout<<endl;

};
