//----------------------------------------------------------------------------
/// @file test_sort_01.cpp
/// @brief Program to test the sort funcion over a vector_tree
///
/// @author Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <boost/countertree/vector_tree.hpp>

int main ( void)
{   //---------------------------- begin -------------------------
    cntree::vector_tree<int >  V1, V2, V3 ;
    std::vector<int> V4 ;

    V1.push_back (111111111);
    for ( int i = 0 ; i < 1000 ; ++i)
        V1.push_back ( rand());

    std::sort ( V1.begin(), V1.end());

    for ( int i = 0 ; i < V1.size() ; ++i)
        std::cout<<V1[i]<<"    ";
    std::cout<<std::endl;

    if ( std::binary_search ( V1.begin() , V1.end(), 111111111) )
        std::cout<<"encontrado "<<std::endl;
    else std::cout<<"no encontrado"<<std::endl;

    for ( int i = 0 ; i < 1000 ; ++i)
        V2.push_back ( rand());
    std::sort ( V2.begin(), V2.end());


    std::cout<<"set_union ---------------------------->"<<std::endl;
    std::set_union ( V1.begin(), V1.end() , V2.begin(), V2.end() , std::back_inserter (V3));
    std::set_union ( V1.begin(), V1.end() , V2.begin(), V2.end() , std::back_inserter (V4));
    for ( int i = 0 ; i < V3.size() ; ++i)
        std::cout<<V3[i]<<"    ";
    std::cout<<std::endl;

}
