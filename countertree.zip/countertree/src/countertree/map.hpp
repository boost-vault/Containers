//----------------------------------------------------------------------------
/// @file   map.hpp
/// @brief  This file contains the implementation of map and multimap,
///         based on the vector_tree
///
/// @author Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_MAP_HPP
#define __COUNTERTREE_MAP_HPP

#include <functional>
#include <utility>
#include <boost/countertree/sorted_vector_tree.hpp>

namespace cntree
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                  C L A S S                       #             ##
//       #                                                  #             ##
//       #                    M A P                         #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################


//-------------------------------------------------------------
/// @class  map
/// @brief  This class have the same interface and functions than the
///         class map defined in the Standard Template Library ( STL),
///         plus a function  at which permit to access to the elements
///         of the map by their position
///         This class map have too, iterators with random access, which
///         permit increment and decrement any value to the iterators
/// @remarks
//----------------------------------------------------------------
template < class Key, class Data, class Comp=std::less<Key>,
class Alloc=std::allocator<std::pair <const Key, Data> > >
class map
{
public :
//##########################################################################
//                                                                        ##
//                    D E F I N I T I O N S                               ##
//                                                                        ##
//##########################################################################
typedef Key                                                    key_type;
typedef std::pair<const Key,Data >                             value_type ;
typedef tools::CompPair<Key,Data,Comp>                         ValueCompare;
typedef tools::filter_map<Key , value_type>                    Filter ;
typedef sorted_vector_tree<value_type,Key,Filter,Comp,Alloc>   SVTree ;
typedef typename SVTree::iterator                              iterator;
typedef typename SVTree::const_iterator                        const_iterator ;
typedef typename SVTree::iterator                              reverse_iterator;
typedef typename SVTree::const_iterator                        const_reverse_iterator;
typedef typename SVTree::size_type                             size_type ;
typedef typename SVTree::difference_type                       difference_type;

private :
//##########################################################################
//                                                                        ##
//                     V A R I A B L E S                                  ##
//                                                                        ##
//##########################################################################
SVTree SVT ;

public:
//##########################################################################
//                                                                        ##
//           C O N S T R U C T O R , D E S T R U C T O R                  ##
//                                                                        ##
//           A S I G N A T I O N   ,  A T ( Access by position)           ##
//                                                                        ##
//##########################################################################

//-----------------------------------------------------------------------
//  function : map
/// @brief  Constructor from an object Comparer and an object Allocator
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//------------------------------------------------------------------------
explicit map ( const Comp& C1 = Comp(),
               const Alloc & A= Alloc() ): SVT(Filter(),C1,A){};

//----------------------------------------------------------------
//  function : map
/// @brief  Constructor from a pair of iterators and an object
///         Comparer and an object Allocator
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//----------------------------------------------------------------
template <class InputIterator>
map ( InputIterator first,
      InputIterator last,
      const Comp& C1 = Comp(),
      const Alloc & A1= Alloc() ): SVT(Filter(),C1,A1)
{   //---------------------begin ----------------------------
    for ( ; first != last ; first++) insert ( *first) ;
};

//----------------------------------------------------------------
//  function : map
/// @brief  Copy constructor
/// @param [in] m :map from where copy the data
//----------------------------------------------------------------
map( const map<Key,Data,Comp,Alloc>& m ): SVT ( m.SVT){};

//----------------------------------------------------------------
//  function : ~map
/// @brief  Destructor
//----------------------------------------------------------------
virtual ~map(){};

//----------------------------------------------------------------
//  function : operator =
/// @brief Asignation operator
/// @param [in] m : map from where copy the data
/// @return Reference to the map after the copy
//---------------------------------------------------------------
map & operator= ( const map &m)
{   SVT = m.SVT;
    return *this ;
};

//----------------------------------------------------------------------
//  function : at
/// @brief  Access to an element by their position in the map
/// @param  in] Pos : Position to read
/// @return Reference to the object selected
/// @remarks This is an random access function of the map.
///          This operation is log(N) \n I didn't use
///          the operator [ ] because it is used in the map class.\n
///          It is very important to be uniform access method in the
///          four classes ( set, multiset, map and multimap)
//------------------------------------------------------------------------
value_type & at ( size_type Pos)      {   return SVT[Pos] ; };

//-------------------------------------------------------------------------
//  function : at
/// @brief  Access to an element by their position in the map
/// @param  in] Pos : Position to read
/// @return Const Reference to the object selected
/// @remarks This is an random access function of the map.
///          This operation is log(N) \n I didn't use
///          the operator [ ] because it is used in the map class.\n
///          It is very important to be uniform access method in the
///          four classes ( set, multiset, map and multimap)
//--------------------------------------------------------------------------
const value_type & at ( size_type Pos)const {   return SVT[Pos] ; };

//##########################################################################
//                                                                        ##
//                   I T E R A T O R S                                    ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------------
//  function : is_mine
/// @brief Check if the iterator is pointing to this map
/// @param [in] P1 : iterator to check
/// @return (true/false ) Indicate if it is pointing to this map
/// @remarks This operation is O ( const )
//------------------------------------------------------------------------
bool is_mine ( iterator it) const
{   return SVT.is_mine(it) ;
};

//----------------------------------------------------------------
//  function : begin
/// @brief Return one iterator to the first element of the map
/// @return Iterator to the first element of the map
//----------------------------------------------------------------
iterator begin (void )       { return SVT.begin() ;};

//----------------------------------------------------------------
//  function :begin
/// @brief Return one const_iterator to the first element of the map
/// @return Const_iterator to the first element of the map
//----------------------------------------------------------------
const_iterator begin (void ) const { return SVT.begin() ;};

//----------------------------------------------------------------
//  function :end
/// @brief Return one iterator to the next element after the last
/// @return Iterator to the next element after the last
//----------------------------------------------------------------
iterator end ( void )       { return SVT.end() ;};

//----------------------------------------------------------------------
//  function : end
/// @brief Return one const_iterator to the next element after the last
/// @return Const_terator to the next element after the last
//-----------------------------------------------------------------------
const_iterator end ( void ) const { return SVT.end() ;};

//----------------------------------------------------------------
//  function : rbegin
/// @brief return one iterator to the last element of the map
/// @return iterator to the last element of the map
//----------------------------------------------------------------
iterator  rbegin (void) { return SVT.rbegin();};

//----------------------------------------------------------------
//  function : rbegin
/// @brief return one const_iterator to the last element of the map
/// @return const_iterator to the last element of the map
//----------------------------------------------------------------
const_iterator rbegin (void)const { return SVT.rbegin();};

//---------------------------------------------------------------------
//  function : rend
/// @brief return one iterator to the previous elemento to the first
/// @return iterator to the previous elemento to the first
//-----------------------------------------------------------------------
iterator rend ( void ) { return SVT.rend() ;};

//-------------------------------------------------------------------------
//  function :rend
/// @brief return one const_iterator to the previous elemento to the first
/// @return const_iterator to the previous elemento to the first
//-------------------------------------------------------------------------
const_iterator rend ( void ) const{ return SVT.rend() ;};

//##########################################################################
//                                                                        ##
//                       C A P A C I T Y                                  ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------
//  function : empty
/// @brief indicate if the map is empty
/// @return true if the map is empty, false in any other case
//----------------------------------------------------------------
bool empty (void) const {return SVT.empty();};

//----------------------------------------------------------------
//  function : size
/// @brief return the number of elements in the map
/// @return number of elements in the map
//----------------------------------------------------------------
size_type size (void) const { return SVT.size() ;};

//----------------------------------------------------------------
//  function : max_size
/// @brief return the maximun size of the container
/// @return maximun size of the container
//----------------------------------------------------------------
size_type max_size ( void) const { return SVT.size_type_max() ;};

//##########################################################################
//                       M O D I F I E R S                                ##
//                                                                        ##
//  I N S E R T ,  E R A S E , O P E R A T O R [ ] , S W A P , C L E A R  ##
//                                                                        ##
//##########################################################################
//---------------------------------------------------------------------------
//  function : operator[ ]
/// @brief  Return the Data with the key K, if don't exist , inserts a
///         new pair (key, Data) with that key and returns a reference
///         to this pair
/// @param [in] K  key to find in the map
/// @return reference to the Data of the pair with key K
//---------------------------------------------------------------------------
Data & operator[] ( const Key  &K )
{   //------------ begin ----------------
    iterator Alfa = SVT.find(K);
    if ( Alfa == end())
    {   value_type V1 ( K, Data());
        Alfa = SVT.insert_value_unique( V1);
    };
    return (Alfa->second) ;
};

//----------------------------------------------------------------
//  function : insert
/// @brief insert a value in the map
/// @param [in] X : value to insert
/// @return Pair of elements, the first is one iterator to the element
///         inserted \n and the second is a boolean which indcate if
///         the iterator is end()
//----------------------------------------------------------------
std::pair<iterator,bool> insert ( const value_type& x )
{   iterator Alfa = SVT.insert_value_unique ( x );
    return std::pair<iterator,bool> ( Alfa , Alfa != end());
};

//----------------------------------------------------------------------------
//  function : insert
/// @brief Insert a value in the map, and receive too an iterator to
///        an element nearest the insertion point \n
/// @param [in] position :iterator to an element close to the insertion point
/// @param [in] x : element to insert
/// @return iterator to the element inserted
/// @remarks This function is unuseful in this implementation
//-----------------------------------------------------------------------------
iterator insert ( iterator position, const value_type& x )
{   iterator Alfa = SVT.insert_value_unique ( x );
    return Alfa ;
};

//----------------------------------------------------------------
//  function : insert
/// @brief Insertion of range of elements from two iterators
/// @param [in] first : Iterator to the first element of the range
/// @param [in] last : Iterator to the last lement of the range
/// @return none
//----------------------------------------------------------------
template <class InputIterator>
void insert ( InputIterator first, InputIterator last )
{   for ( ; first != last ; ++first) insert ( *first);
};

//----------------------------------------------------------------
//  function : erase
/// @brief erase the element pointed by iter
/// @param [in] iter : iterator to the element to erase
/// @return none
//----------------------------------------------------------------
void erase ( iterator position )
{
#if __DEBUG_MODE > 0
    if ( not is_mine (position) )
        throw std::invalid_argument ("map::erase");
#endif
    SVT.erase( position);
};

//----------------------------------------------------------------
//  function : erase
/// @brief Erase all the elements with a key
/// @param [in] x : key of all the elements to erase
/// @return number of elements erased
//----------------------------------------------------------------
size_type erase ( const Key& x )
{   iterator first = lower_bound ( x) ;
    iterator last = upper_bound( x);
    size_type N = last - first ;
    erase ( first, last) ;
    return N ;
};

//----------------------------------------------------------------
//  function :erase
/// @brief erase a range of elements in the range first, last
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @return none
//----------------------------------------------------------------
void erase ( iterator first, iterator last )
{
#if __DEBUG_MODE > 0
    if ( not is_mine (first) or not is_mine (last))
        throw std::invalid_argument ("map::erase");
#endif
    SVT.erase ( first, last);
};

//----------------------------------------------------------------
//  function : swap
/// @brief swap the data of the map st with the actual map
/// @param [in] st : map to swap
/// @return none
//----------------------------------------------------------------
void swap ( map<Key,Data,Comp,Alloc>& mp )
{  SVT.swap (mp.SVT);
};

//----------------------------------------------------------------
//  function : clear
/// @brief Delete all the elements of the map
/// @param [in] none
/// @return none
//----------------------------------------------------------------
void clear ( void ){ SVT.clear() ;};

//##########################################################################
//                                                                        ##
//                   O B S E R V E R S                                    ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------
//  function : key_comp
/// @brief return the object used to compare two keys
/// @param [in] none
/// @return object used to compare two keys
//----------------------------------------------------------------
Comp key_comp ( ) const{ return SVT.key_comp();};

//----------------------------------------------------------------
//  function : value_comp
/// @brief return the object used to compare two values
/// @param [in] none
/// @return object used to compare two values
//----------------------------------------------------------------
ValueCompare value_comp ( ) const
{   return ValueCompare (SVT.key_comp());
};

//----------------------------------------------------------------
//  function : get_allocator
/// @brief return the object allocator of the map
/// @param [in] none
/// @return object allocator
//----------------------------------------------------------------
Alloc get_allocator() const { return SVT.A ;};

//##########################################################################
//                                                                        ##
//          F I N D ,  C O U N T , L O W E R _ B O U N D                  ##
//                                                                        ##
//         U P P E R _ B O U N D , E Q U A L _ R A N G E                  ##
//                                                                        ##
//##########################################################################
//----------------------------------------------------------------------------
//  function : find
/// @brief return the iterator to the element with the key x
/// @param [in] x : key to find in the map
/// @return iterator to the element with the key x. If don't exist return end()
//------------------------------------------------------------------------------
iterator find ( const Key& x )
{   return SVT.find_unique(x) ;
};

//----------------------------------------------------------------------
//  function : find
/// @brief return the const_iterator to the element with the key x
/// @param [in] x : key to find in the map
/// @return const_iterator to the element with the key x. If don't
/// exist return end()
//----------------------------------------------------------------------
const_iterator find ( const Key& x ) const
{   return SVT.find(x);
};

//---------------------------------------------------------------------
//  function : count
/// @brief return the number of elements in the map with the key x
/// @param [in] x : key to find
/// @return number of elements in the set with the key x
/// @remarks This operation is log (N)
//----------------------------------------------------------------------
size_type count ( const Key& x ) const
{   iterator first = lower_bound ( x) ;
    iterator last = upper_bound( x);
    return last - first ;
};

//--------------------------------------------------------------------------
//  function : lower_bound
/// @brief return one iterator to the first appearance of the key x
/// if exist \n and if don't exist return one iterator to the first
/// element greather than x
/// @param [in] x : key to find
/// @return iterator
//--------------------------------------------------------------------------
iterator lower_bound ( const Key & x )
{   return SVT.lower_bound(x);
};
//--------------------------------------------------------------------------
//  function :lower_bound
/// @brief return one const_iterator to the first appearance of the key x
/// if exist \n and if don't exist return one iterator to the first element
/// greather than x
/// @param [in] x : key to find
/// @return const_iterator
//---------------------------------------------------------------------------
const_iterator lower_bound ( const Key & x ) const
{   return SVT.lower_bound(x);
};

//---------------------------------------------------------------------------
//  function : upper_bound
/// @brief return one iterator to the first element greather than x. If
/// don't exist any element greather than x , return end()
/// @param [in] x : key to find
/// @return iterator
//--------------------------------------------------------------------------
iterator upper_bound ( const Key& x )
{   return SVT.upper_bound(x);
};

//--------------------------------------------------------------------------
// function : upper_bound
/// @brief return one const_iterator to the first element greather than x.
/// If don't exist any element greather than x , return end()
/// @param [in] x : key to find
/// @return const_iterator
//------------------------------------------------------------------------
const_iterator upper_bound ( const Key& x ) const
{   return SVT.upper_bound(x);
};

//----------------------------------------------------------------------
//  function : equal_range
/// @brief return a pair of iterators, the first is the lower_bound (x)
/// and the second is upper_bound (x)
/// @param [in] X :key to find
/// @return pair of iterators
//----------------------------------------------------------------------
std::pair<iterator,iterator> equal_range ( const Key& x )
{   return SVT.equal_range(x);
};

//--------------------------------------------------------------------------
//  function : equal_range
/// @brief return a pair of const_iterators, the first is the lower_bound(x)
/// and the second is upper_bound (x)
/// @param [in] X :key to find
/// @return pair of const_iterators
//---------------------------------------------------------------------------
std::pair<const_iterator,const_iterator> equal_range (const Key& x )const
{   return SVT.equal_range(x);
};

}; //--------------------- end of the clas map -----------------------------------

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                 C L A S S                        #             ##
//       #                                                  #             ##
//       #              M U L T I M A P                     #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//---------------------------------------------------------------------------
/// @class  multimap
/// @brief  This class have the same interface and functions than the
///  class multimap defined in the Standard Template Library ( STL), plus a
///  function at which permit to access to the elements of the map by their
///  position
///  This class multimap have too, iterators with random access, which permit
///  increment and decrement any value to the iterators
/// @remarks
//----------------------------------------------------------------------------

template <class Key, class Data, class Comp=std::less<Key>,
class Alloc=std::allocator<std::pair <const Key, Data> > >
class multimap
{
public :
//##########################################################################
//                                                                        ##
//                    D E F I N I T I O N S                               ##
//                                                                        ##
//##########################################################################
typedef Key                                                    key_type;
typedef std::pair<const Key,Data >                             value_type ;
typedef tools::CompPair<Key,Data,Comp>                         ValueCompare;
typedef tools::filter_map<Key , value_type>                    Filter ;
typedef sorted_vector_tree<value_type,Key,Filter,Comp,Alloc>   SVTree ;
typedef typename SVTree::iterator                              iterator;
typedef typename SVTree::const_iterator                        const_iterator ;
typedef typename SVTree::iterator                              reverse_iterator;
typedef typename SVTree::const_iterator                        const_reverse_iterator;
typedef typename SVTree::size_type                             size_type ;
typedef typename SVTree::difference_type                       difference_type;
private :
//##########################################################################
//                                                                        ##
//                     V A R I A B L E S                                  ##
//                                                                        ##
//##########################################################################
SVTree SVT ;

public:
//##########################################################################
//                                                                        ##
//           C O N S T R U C T O R , D E S T R U C T O R                  ##
//                                                                        ##
//           A S I G N A T I O N   ,  A T ( Access by position)           ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------------
//  function :multimap
/// @brief  Constructor from an object Comparer and an object Allocator
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//----------------------------------------------------------------------
explicit multimap ( const Comp& C1 = Comp(),
                    const Alloc & A= Alloc() ): SVT(Filter(),C1,A){};

//--------------------------------------------------------------------
//  function : multimap
/// @brief  Copy constructor
/// @param [in] m :multimap from where copy the data
//--------------------------------------------------------------------
multimap( const multimap<Key,Data,Comp,Alloc>& m ): SVT ( m.SVT){};

//---------------------------------------------------------------------
//  function : multimap
/// @brief  Constructor from a map
/// @param [in] m :map from where copy the data
//---------------------------------------------------------------------
multimap( const map<Key,Data,Comp,Alloc>& m ): SVT ( m.SVT){};

//---------------------------------------------------------------------
//  function : multimap
/// @brief  Constructor from a pair of iterators and an object
///         Comparer and an object Allocator
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @param [in] C1 : Comparer
/// @param [in] A1 : Allocator
//-----------------------------------------------------------------------
template <class InputIterator>
multimap( InputIterator first, InputIterator last,const Comp& C1 = Comp(),
      const Alloc & A1= Alloc() ): SVT(Filter(),C1,A1)
{   //---------------------begin ----------------------------
    for ( ; first != last ; first++) insert ( *first) ;
};

//----------------------------------------------------------------
//  function : ~multimap
/// @brief  Destructor
//----------------------------------------------------------------
virtual ~multimap(){};

//----------------------------------------------------------------
//  function : operator =
/// @brief Asignation operator
/// @param [in] m : map from where copy the data
/// @return Reference to the map after the copy
//---------------------------------------------------------------
multimap & operator= ( const multimap &m)
{   SVT = m.SVT;
    return *this ;
};
//----------------------------------------------------------------------
//  function : at
/// @brief  Access to an element by their position in the multimap
/// @param  [in] Pos : Position to read
/// @return Reference to the object selected
/// @remarks This is an random access function of the multimap.
/// This operation is log(N) \n
/// I didn't use the operator [ ] because it is used in the map class.\n
/// It is very important to be uniform access method in the four classes
/// ( set, multiset, map and multimap)
//----------------------------------------------------------------------
value_type & at ( size_type Pos){   return SVT[Pos] ; };

//----------------------------------------------------------------------
//  function : at
/// @brief  Access to an element by their position in the multimap
/// @param  [in] Pos : Position to read
/// @return Const reference to the object selected
/// @remarks This is an random access function of the multimap.
/// This operation is log(N) \n
/// I didn't use the operator [ ] because it is used in the map class.\n
/// It is very important to be uniform access method in the four classes
/// ( set, multiset, map and multimap)
//-------------------------------------------------------------------------
const value_type & at ( size_type Pos)const {   return SVT[Pos] ; };


//##########################################################################
//                                                                        ##
//                   I T E R A T O R S                                    ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------------
//  function : is_mine
/// @brief Check if the iterator is pointing to this map
/// @param [in] P1 : iterator to check
/// @return (true/false ) Indicate if it is pointing to this map
/// @remarks This operation is O ( const )
//------------------------------------------------------------------------
bool is_mine ( iterator it) const
{   return SVT.is_mine(it) ;
};

//-------------------------------------------------------------------
//  function : begin
/// @brief Return one iterator to the first element of the multimap
/// @return Iterator to the first element of the multimap
//--------------------------------------------------------------------
iterator begin (void )        { return SVT.begin() ;};

//----------------------------------------------------------------------
//  function : begin
/// @brief Return one const_iterator to the first element of the multimap
/// @return Const_iterator to the first element of the multimap
//-----------------------------------------------------------------------
const_iterator begin (void ) const { return SVT.begin() ;};

//----------------------------------------------------------------
//  function : end
/// @brief Return one iterator to the next element after the last
/// @return Iterator to the next element after the last
//----------------------------------------------------------------
iterator end ( void )        { return SVT.end() ;};

//---------------------------------------------------------------------
//  function : end
/// @brief Return one const_iterator to the next element after the last
/// @return Const_terator to the next element after the last
//---------------------------------------------------------------------
const_iterator end ( void ) const { return SVT.end() ;};

//----------------------------------------------------------------
//  function : rbegin
/// @brief return one iterator to the last element of the map
/// @return iterator to the last element of the map
//----------------------------------------------------------------
iterator       rbegin (void)       { return SVT.rbegin();};

//----------------------------------------------------------------
//  function : rbegin
/// @brief return one const_iterator to the last element of the map
/// @return const_iterator to the last element of the map
//----------------------------------------------------------------
const_iterator rbegin (void)const { return SVT.rbegin();};

//---------------------------------------------------------------------
//  function : rend
/// @brief return one iterator to the previous elemento to the first
/// @return iterator to the previous elemento to the first
//---------------------------------------------------------------------
iterator       rend ( void )        { return SVT.rend() ;};

//--------------------------------------------------------------------------
//  function : rend
/// @brief return one const_iterator to the previous elemento to the first
/// @return const_iterator to the previous elemento to the first
//--------------------------------------------------------------------------
const_iterator rend ( void ) const { return SVT.rend() ;};

//##########################################################################
//                                                                        ##
//                       C A P A C I T Y                                  ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------
//  function : empty
/// @brief indicate if the map is empty
/// @return true if the map is empty, false in any other case
//----------------------------------------------------------------
bool empty (void) const {return SVT.empty();};

//----------------------------------------------------------------
//  function : size
/// @brief return the number of elements in the map
/// @return number of elements in the map
//----------------------------------------------------------------
size_type size (void) const { return SVT.size() ;};

//----------------------------------------------------------------
//  function : max_size
/// @brief return the maximun size of the container
/// @return maximun size of the container
//----------------------------------------------------------------
size_type max_size ( void) const { return SVT.size_type_max() ;};

//##########################################################################
//                       M O D I F I E R S                                ##
//                                                                        ##
//  I N S E R T ,  E R A S E , O P E R A T O R [ ] , S W A P , C L E A R  ##
//                                                                        ##
//##########################################################################

//-----------------------------------------------------------------------
//  function : insert
/// @brief insert a value in the map
/// @param [in] x : value to insert
/// @return pair of elements, the first is one iterator to the element
///         inserted and the second is a boolean which indcate if the
///         iterator is end()
//-----------------------------------------------------------------------
std::pair<iterator,bool> insert ( const value_type& x )
{   iterator Alfa = SVT.insert_value ( x );
    return std::pair<iterator,bool> ( Alfa , Alfa != end());
};

//----------------------------------------------------------------
//  function : insert
/// @brief insert a value in the map, and receive too an iterator to
///     an element nearest the insertion point \n
/// @param [in] position :iterator to an element close to the insertion
///                       point
/// @param [in] x : element to insert
/// @return iterator to the element inserted
/// @remarks This function is unuseful in this implementation
//----------------------------------------------------------------
iterator insert ( iterator position, const value_type& x )
{   iterator Alfa = SVT.insert_value ( x );
    return Alfa ;
};

//----------------------------------------------------------------
//  function : insert
/// @brief Insertion of range of elements from two iterators
/// @param [in] first : Iterator to the first element of the range
/// @param [in] last : Iterator to the last lement of the range
/// @return none
//----------------------------------------------------------------
template <class InputIterator>
void insert ( InputIterator first, InputIterator last )
{   for ( ; first != last ; ++first) insert ( *first);
};

//----------------------------------------------------------------
//  function : erase
/// @brief erase the element pointed by iter
/// @param [in] iter : iterator to the element to erase
/// @return none
//----------------------------------------------------------------
void erase ( iterator position )
{
#if __DEBUG_MODE > 0
    if ( not is_mine (position) )
        throw std::invalid_argument ("multimap::erase");
#endif
    SVT.erase( position);
};

//----------------------------------------------------------------
//  function : erase
/// @brief Erase all the elements with a key
/// @param [in] x : key of all the elements to erase
/// @return number of elements erased
//----------------------------------------------------------------
size_type erase ( const Key& x )
{   iterator first = lower_bound ( x) ;
    iterator last = upper_bound( x);
    size_type N = last - first ;
    erase ( first, last) ;
    return N ;
};

//----------------------------------------------------------------
//  function : erase
/// @brief erase a range of elements in the range first, last
/// @param [in] first : iterator to the first element of the range
/// @param [in] last : iterator to the last element of the range
/// @return none
//----------------------------------------------------------------
void erase ( iterator first, iterator last )
{
#if __DEBUG_MODE > 0
    if ( not is_mine (first) or not is_mine (last))
        throw std::invalid_argument ("multimap::erase");
#endif
    SVT.erase ( first, last);
};

//----------------------------------------------------------------
//  function : swap
/// @brief swap the data of the map st with the actual map
/// @param [in] st : map to swap
/// @return none
//----------------------------------------------------------------
void swap ( multimap<Key,Data,Comp,Alloc>& mp )
{  SVT.swap (mp.SVT);
};

//----------------------------------------------------------------
//  function : clear
/// @brief Delete all the elements of the map
/// @param [in] none
/// @return none
//----------------------------------------------------------------
void clear ( void ){ SVT.clear() ;};


//##########################################################################
//                                                                        ##
//                   O B S E R V E R S                                    ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------
//  function : key_comp
/// @brief return the object used to compare two keys
/// @param [in] none
/// @return object used to compare two keys
//----------------------------------------------------------------
Comp key_comp ( ) const{ return SVT.key_comp();};

//----------------------------------------------------------------
//  function : value_comp
/// @brief return the object used to compare two values
/// @param [in] none
/// @return object used to compare two values
//----------------------------------------------------------------
ValueCompare value_comp ( ) const
{   return ValueCompare (SVT.key_comp());
};

//----------------------------------------------------------------
//  function : get_allocator
/// @brief return the object allocator of the map
/// @param [in] none
/// @return object allocator
//----------------------------------------------------------------
Alloc get_allocator() const { return SVT.A ;};

//##########################################################################
//                                                                        ##
//          F I N D ,  C O U N T , L O W E R _ B O U N D                  ##
//                                                                        ##
//         U P P E R _ B O U N D , E Q U A L _ R A N G E                  ##
//                                                                        ##
//##########################################################################

//----------------------------------------------------------------
//  function : find
/// @brief return the iterator to the element with the key x
/// @param [in] x : key to find in the map
/// @return iterator to the element with the key x. If don't
/// exist return end()
//----------------------------------------------------------------
iterator find ( const Key& x )
{   return SVT.find(x) ;
};

//----------------------------------------------------------------
//  function : find
/// @brief return the const_iterator to the element with the key x
/// @param [in] x : key to find in the map
/// @return const_iterator to the element with the key x. If don't
/// exist return end()
//----------------------------------------------------------------
const_iterator find ( const Key& x ) const
{   return SVT.find(x);
};

//----------------------------------------------------------------
//  function : count
/// @brief return the number of elements in the map with the key x
/// @param [in] x : key to find
/// @return number of elements in the set with the key x
/// @remarks This operation is log (N)
//----------------------------------------------------------------
size_type count ( const Key& x ) const
{   iterator first = lower_bound ( x) ;
    iterator last = upper_bound( x);
    return last - first ;
};

//----------------------------------------------------------------
//  function : lower_bound
/// @brief return one iterator to the first appearance of the key x
///        if exist and if don't exist return one iterator to the first
///        element greather than x
/// @param [in] x : key to find
/// @return iterator
//----------------------------------------------------------------
iterator lower_bound ( const Key & x )
{   return SVT.lower_bound(x);
};

//----------------------------------------------------------------
//  function : lower_bound
/// @brief Return one const_iterator to the first appearance of the
///        key x if exist \n and if don't exist return one iterator
///        to the first element greather than x
/// @param [in] x : key to find
/// @return const_iterator
//----------------------------------------------------------------
const_iterator lower_bound ( const Key & x ) const
{   return SVT.lower_bound(x);
};

//------------------------------------------------------------------
//  function : upper_bound
/// @brief return one iterator to the first element greather than x.
///        If don't exist any element greather than x , return end()
/// @param [in] x : key to find
/// @return iterator
//------------------------------------------------------------------
iterator upper_bound ( const Key& x )
{   return SVT.upper_bound(x);
};

//------------------------------------------------------------------------
//  function : upper_bound
/// @brief return one const_iterator to the first element greather than x.
///        If don't exist any element greather than x , return end()
/// @param [in] x : key to find
/// @return const_iterator
//-------------------------------------------------------------------------
const_iterator upper_bound ( const Key& x ) const
{   return SVT.upper_bound(x);
};

//--------------------------------------------------------------------
//  function : equal_range
/// @brief return a pair of iterators, the first is the lower_bound (x)
///        and the second is upper_bound (x)
/// @param [in] X :key to find
/// @return pair of iterators
//---------------------------------------------------------------------
std::pair<iterator,iterator> equal_range ( const Key& x )
{   return SVT.equal_range(x);
};

//-------------------------------------------------------------------------
//  function : equal_range
/// @brief return a pair of const_iterators, the first is the lower_bound(x)
///        and the second is upper_bound (x)
/// @param [in] X :key to find
/// @return pair of const_iterators
//---------------------------------------------------------------------------
std::pair<const_iterator,const_iterator> equal_range ( const Key& x ) const
{   return SVT.equal_range(x);
};


}; //--------------------- end of the clas multimap -----------------------------------
}; //----------------------- end namespace util ----------------------------------

#endif

