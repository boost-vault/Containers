//----------------------------------------------------------------------------
/// @file   iterator.hpp
/// @brief  This file contains the Iterator and const_iterator definition
///
/// @author Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_BASIC_TREE_HPP
#define __COUNTERTREE_BASIC_TREE_HPP

#include <boost/countertree/tools/node.hpp>

namespace cntree
{
namespace tools // tools
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #            B A S I C _ T R E E                   #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
/// @struct  basic_tree
/// @brief  This struct is for to provide to the iterators, the number of
///         elements and the pointers to the first and last nodes of the tree
///
/// @remarks
//----------------------------------------------------------------
template <class T>
struct basic_tree
{
    //##########################################################################
    //                                                                        ##
    //                    D E F I N I T I O N S                               ##
    //                                                                        ##
    //##########################################################################
    typedef typename  node<T>::pnode          pnode ;
    typedef typename  node<T>::const_pnode    const_pnode   ;
    typedef  Conf<NByte>::size_type size_type ;
    virtual ~basic_tree(void){};
    //----------------- virtual functions ------------
    virtual       size_type  size(void) const = 0 ;
    virtual       pnode get_first ( void)       = 0 ;
    virtual const_pnode get_first ( void) const = 0 ;
    virtual       pnode get_last  ( void)       = 0 ;
    virtual const_pnode get_last  ( void) const = 0 ;

};


}; //----------------------- end namespace tools ---------------------------
}; //---------------------- end namespace cntree ----------------------------
#endif
