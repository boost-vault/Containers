///------------------------------------------------------------------------------
// FILE : Config.h
//
// DESCRIPTION : This file contains the definition of the data formats used
//  in the impementation of tree234 and all the classes related
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_CONFIG_HPP
#define __COUNTERTREE_CONFIG_HPP

#include <limits>
#include <boost/cstdint.hpp>
#include <ciso646>

//------------------------------------------------------------------
// if __DEBUG_MODE is defined , the compilation is done checking all
// the parameters of  every functions, and lost around 20% of speed
// This must be the first line of code in the program
// You have 3 levels of debug
// 2 - Activate specific functions  for to debug
// 1 - Checking all the parameters of all the functions, and if error
//     raise an exception ( default )
// 0 - No debug
//-------------------------------------------------------------------
#ifndef __DEBUG_MODE
    #define __DEBUG_MODE 1
#endif

namespace cntree
{
namespace tools 
{

//-----------------------------------------------------------------
// Public data definitions
//-----------------------------------------------------------------
const unsigned NByte = sizeof(size_t) ;
//----------------------------------------------------------
//    32 bits compiler
//----------------------------------------------------------
template <unsigned NByte >
struct Conf
{   //--------------- Type definition--------------
    typedef int32_t  size_type;
    typedef uint32_t bitfield_t ;

    //const int32_t  size_type_max = std::numeric_limits<size_type>::max();
    enum { n_bits_number = 31 };
    //void * const Ptr_Max =0xffffffffU;
};
//----------------------------------------------------------
//    64 bits compiler
//----------------------------------------------------------
template < >
struct Conf<8>
{   //------Type definition -------------
    typedef int64_t  size_type;
    typedef uint64_t bitfield_t ;

    //const int64_t  size_type_max =std::numeric_limits<size_type>::max() ;
    enum{  n_bits_number = 63 };
    //void * const Ptr_Max =0xffffffffffffffffULL;
};

typedef Conf<NByte>::size_type size_type ;

//void * const PMIN = 0 ;
//void * const PMAX = std::numeric_limits<void *>::max();
//----------------------------------------------------------
//    64 bits compiler
//----------------------------------------------------------
//typedef  ptrdiff_t  node_number;
//const   node_number node_number_max = std::numeric_limits<node_number>::max() ;
//typedef size_t bitfield_t ;
//const unsigned n_bits_number = std::numeric_limits<size_t>::digits - 1;
/*
void Error ( const char *S)
{   throw std::runtime_error (S);
};
*/
}; //------------ End namespace tools ------------------------------------
}; //-------------------- End namespace cntree ----------------------------
#endif
