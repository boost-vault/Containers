///----------------------------------------------------------------------------
// FILE : debug_branch.hpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_DEBUG_BRANCH_HPP
#define __COUNTERTREE_DEBUG_BRANCH_HPP

#if __DEBUG_MODE > 1

#include <boost/countertree/tools/debug_node.hpp>
#include <boost/countertree/tools/branch.hpp>

namespace cntree
{
namespace tools 
{

//----------------------------------------------------------------
// FUNCION : operator<<
//
// DESCRIPCION : Operador de impresion para la branch
//
// PARAMETROS :
//  salida : ostream en el que vamos a imprimir
//  R : branch a imprimir
//
// PARAMETRO DEVUELTO : ostream despues de la impresion
//
// OBSERVACIONES :
//
//----------------------------------------------------------------
template <class T>
inline std::ostream & operator<<(std::ostream &salida, const branch<T> & H )
{	//------------ Inicio ------------------------
	salida<<"["<<( void*)(&H)<< "] ";
	salida<<"ppblack:"<<( void*)(H.ppblack);
	salida<<" PBlack:"<<(*H.ppblack);
	salida<<" N :"<<H.n_nodes()<<std::endl ;
	if (H.n_nodes() == 0 ) return salida ;


    node<T> *PAux = *(H.ppblack) ;
    salida<<"Black :"<<(*PAux)<<std::endl;

    if ( PAux->left != NULL and PAux->left->is_red() )
    {   PAux = PAux->left ;
        salida<<"left  :"<<( *PAux )<<std::endl;
        if ( PAux->left!= NULL and PAux->left->is_red() )
            salida<<"left->left :"<<( * PAux->left)<<std::endl;
        if ( PAux->right!= NULL and PAux->right->is_red() )
            salida<<"left->right :"<<( * PAux->right)<<std::endl;
    };
    PAux = *(H.ppblack) ;
    if ( PAux->right != NULL and PAux->right->is_red() )
    {   PAux = PAux->right ;
        salida<<"right  :"<<( *PAux )<<std::endl;
        if ( PAux->left!= NULL and PAux->left->is_red() )
            salida<<"right->left :"<<( * PAux->left)<<std::endl;
        if ( PAux->right!= NULL and PAux->right->is_red() )
            salida<<"right->right :"<<( * PAux->right)<<std::endl;
    };
 	return salida ;
};
}; // -------------------------- End namespace tools -----------------
}; // -------------------------- End  namespace cntree-------------------
#endif
#endif
