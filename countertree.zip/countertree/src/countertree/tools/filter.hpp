///----------------------------------------------------------------------------
// FILE : filter.hpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_FILTER_HPP
#define __COUNTERTREE_FILTER_HPP


#include <functional>
#include <utility>

namespace cntree
{
namespace tools
{

///----------------------------------------------------------------
// STRUCT : filter_set
//
// DESCRIPTION : This class is a filter for to extract the key from
//  the value
//  Consideer 1 value_t = 1 key_t + 1 data_t
//  Inthe set the data_t don't exist and  1 value_t = 1 key_t
//
// VARIABLES :
//
// NOTES :
//
//----------------------------------------------------------------
template <class key_t , class value_t >
struct filter_set
{   const key_t & operator () ( const value_t &V)const
    {   return V ;
    };
};

///----------------------------------------------------------------
// STRUCT : filter_map
//
// DESCRIPTION : This class is a filter for to extract the key from
//  the value
//  Consideer 1 value_t = 1 key_t + 1 data_t
//  In the map the value_t is a pair<const key_t, data_t> and  the
//  key_ is value_t.first
//
// VARIABLES :
//
// NOTES :
//
//----------------------------------------------------------------
template <class key_t , class value_t >
struct filter_map
{   const key_t & operator () ( const value_t &V)const
    {   return V.first ;
    };
};

//-------------------------------------------------------------
/// @class  CompPair
/// @brief This class is only for to provide an object to compare
///        two objects value_type (pair<const class1, class2> of
///        the map and multimap
/// @remarks It is used by the function value_comp
//----------------------------------------------------------------
template <class Key, class T , class Comp = std::less<Key> >
struct CompPair
{
    //--------------------- Definitions ----------------------
    typedef std::pair <const Key , T > value_type ;
    //--------------------- Variables-------------------------
    Comp C ;
    //--------------------- Functions ------------------------
    CompPair ( const Comp &C1 = Comp()):C(C1){} ;
    bool operator ()( const value_type &V1, const value_type &V2)
    {   return C ( V1.first, V2.first);
    };
};

}; //------------------------------- end namespace tools --------------
};//----------------------------------- end namespace cntree -----------------
#endif
