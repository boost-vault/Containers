//----------------------------------------------------------------------------
/// @file   iterator.hpp
/// @brief  This file contains the Iterator and const_iterator definition
///
/// @author Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_ITERATOR_HPP
#define __COUNTERTREE_ITERATOR_HPP

#include <boost/countertree/tools/basic_tree.hpp>
#include <iterator>

namespace cntree
{
namespace tools 
{

template <class T> class const_iterator ;

//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #                I T E R A T O R                   #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
/// @class  iterator
/// @brief  This class represent the iterators of the vector_tree structure
/// @remarks
//------------------------------------------------------------------------
template <class T>
class iterator
{
public :
//##########################################################################
//                                                                        ##
//                    D E F I N I T I O N S                               ##
//                                                                        ##
//##########################################################################
typedef typename  node<T>::pnode          pnode ;
typedef typename  node<T>::const_pnode    const_pnode   ;
typedef typename  node<T>::address_pnode  address_pnode ;
typedef typename  node<T>::rnode          rnode   ;
typedef typename  node<T>::const_rnode    const_rnode ;

typedef Conf<NByte>::size_type size_type ;
typedef T                                 value_type;
typedef size_type                         difference_type;
typedef T*                                pointer;
typedef T &                               reference;
typedef std::random_access_iterator_tag   iterator_category;

private:
//##########################################################################
//                                                                        ##
//             S P E C I A L    F U N C T I O N S                         ##
//                                                                        ##
//##########################################################################
static pnode PMIN ( void )
{   return ( pnode) 0 ;
};

static pnode PMAX ( void)
{   return (pnode) ~0 ;
} ;

//##########################################################################
//                                                                        ##
//                     V A R I A B L E S                                  ##
//                                                                        ##
//##########################################################################
pnode P ;
basic_tree<T> *BT ;

//##########################################################################
//                                                                        ##
//               P R I V A T E    F U N C T I O N S                       ##
//                                                                        ##
//       I N H E R I T E D    F R O M    B A S I C _ T R E E              ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : get_first
/// @brief Return a pointer to the first element of the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
static pnode get_first(basic_tree<T> *BT)
{   //----------------------- begin ------------------------
    pnode P ;
    if ( (P = BT->get_first() ) == NULL ) P = PMAX() ;
    return P ;
};
//------------------------------------------------------------------------
//  function : get_last
/// @brief Return a pointer to the last element of the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
static pnode get_last( basic_tree<T> *BT)
{   //----------------------- begin --------------------
    pnode P ;
    if ( (P = BT->get_last() ) == NULL ) P = PMIN() ;
    return P ;
};
//------------------------------------------------------------------------
//  function : next
/// @brief Return a pointer to the next element in the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
void next ( void)
{   //-------------------------- begin ------------------
    if ( P != PMAX() )
    {   if ( P == PMIN()) P = get_first(BT) ;
        else if ( (P = P->next()) == NULL ) P = PMAX() ;
    }
};
//------------------------------------------------------------------------
//  function : previous
/// @brief Return a pointer to the previous element in the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
void previous ( void)
{   //-------------------------- begin ------------------
    if ( P != PMIN() )
    {   if ( P == PMAX() )  P = get_last(BT) ;
        else if ( (P = P->previous()) == NULL) P = PMIN();
    };
};

//------------------------------------------------------------------------
//  function : shift
/// @brief Shift the iterator forward positions
/// @param [in] Distance : positions to go shift ( it can be negative)
/// @return none
//------------------------------------------------------------------------
void shift ( size_type Distance)
{   //--------------------- Inicio -------------------------
    if ( Distance != 0 )
    {   if (Distance > 0 )
        {   if (P == PMIN())
            {   next() ;
                --Distance ;
            };
            if ( Distance != 0 and P != PMAX() )
            {   if ((P = P->shift(Distance))== NULL ) P = PMAX();
            };
        }
        else
        {   if (P == PMAX())
            {   previous();
                ++Distance;
            };
            if ( Distance != 0 and P != PMIN())
            {   if ( (P = P->shift(Distance)) == NULL) P = PMIN() ;
            };
        };
    };
};

public :

//##########################################################################
//                                                                        ##
//   C O N S T R U C T O R    &   D E S T R U C T O R                     ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : iterator
/// @brief void constructor
/// @param [in] none
//------------------------------------------------------------------------
iterator ( void):P (PMAX()),BT(NULL){ };

//------------------------------------------------------------------------
//  function : iterator
/// @brief constructor
/// @param [in] P1 : pointer to a node
/// @param [in] BT1 : pointer to a basic_tree structure
//------------------------------------------------------------------------
iterator( pnode P1 ,basic_tree<T> *BT1):P(P1),BT(BT1)
{   //--------------------- begin -----------------------
    if ( BT == NULL) P = PMAX();
};

//##########################################################################
//                                                                        ##
//          A R I T H M E T I C    O P E R A T O R S                      ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : operator ++
/// @brief pre increment operator
/// @param [in] none
/// @return reference to the iterator incremented
//------------------------------------------------------------------------
iterator &  operator++ ( void  )
{   //--------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ("iterator::operator++");
#endif
    next() ;
    return *this ;
};
//------------------------------------------------------------------------
//  function : operator++
/// @brief post increment operator
/// @param [in] int : not used
/// @return iterator before the increment
//------------------------------------------------------------------------
iterator  operator++ ( int  )
{   //-------------- Begin ---------------
    iterator C1 ( *this);
    ++(*this) ;
    return C1 ;
};
//------------------------------------------------------------------------
//  function . operator--
/// @brief pre decrement operator
/// @param [in] none
/// @return reference to the iterator decremented
//------------------------------------------------------------------------
iterator  & operator-- ( void  )
{   //--------------------------- Begin ---------------------
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ("iterator::operator--");
#endif
    previous();
    return *this ;
};
//------------------------------------------------------------------------
//  function : operator--
/// @brief post decrement operator
/// @param [in] not used
/// @return iterator before the decrement
//------------------------------------------------------------------------
iterator  operator-- ( int  )
{   //------------------ Begin -----------------------
    iterator C1 ( *this);
    --(*this) ;
    return C1 ;
};
//------------------------------------------------------------------------
//  function : operator+=
/// @brief self addition operator
/// @param [in] Distance : number of elements to jump forward
/// @return reference to the iterator after the addition
///
/// @remarks
//------------------------------------------------------------------------
iterator & operator+= ( difference_type Distance )
{   //---------------------- Begin --------------------
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ("iterator::operator+=");
#endif
    shift ( Distance);
    return *this ;
};

//------------------------------------------------------------------------
//  function : operator-=
/// @brief self sustract operator
/// @param [in] Distance : number to elements to jump backward
/// @return reference to the iterator after the sustraction
//------------------------------------------------------------------------
iterator & operator-= ( difference_type Distance )
{   return ((*this )+= -Distance );
};
//------------------------------------------------------------------------
//  function : operator+
/// @brief Addition operator. Return the iterator shifted forward Distance
///        positions without modify the iterator
/// @param [in] Distance : Number of positions to shift ( it can be negative)
/// @return iterator

//------------------------------------------------------------------------
iterator  operator+ ( size_type Distance) const
{   iterator C1 ( *this) ;
    return ( C1+= (Distance) );
};

//------------------------------------------------------------------------
//  function : operator -
/// @brief substraction operator. Return the iterator shifted forward Distance
///        positions without modify the iterator
/// @param [in]Distance : Number of positions to shift ( it can be negative)
/// @return iterator
//------------------------------------------------------------------------
iterator  operator- ( size_type Distance)
{   iterator C1 ( *this) ;
    return ( C1-= (Distance) );
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief sustraction of two iterators
/// @param [in] I :  iterator to substract
/// @return distance between the two iterators
//------------------------------------------------------------------------
size_type operator- ( const iterator & I   )
{   //---------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if ( ptr_basic_tree() == NULL or I.ptr_basic_tree() == NULL or
         ptr_basic_tree()!= I.ptr_basic_tree() )
        throw std::invalid_argument ("iterator::operator-");
#endif
    return ( pos() - I.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief sustraction of two iterators
/// @param [in] I :  iterator to substract
/// @return distance between the two iterators
//------------------------------------------------------------------------
size_type operator- ( const const_iterator<T> & I   )
{   //---------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if ( ptr_basic_tree() == NULL or
        I.ptr_basic_tree() == NULL or
        ptr_basic_tree()!= I.ptr_basic_tree() )
        throw std::invalid_argument ("iterator::operator-");
#endif
    return ( pos() - I.pos() ) ;
};
//##########################################################################
//                                                                        ##
//          D E R E F E R E N C E D     O P E R A T O R S                 ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : operator*
/// @brief dereferenced operator
/// @param [in] none
/// @return reference to the data pointed by the iterator
//------------------------------------------------------------------------
reference operator * ( void )
{   //------------------- Begin --------------
#if __DEBUG_MODE > 0
    if ( BT == NULL or P == PMAX() or P == PMIN() )
        throw std::invalid_argument("iterator::operator *");
#endif
    return ( P->data ) ;
};

//------------------------------------------------------------------------
//  function : operator->
/// @brief dereferenced operator
/// @param [in] none
/// @return pointer to the data pointed by the iterator
//------------------------------------------------------------------------
pointer operator-> ( void )
{   //------------------- Begin --------------
#if __DEBUG_MODE > 0
    if ( BT == NULL or P == PMAX() or P == PMIN() )
        throw std::invalid_argument ("iterator::operator ->");
#endif
    return (& (P->data)) ;
};

//------------------------------------------------------------------------
//  function : pos
/// @brief return the position of the iterator in the data structure
/// @param [in] none
/// @return position
//------------------------------------------------------------------------
size_type pos ( void) const
{   //------------------------ begin -------------------
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "iterator::pos");
#endif
    if ( P == PMIN() ) return  -1 ;
    return ( P == PMAX() ) ? BT->size() : P->get_pos () ;
};

//------------------------------------------------------------------------
//  function : ptr
/// @brief return the pointer to the node pointed by the iterator
/// @param [in] none
/// @return pointer
//------------------------------------------------------------------------
pnode ptr ( void ) const
{
#if __DEBUG_MODE  > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "iterator::ptr");
#endif
    return P;
};
//------------------------------------------------------------------------
//  function : ptr_basic_tree
/// @brief return the pointer to the basic_tree contained in the iterator
/// @param [in] none
/// @return pointer
//------------------------------------------------------------------------
basic_tree<T> * ptr_basic_tree ( void ) const
{   //----------------- Inicio ----------------------
    return BT ;
};
//##########################################################################
//                                                                        ##
//                 S P E C I A L    V A L U E S                           ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : end
/// @brief return the iterator to the next position after the last in
///        the data structure
/// @param [in] none
/// @return iterator to the end
//------------------------------------------------------------------------
static iterator end (basic_tree<T> *BT)
{
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "iterator::end");
#endif
    return iterator(PMAX() ,BT);
};

//------------------------------------------------------------------------
//  function : end
/// @brief return the iterator to the next position after the last in
///        the data structure
/// @param [in] none
/// @return iterator to the end
//------------------------------------------------------------------------
static iterator end (const  iterator & V)
{   return end ( V.ptr_basic_tree());
};

//------------------------------------------------------------------------
//  function : rend
/// @brief return the iterator to the previous element to the first in
///        the data structure
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static iterator rend(basic_tree<T> *BT)
{
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "iterator::rend");
#endif
    return iterator(PMIN() ,BT);
};

//------------------------------------------------------------------------
//  function : rend
/// @brief return the iterator to the previous element to the first in
///        the data structure
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static iterator rend(const iterator &V)
{   return rend (V.ptr_basic_tree());
};

//------------------------------------------------------------------------
//  function : begin
/// @brief iterator to the first element in the data structure. If the
///        data structure is empty return end()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static iterator begin (basic_tree<T> *BT)
{
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "iterator::begin");
#endif
    return iterator(get_first(BT), BT);
};

//------------------------------------------------------------------------
//  function : begin
/// @brief iterator to the first element in the data structure. If the
///        data structure is empty return end()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static iterator begin (const iterator &V)
{   return begin ( V.ptr_basic_tree());
};

//------------------------------------------------------------------------
//  function : rbegin
/// @brief iterator to the last  element of the data structure. If the
///        data structure is empty return rend()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static iterator rbegin (basic_tree<T> *BT)
{
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument( "iterator::rbegin");
#endif
    return iterator(get_last(BT), BT);
};

//------------------------------------------------------------------------
//  function : rbegin
/// @brief iterator to the last  element of the data structure. If the
///        data structure is empty return rend()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static iterator rbegin (const iterator &V)
{   return rbegin ( V.ptr_basic_tree());
};

}; //------------------ end class iterator--------------------------------


//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #           C O N S T _ I T E R A T O R            #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
/// @class  const_iterator
/// @brief  This class represent the iterators of the vector_tree structure
/// @remarks
//------------------------------------------------------------------------

template <class T>
class const_iterator
{
public:
//##########################################################################
//                                                                        ##
//                    D E F I N I T I O N S                               ##
//                                                                        ##
//##########################################################################
typedef typename  node<T>::pnode          pnode ;
typedef typename  node<T>::const_pnode    const_pnode   ;
typedef typename  node<T>::address_pnode  address_pnode ;
typedef typename  node<T>::rnode          rnode   ;
typedef typename  node<T>::const_rnode    const_rnode ;
typedef Conf<NByte>::size_type            size_type ;
typedef const T                           value_type;
typedef size_type                         difference_type;
typedef const T*                          pointer;
typedef const T &                         reference;
typedef std::random_access_iterator_tag   iterator_category;

private:
//##########################################################################
//                                                                        ##
//             S P E C I A L    F U N C T I O N S                         ##
//                                                                        ##
//##########################################################################
static const_pnode PMIN ( void )
{   return ( const_pnode) 0 ;
};

static const_pnode PMAX ( void)
{   return (const_pnode) ~0 ;
} ;

//##########################################################################
//                                                                        ##
//                     V A R I A B L E S                                  ##
//                                                                        ##
//##########################################################################
const_pnode          P ;
const basic_tree<T> *BT ;

//------------------------------------------------------------------------
//  function : remove_const
/// @brief Generate a pnode from a const_pnode
/// @param [in] pointer to a const node
/// @return pointer to a node
//------------------------------------------------------------------------
static pnode remove_const ( const_pnode P)
{   return  const_cast < pnode>(P );
};

//##########################################################################
//                                                                        ##
//               P R I V A T E    F U N C T I O N S                       ##
//                                                                        ##
//       I N H E R I T E D    F R O M    B A S I C _ T R E E              ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : get_first
/// @brief Return a pointer to the first element of the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
static const_pnode get_first(const basic_tree<T> *BT )
{   //----------------------- begin ------------------------
    const_pnode P ;
    if ( ( P = BT->get_first() ) == NULL) P = PMAX() ;
    return P ;
};

//------------------------------------------------------------------------
//  function : get_last
/// @brief Return a pointer to the last element of the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
static const_pnode get_last(const basic_tree<T> *BT)
{   //----------------------- begin --------------------
    const_pnode P ;
    if ( (P = BT->get_last() )== NULL) P = PMIN() ;
    return P ;
};
//------------------------------------------------------------------------
//  function : next
/// @brief Return a pointer to the next element in the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
void next ( void)
{   //-------------------------- begin ------------------
    if ( P != PMAX() )
    {   if ( P == PMIN()) P = get_first(BT) ;
        else if ( (P = remove_const(P)->next()) == NULL ) P = PMAX() ;
    }
};

//------------------------------------------------------------------------
//  function : previous
/// @brief Return a pointer to the previous element in the container
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
void previous ( void)
{   //-------------------------- begin ------------------
    if ( P != PMIN() )
    {   if ( P == PMAX() ) P = get_last(BT) ;
        else if ( (P = remove_const(P)->previous()) == NULL) P = PMIN();
    };
};
//------------------------------------------------------------------------
//  function : shift
/// @brief Shift the iterator forward positions
/// @param [in] Distance : positions to go shift ( it can be negative)
/// @return none
//------------------------------------------------------------------------
void shift ( size_type Distance)
{   //--------------------- Inicio -------------------------
    if ( Distance != 0 )
    {   if (Distance > 0 )
        {   if (P == PMIN())
            {   next() ;
                --Distance ;
            };
            if ( Distance != 0 and P != PMAX() )
            {   if ((P = remove_const(P)->shift(Distance))== NULL ) P = PMAX();
            };
        }
        else
        {   if (P == PMAX())
            {   previous();
                ++Distance;
            };
            if ( Distance != 0 and P != PMIN())
            {   if ( (P = remove_const(P)->shift(Distance)) == NULL) P = PMIN() ;
            };
        };
    };
};

public :
//##########################################################################
//                                                                        ##
//   C O N S T R U C T O R    &   D E S T R U C T O R                     ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : const_iterator
/// @brief void constructor
/// @param [in] none
//------------------------------------------------------------------------
const_iterator(void):P(PMAX() ),BT(NULL){};

//------------------------------------------------------------------------
//  function : const_iterator
/// @brief constructor
/// @param [in] P1 : pointer to a node
/// @param [in] BT1 : pointer to a basic_tree structure
//------------------------------------------------------------------------
const_iterator ( const_pnode P1 ,
                    const basic_tree<T> *BT1) : P(P1),BT(BT1)
{   //-------------------------- begin -----------------------------
    if ( BT == NULL ) P = PMAX();
};
//------------------------------------------------------------------------
//  function : const_iterator
/// @brief constructor
/// @param [in] C : iterator
//------------------------------------------------------------------------
const_iterator ( const iterator<T> & C) :P(C.ptr()) ,BT(C.ptr_basic_tree()){ };


//##########################################################################
//                                                                        ##
//          A R I T H M E T I C    O P E R A T O R S                      ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : operator ++
/// @brief pre increment operator
/// @param [in] none
/// @return reference to the iterator incremented
//------------------------------------------------------------------------
const_iterator<T> &  operator++ ( void  )
{   //--------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument("const_iterator::operator++");
#endif
    next() ;
    return *this ;
};
//------------------------------------------------------------------------
//  function : operator++
/// @brief post increment operator
/// @param [in] int : not used
/// @return iterator before the increment
//------------------------------------------------------------------------
const_iterator  operator++ ( int  )
{   const_iterator C1 ( *this);
    ++(*this) ;
    return C1 ;
};
//------------------------------------------------------------------------
//  function . operator--
/// @brief pre decrement operator
/// @param [in] none
/// @return reference to the iterator decremented
//------------------------------------------------------------------------
const_iterator  & operator-- ( void  )
{   //--------------------------- Begin ---------------------
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ("const_iterator::operator--");
#endif
    previous();
    return *this ;
};
//------------------------------------------------------------------------
//  function : operator--
/// @brief post decrement operator
/// @param [in] not used
/// @return iterator before the decrement
//------------------------------------------------------------------------
const_iterator  operator-- ( int  )
{   const_iterator C1 ( *this);
    --(*this) ;
    return C1 ;
};
//------------------------------------------------------------------------
//  function : operator+=
/// @brief self addition operator
/// @param [in] Distance : number of elements to jump forward
/// @return reference to the iterator after the addition
//------------------------------------------------------------------------
const_iterator & operator+= ( size_type Distance )
{   //---------------------- Begin --------------------
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ("const_iterator::operator+=");
#endif
    shift ( Distance);
    return *this ;
};
//------------------------------------------------------------------------
//  function : operator-=
/// @brief self sustract operator
/// @param [in] Distance : number to elements to jump backward
/// @return reference to the iterator after the sustraction
//------------------------------------------------------------------------
const_iterator & operator-= ( size_type Distance )
{   return ((*this )+= -Distance );
};
//------------------------------------------------------------------------
//  function : operator+
/// @brief Addition operator. Return the iterator shifted forward Distance
///        positions without modify the iterator
/// @param [in] Distance : Number of positions to shift ( it can be negative)
/// @return iterator

//------------------------------------------------------------------------
const_iterator  operator+ ( size_type Distance) const
{   const_iterator C1 ( *this) ;
    return ( C1+= (Distance) );
};

//------------------------------------------------------------------------
//  function : operator -
/// @brief substraction operator. Return the iterator shifted forward Distance
///        positions without modify the iterator
/// @param [in]Distance : Number of positions to shift ( it can be negative)
/// @return iterator
//------------------------------------------------------------------------
const_iterator  operator - ( size_type Distance)
{   const_iterator C1 ( *this) ;
    return ( C1-= (Distance) );
};

//------------------------------------------------------------------------
//  function : operator-
/// @brief sustraction of two iterators
/// @param [in] I :  iterator to substract
/// @return distance between the two iterators
//------------------------------------------------------------------------
size_type operator- ( const iterator<T> & I   )
{   //---------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if ( ptr_basic_tree() == NULL or
        I.ptr_basic_tree() == NULL or
        ptr_basic_tree()!= I.ptr_basic_tree() )
        throw std::invalid_argument ("iterator::operator-");
#endif
    return ( pos() - I.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator-
/// @brief sustraction of two iterators
/// @param [in] I :  iterator to substract
/// @return distance between the two iterators
//------------------------------------------------------------------------
size_type operator- ( const const_iterator & I   )
{   //---------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if ( ptr_basic_tree() == NULL or
        I.ptr_basic_tree() == NULL or
        ptr_basic_tree()!= I.ptr_basic_tree() )
        throw std::invalid_argument ("iterator::operator-");
#endif
    return ( pos() - I.pos() ) ;
};
//##########################################################################
//                                                                        ##
//          D E R E F E R E N C E D     O P E R A T O R S                 ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : operator*
/// @brief dereferenced operator
/// @param [in] none
/// @return reference to the data pointed by the iterator
//------------------------------------------------------------------------
reference operator * ( void ) const
{
#if __DEBUG_MODE > 0
    if ( BT == NULL or P == PMAX() or P == PMIN() )
        throw std::invalid_argument ("const_iterator::operator ->");
#endif
    return ( P->data ) ;
};

//------------------------------------------------------------------------
//  function : operator->
/// @brief dereferenced operator
/// @param [in] none
/// @return pointer to the data pointed by the iterator
//------------------------------------------------------------------------
pointer operator-> ( void ) const
{
#if __DEBUG_MODE > 0
    if ( BT == NULL or P == PMAX() or P == PMIN() )
        throw std::invalid_argument ("const_iterator::operator ->");
#endif
    return (& (P->data));
};
//------------------------------------------------------------------------
//  function : pos
/// @brief return the position of the iterator in the data structure
/// @param [in] none
/// @return position
//------------------------------------------------------------------------
size_type pos ( void) const
{   //------------------------ begin -------------------
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "const_iterator::pos");
#endif
    if ( P == PMIN() ) return -1 ;
    return ( P == PMAX() ) ? BT->size() : P->get_pos () ;
};
//------------------------------------------------------------------------
//  function : ptr
/// @brief return the pointer to the node pointed by the iterator
/// @param [in] none
/// @return pointer
//------------------------------------------------------------------------
const_pnode ptr ( void ) const
{
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "const_iterator::ptr");
#endif
    return P;
};
//------------------------------------------------------------------------
//  function : ptr_basic_tree
/// @brief return the pointer to the basic_tree contained in the iterator
/// @param [in] none
/// @return pointer
//------------------------------------------------------------------------
const basic_tree<T> * ptr_basic_tree ( void ) const
{   //----------------- Inicio ----------------------
    return BT ;
};

//##########################################################################
//                                                                        ##
//                 S P E C I A L    V A L U E S                           ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : end
/// @brief return the iterator to the next position after the last in
///        the data structure
/// @param [in] none
/// @return iterator to the end
//------------------------------------------------------------------------
static const_iterator end (const basic_tree<T> *BT )
{
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "const_iterator::end");
#endif
    return const_iterator(PMAX(),BT);
};

//------------------------------------------------------------------------
//  function : end
/// @brief return the iterator to the next position after the last in
///        the data structure
/// @param [in] none
/// @return iterator to the end
//------------------------------------------------------------------------
static const_iterator end (const const_iterator & V)
{   return end(V.ptr_basic_tree() );
};

//------------------------------------------------------------------------
//  function : rend
/// @brief return the iterator to the previous element to the first in
///        the data structure
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static const_iterator rend(const basic_tree<T> *BT)
{
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "const_iterator::rend");
#endif
    return const_iterator(PMIN(),BT);
};

//------------------------------------------------------------------------
//  function : rend
/// @brief return the iterator to the previous element to the first in
///        the data structure
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static const_iterator rend(const const_iterator & V)
{   return rend ( V.ptr_basic_tree());
};

//------------------------------------------------------------------------
//  function : begin
/// @brief iterator to the first element in the data structure. If the
///        data structure is empty return end()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static const_iterator<T> begin (const basic_tree<T> *BT)
{
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "const_iterator::begin");
#endif
    return const_iterator(get_first(BT), BT);
};

//------------------------------------------------------------------------
//  function : begin
/// @brief iterator to the first element in the data structure. If the
///        data structure is empty return end()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static const_iterator<T> begin (const const_iterator & V)
{   return begin ( V.ptr_basic_tree());
};

//------------------------------------------------------------------------
//  function : rbegin
/// @brief iterator to the last  element of the data structure. If the
///        data structure is empty return rend()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static const_iterator<T> rbegin (const basic_tree<T> *BT)
{
#if __DEBUG_MODE > 0
    if ( BT == NULL )
        throw std::invalid_argument ( "const_iterator::rbegin");
#endif
    return const_iterator(get_last(BT), BT);
};

//------------------------------------------------------------------------
//  function : rbegin
/// @brief iterator to the last  element of the data structure. If the
///        data structure is empty return rend()
/// @param [in] none
/// @return iterator
//------------------------------------------------------------------------
static const_iterator<T> rbegin (const const_iterator & V)
{   return rbegin ( V.ptr_basic_tree());
};

};
// -----------------------------------------------------------------------
//                 end class const_iterator
//-------------------------------------------------------------------------


//##########################################################################
//                                                                        ##
//                                                                        ##
//              E X T E R N A L       O P E R A T O R S                   ##
//                                                                        ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : operator ==
/// @brief equality operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <class Iterator1, class Iterator2>
bool operator == (const Iterator1 &C1, const Iterator2 &C2 )
{   return (C1.ptr_basic_tree()==C2.ptr_basic_tree() and C1.ptr()==C2.ptr());
};

//------------------------------------------------------------------------
//  function : operator !=
/// @brief inequality operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <class Iterator1, class Iterator2>
bool operator != (const Iterator1 &C1, const Iterator2 &C2 )
{   return not( C1 == C2);
};

//------------------------------------------------------------------------
//  function : operator <
/// @brief less than  operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <class Iterator1, class Iterator2>
bool operator < (const Iterator1 &C1, const Iterator2 &C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if (C1.ptr_basic_tree() == NULL or
        C2.ptr_basic_tree() == NULL or
        C1.ptr_basic_tree()!= C2.ptr_basic_tree() )
        throw std::invalid_argument ("iterator::operator-");
#endif
    return ( C1.pos() < C2.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator >
/// @brief less than  operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <class Iterator1, class Iterator2>
bool operator > (const Iterator1 &C1, const Iterator2 &C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if (C1.ptr_basic_tree() == NULL or
        C2.ptr_basic_tree() == NULL or
        C1.ptr_basic_tree()!= C2.ptr_basic_tree() )
        throw std::invalid_argument ("iterator::operator-");
#endif
    return ( C1.pos() > C2.pos() ) ;
};

//------------------------------------------------------------------------
//  function : operator <=
/// @brief less than  operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <class Iterator1, class Iterator2>
bool operator <= (const Iterator1 &C1, const Iterator2 &C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if (C1.ptr_basic_tree() == NULL or
        C2.ptr_basic_tree() == NULL or
        C1.ptr_basic_tree()!= C2.ptr_basic_tree() )
        throw std::invalid_argument ("iterator::operator-");
#endif
    return ( C1.pos() <= C2.pos() ) ;
};
//------------------------------------------------------------------------
//  function : operator >=
/// @brief less than  operator
/// @param [in] C1 : iterator to compare
/// @param [in] C2 : iterator to compare
/// @return true: equals false : not equals
//------------------------------------------------------------------------
template <class Iterator1, class Iterator2>
bool operator >= (const Iterator1 &C1, const Iterator2 &C2 )
{   //---------------------- Begin --------------------------
#if __DEBUG_MODE > 0
    if (C1.ptr_basic_tree() == NULL or
        C2.ptr_basic_tree() == NULL or
        C1.ptr_basic_tree()!= C2.ptr_basic_tree() )
        throw std::invalid_argument ("iterator::operator-");
#endif
    return ( C1.pos() >= C2.pos() ) ;
};

}; //----------------------- end namespace tools ---------------------------
}; //---------------------- end namespace cntree ----------------------------
#endif
