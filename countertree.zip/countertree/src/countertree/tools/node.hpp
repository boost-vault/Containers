//----------------------------------------------------------------------------
/// @file   node.hpp
/// @brief  This file contains the implementation of the node in the countertree
///         data structure
///
/// @author Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )\n
///         Distributed under the Boost Software License, Version 1.0.\n
///         ( See accompanyingfile LICENSE_1_0.txt or copy at
///           http://www.boost.org/LICENSE_1_0.txt  )
/// @version 0.1
///
/// @remarks
//-----------------------------------------------------------------------------
#ifndef __COUNTERTREE_NODE_HPP
#define __COUNTERTREE_NODE_HPP

#include <stdexcept>
#include <boost/countertree/tools/config.hpp>


namespace cntree
{
namespace tools
{
//##########################################################################
//                                                                        ##
//       ####################################################             ##
//       #                                                  #             ##
//       #           C L A S S        N O D E               #             ##
//       #                                                  #             ##
//       ####################################################             ##
//                                                                        ##
//##########################################################################

//-------------------------------------------------------------
/// @class  node
/// @brief  This class represent a node of the tree
//
/// @remarks
//----------------------------------------------------------------
template <class T>
struct node
{
//##########################################################################
//                                                                        ##
//                    D E F I N I T I O N S                               ##
//                                                                        ##
//##########################################################################
typedef        node*  pnode ;
typedef  const node*  const_pnode ;
typedef        node** address_pnode ;
typedef        node&  rnode ;
typedef  const node&  const_rnode ;
typedef  Conf<NByte>::size_type size_type ;
typedef Conf<NByte>::bitfield_t  bitfield_t ;


//##########################################################################
//                                                                        ##
//                       V A R I A B L E S                                ##
//                                                                        ##
//##########################################################################
pnode left ;
pnode right ;
pnode up ;
bitfield_t  N : Conf<NByte>::n_bits_number ;
unsigned color :1;
T data ;

//##########################################################################
//                                                                        ##
//        C O N S T R U C T O R , D E S T R U C T O R                     ##
//                                                                        ##
//             O P E R A T O R = , I N I T                                ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : node
/// @brief Constructor
/// @param [in] DT : Value to copy in the node. By default the empty
///                  constructor of the value
//------------------------------------------------------------------------
node ( const T &Dt = T()) :
left(NULL),right(NULL),up(NULL),N(1), color(1),data(Dt)
{
};

//------------------------------------------------------------------------
//  function : node
/// @brief Copy constructor. We copy the data, color and counter, but
///        don't copy the pnodes
/// @param [in] N1 : reference const  to the object to be copied
//------------------------------------------------------------------------
node ( const_rnode N1 ):
left(NULL),right(NULL),up(NULL),N(N1.N), color(N1.color),data(N1.data)
{
};

//------------------------------------------------------------------------
//  function :~node
/// @brief Destructor of the class
//------------------------------------------------------------------------
~node( void)
{   left = right= up = NULL;
};

//------------------------------------------------------------------------
//  function : operator=
/// @brief Asignation operator
/// @param [in] Nd : node to be copied
/// @return reference to the object after the copy
/// @remarks This function copy the data, color and counter , but don't
///          copy the pnodes
//------------------------------------------------------------------------
rnode operator = ( const_rnode Nd)
{   N= Nd.N ;
    color = Nd.color;
    data= Nd.data;
    return *this ;
};

//------------------------------------------------------------------------
//  function : init
/// @brief Initialize the node, but don't modify the data
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
void init ( void )
{   left =right=up=NULL;
    N = 1 ;
    set_red() ;
};
//------------------------------------------------------------------------
//  function : remove_const
/// @brief Generate a pnode from a const_pnode
/// @param [in] none
/// @return Pointer
//------------------------------------------------------------------------
pnode remove_const ( void) const
{   return  const_cast < pnode>(this );
};

//##########################################################################
//                                                                        ##
//                         C O L O R                                      ##
//                                                                        ##
//  I S _ B L A C K , I S _ R E D , S E T _ B L A C K , S E T _ R E D     ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : is_black
/// @brief Indicate if the node color is black
/// @param [in] none
/// @return bool
//------------------------------------------------------------------------
bool is_black  ( void ) const
{   return ( color == 1 );
};

//------------------------------------------------------------------------
//  function : is_red
/// @brief Indicate if the node color is red
/// @param [in] none
/// @return bool
//------------------------------------------------------------------------
bool is_red    ( void ) const
{   return ( color == 0 );
};

//------------------------------------------------------------------------
//  function : set_black
/// @brief Set the node color to black
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
void set_black ( void )
{   color = 1 ;
};

//------------------------------------------------------------------------
//  function : set_red
/// @brief Set the node color to red
/// @param [in] none
/// @return none
//------------------------------------------------------------------------
void set_red   ( void )
{   color = 0 ;
};
//##########################################################################
//                                                                        ##
//                          J U M P S                                     ##
//                                                                        ##
//            P R E V I O U S , N E X T , S H I F T                       ##
//                                                                        ##
//##########################################################################
//------------------------------------------------------------------------
//  function : previous
/// @brief Obtain the pnode to the previous node. If don't exist return NULL
/// @param [in] none
/// @return Pointer to the node.
/// @remarks This operation is O ( log N )
//------------------------------------------------------------------------
pnode  previous  ( void )
{   //------------------------- Inicio ---------------------------
    pnode P = this ;

    //-------------------------------------------------------------------
    // Primero tratamos de buscarlo hacia abajo. Si no fuera así , lo
    // buscamos hacia arriba
    //-------------------------------------------------------------------
    if ( left != NULL )
    {   P = left ;
        while ( P->right != NULL ) P = P->right ;
    }
    else
    {   //---------------------------------------------------------------
        // Subir por la dcha todo lo que puedas y luego un salto hacia
        // arriba a la izda
        // Si no es posible saltar a la left devuelve NULL, porque no
        // tiene nada posterior
        //---------------------------------------------------------------
        while ( P->up != NULL and P->up->left == P ) P = P->up ;
        P =( P->up != NULL and P->up->right != P ) ?NULL :P->up ;
    };
    return P ;
};

//------------------------------------------------------------------------
//  function : next
/// @brief Obtain the pnode of the next node. If don't exist return NULL
/// @param [in] none
/// @return pnode
/// @remarks This operation is O ( log N )
//------------------------------------------------------------------------
pnode next ( void )
{   //---------------------- Inicio ------------------------------
    pnode P = this ;

    //-------------------------------------------------------------------
    // Primero tratamos de buscarlo hacia abajo. Si no fuera así , lo
    // buscamos hacia arriba
    //-------------------------------------------------------------------
    if ( right != NULL )
    {   P = right;
        while ( P->left != NULL ) P = P->left ;
    }
    else
    {   //----------------------------------------------------------------
        // Subir todo lo que puedas por la left, y luego un salto hacia
        // arriba hacia la dcha
        // Si no puede saltar a la dcha devuelve NULL, porque no tiene
        // nodo posterior
        //----------------------------------------------------------------
        while (P->up != NULL and P->up->right == P) P= P->up;
        P= ( P->up != NULL and P->up->left == P) ?  P->up :NULL;
    };
    return P;
};

//------------------------------------------------------------------------
//  function : shift
/// @brief Obtain the pnode of the node located several positions
///        after or before the node
/// @param [in] NDesp : Number of positions to shift. This value can be
///                     positive  or negative
/// @return Pointer to the node. If don't exist return NULL
/// @remarks This operation is O ( log N )
//------------------------------------------------------------------------
pnode shift ( size_type NDesp )
{   //-------------------------Inicio -----------------------------------
    pnode P = this ;
    if ( NDesp == 0 ) return P;
    while ( NDesp != 0)
    {   if (NDesp > 0 )
        {   //---------------------------------------------------------------
            //               Desplazamiento hacia adelante
            // Trata de bajar por la right. Lo máximo que puede avanzar por
            // ese camino está determinado por el contador del nodo a su dcha.
            // Si esto no fuera suficiente, emprende el camino hacia el nodo
            // superior. Si este no existiera quiere decir que no puede
            // alcanzar ese desplazamiento por lo que devuelve NULL
            //----------------------------------------------------------------
            if ( NDesp > (size_type)(P->n_right()) )
            {   if ( P->up == NULL ) return NULL ;
                if ( P->up->right == P ) NDesp += P->n_left() + 1;
                else                     NDesp -= P->n_right() + 1;
                P = P->up ;
            }
            else
            {   //-------------------------------------------------
                //           Bajada por la right
                //-------------------------------------------------
                P = P->right ;
                NDesp -= P->n_left() +1 ;
            };
        }
        else
        {   //---------------------------------------------------------------
            //                 Desplazamiento hacia atrás
            // Trata de bajar por la left. Lo máximo que puede retroceder por
            // ese camino está determinado por el contador del nodo a su izda.
            // Si esto no fuera suficiente, emprende el camino hacia el nodo
            // superior. Si este no existiera quiere decir que no puede
            // alcanzar ese desplazamiento por lo que devuelve NULL
            //--------------------------------------------------------------
            if ( -NDesp > (size_type)(P->n_left()) )
            {   if ( P->up == NULL ) return NULL ;
                if ( P->up->right == P ) NDesp += P->n_left () + 1;
                else                     NDesp -= P->n_right () + 1;
                P = P->up ;
            }
            else
            {   //-----------------------------------------------------------
                //               Bajada por la left
                //----------------------------------------------------------
                P = P->left ;
                NDesp += P->n_right() +1 ;
            };
        };
    }; // Fin while
    return P;
};

//##########################################################################
//                                                                        ##
//                G E T T I N G   I N F O R M A T I O N                   ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : get_pos
/// @brief Get the position of the node in the tree structure
/// @param [in] none
/// @return Position in the structure
/// @remarks This operation is O ( log N )
//------------------------------------------------------------------------
size_type get_pos ( void ) const
{   //----------------------- Inicio -----------------------------
    const_pnode P1 = up;
    const_pnode P = this ;
    size_type Pos = P->n_left () ;
    while ( P1 != NULL)
    {   if ( P == P1->right ) Pos += P1->n_left() +1 ;
        P = P1 ;
        P1 = P1->up ;
    };
    return Pos ;
};

//------------------------------------------------------------------------
//  function :n_left
/// @brief Counter of the node linked by the left pnode. If the left
///        pnode is NULL return 0
/// @param [in] none
/// @return Number of nodes
/// @remarks
//------------------------------------------------------------------------
size_type n_left ( void )const
{   return (left == NULL) ? 0 : left->N ;
};

//------------------------------------------------------------------------
//  function : n_right
/// @brief Counter of the node linked by the right pnode. If the right
///        pnode is NULL return 0
/// @param [in]
/// @return Number of nodes
/// @remarks
//------------------------------------------------------------------------
size_type n_right ( void )const
{   return (right == NULL) ? 0 : right->N ;
};

//------------------------------------------------------------------------
//  function : nd
/// @brief Counter of a node pointed by P. If P is NULL return 0
/// @param [in] P : pnode to the node to exam
/// @return Counter of the node
/// @remarks
//------------------------------------------------------------------------
static size_type nd( const_pnode P)
{   return ( P == NULL)?0:P->N;
};

//##########################################################################
//                                                                        ##
//                S W A P P I N G   N O D E S                             ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function : swap_node
/// @brief Swap two nodes. They can't be contiguous
/// @param [in] PP1 : Pointer to the pnode to the first node
/// @param [in] PP2 : Pointer to the pnode to the second node
/// @return none
/// @remarks
//------------------------------------------------------------------------
static void swap_node ( address_pnode PP1, address_pnode PP2)
{   //------------------------------- Inicio ---------------------
#if __DEBUG_MODE > 0
    if ( PP1 == NULL or PP2 == NULL or *PP1 == NULL or *PP2 == NULL)
        throw std::invalid_argument("node::swap_node");
#endif
    //-------------------------------------------------------------
    pnode P1 = *PP1 ;
    pnode P2 = *PP2 ;
    *PP1 = P2 ;
    *PP2 = P1 ;

    //------------------------ up ----------------------------
    std::swap ( P1->up ,  P2->up) ;

    std::swap ( P1->left , P2->left);
    if ( P1->left != NULL) P1->left->up = P1 ;
    if ( P2->left != NULL) P2->left->up = P2 ;

    std::swap ( P1->right , P2->right);
    if ( P1->right != NULL) P1->right->up = P1 ;
    if ( P2->right != NULL) P2->right->up = P2 ;

    //------------------------ color -------------------
    unsigned color1 = P1->color ;
    P1->color  = P2->color ;
    P2->color = color1 ;

    //-------------------------- N -------------------------
    bitfield_t N1 = P1->N ;
    P1->N = P2->N ;
    P2->N = N1 ;
};
//------------------------------------------------------------------------
//  function :swap_contiguous_left
/// @brief Swap two nodes contiguous by the left pnode of the upper
///        node.
/// @param [in][out] PPup : address of the pnode to the upper node\n
///                         When finish the function PPup contains the
///                         address  to the new upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
static void swap_contiguous_left ( address_pnode PPup)
{   //------------------------------ Inicio -----------------------
#if __DEBUG_MODE > 0
    if (PPup == NULL or *PPup == NULL or
        (*PPup)->left == NULL or (*PPup)->left->right != NULL  )
        throw std::invalid_argument ("node::swap_contiguous_left");
#endif
    //--------------------------------------------------------------
    pnode Pup = *PPup ;
    pnode PInf = Pup->left ;

    // ----------- Actualizacion de PPup y Pup ---------------------
    (*PPup ) = PInf ;
    PInf->up = Pup->up ;
    //----------------------- left ---------------------
    Pup->left = PInf->left ;
    if ( Pup->left != NULL ) Pup->left->up = Pup ;

    PInf->left = Pup ;
    Pup->up = PInf ;
    //------------------------ right --------------------
    PInf->right = Pup->right ;
    if ( PInf->right != NULL) PInf->right->up = PInf ;
    Pup->right = NULL ;

    //------------------------ color -------------------
    unsigned color1 = Pup->color ;
    Pup->color  = PInf->color ;
    PInf->color = color1 ;

    //-------------------------- N -------------------------
    bitfield_t N1 = Pup->N ;
    Pup->N = PInf->N ;
    PInf->N = N1 ;
};
//##########################################################################
//                                                                        ##
//                       R O T A T I O N S                                ##
//                                                                        ##
//##########################################################################

//------------------------------------------------------------------------
//  function :rotate_left_aligned
/// @brief rotate to the left two or three nodes aligned
/// @param [in]PPup : pnode to the pnode to the upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
static void rotate_left_aligned    ( address_pnode PPup )
{   //---------------------- Inicio ------------------------
    pnode PBlack ;
    pnode P1;
#if __DEBUG_MODE > 0
    if (PPup==NULL or (PBlack=*PPup)==NULL or (P1=PBlack->right)==NULL)
        throw std::invalid_argument ("node::rotate_left_aligned");
#else
    PBlack=*PPup ;
    P1=PBlack->right;
#endif
    //---------------- Asignaciones -------------------------------
    (*PPup) = P1 ;
    P1->up = PBlack->up ;
    PBlack->up = P1 ;
    P1->N = PBlack->N ;
    PBlack->N -= ( P1->n_right() +1 ) ;
    PBlack->right = P1->left ;
    if ( P1->left != NULL ) P1->left->up = PBlack ;
    P1->left = PBlack ;
};


//------------------------------------------------------------------------
//  function :rotate_left_not_aligned
/// @brief rotate three nodes not aligned to the left
/// @param [in] PPup : address of the pnode to the upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
static void rotate_left_not_aligned ( address_pnode PPup )
{   //---------------------- Inicio -------------------------------
    pnode PBlack;
    pnode P1 ;
    pnode P2;
#if __DEBUG_MODE > 0
    if ( PPup == NULL or (PBlack = *PPup)== NULL or
        (P1 = PBlack->right) == NULL or (P2 = P1->left) == NULL )
        throw std::invalid_argument ("node::rotate_left_not_aligned");
#else
    PBlack = *PPup ;
    P1 = PBlack->right ;
    P2 = P1->left ;
#endif
    //-------------------------- Asignaciones -----------------------
    pnode A = P2->left ;
    pnode B = P2->right;
    pnode C = P1->right;
    pnode D = PBlack->left ;
    (*PPup) = P2 ;
    P2->up = PBlack->up ;
    PBlack->up = P1->up = P2 ;
    P2->N = PBlack->N;
    P2->left = PBlack ;
    P2->right = P1 ;
    PBlack->right = A ;
    if ( A != NULL ) A->up = PBlack ;
    PBlack->N = nd(D) + nd(A) + 1 ;
    P1->left = B ;
    if ( B != NULL ) B->up = P1 ;
    P1->N = nd(B) + nd(C) + 1 ;
};

//------------------------------------------------------------------------
//  function :rotate_right_aligned
/// @brief Rotate two or three aligned nodes to the right
/// @param [in] PPup : address of the pnode to the upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
static void rotate_right_aligned   (address_pnode PPup )
{   //----------------------- Inicio ---------------------------------
    pnode PBlack ;
    pnode P1 ;
#if __DEBUG_MODE > 0
    if(PPup==NULL or (PBlack=*PPup)== NULL or (P1=PBlack->left)==NULL)
        throw std::invalid_argument("node::rotate_right_aligned");
#else
    PBlack=*PPup ;
    P1=PBlack->left ;
#endif
    //------------------------ Asignaciones --------------------------
    (*PPup)  = P1 ;
    P1->up = PBlack->up ;
    PBlack->up = P1 ;
    P1->N = PBlack->N ;
    PBlack->N -= ( P1->n_left() + 1 ) ;
    PBlack->left = P1->right ;
    if ( P1->right != NULL ) P1->right->up = PBlack;
    P1->right = PBlack ;
};

//------------------------------------------------------------------------
//  function :rotate_right_not_aligned
/// @brief Rotate to the right 3 nodes not aligned
/// @param [in] PPup : address to the pnode to the upper node
/// @return none
/// @remarks
//------------------------------------------------------------------------
static void rotate_right_not_aligned ( address_pnode PPup )
{   //----------------- Inicio ----------------------------------
    node<T> *PBlack ,*P1  , *P2;
#if __DEBUG_MODE > 0
    if ( PPup == NULL or (PBlack = *PPup) == NULL or
        (P1 = PBlack->left) == NULL or (P2 = P1->right) == NULL )
        throw std::invalid_argument ("node::rotate_right_not_aligned");
#else
    PBlack = *PPup ;
    P1 = PBlack->left ;
    P2 = P1->right ;
#endif
    //----------------------- Asignaciones -------------------------
    node<T> *A = P1->left,*B = P2->left, *C = P2->right, *D = PBlack->right ;
    (*PPup) = P2 ;

    P2->up = PBlack->up ;
    PBlack->up = P1->up = P2 ;
    P2->N = PBlack->N ;
    P2->left = P1 ;
    P2->right = PBlack ;
    P2->set_black() ;
    P1->right = B ;
    if ( B != NULL ) B->up = P1 ;
    P1->N = nd(A) + nd(B) + 1;
    PBlack->left = C ;
    if ( C != NULL) C->up = PBlack ;
    PBlack->N = nd(C) + nd(D)+1 ;
    PBlack->set_red() ;
};

}; //------------------------ Fin clase node ----------------------

}; //---------------------- end namespace tools ---------------------------------
}; //---------------------- end namespace cntree --------------------------------
#endif
