///----------------------------------------------------------------------------
// FILE : Testbranch_01.cpp
//
// DESCRIPTION : This is a test program of the class branch
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <boost/countertree/tools/debug_branch.hpp>


using namespace std ;
using namespace cntree::tools;

int main ( void)
{   //------------------------ Inicio ----------------------------------
    {   //---------------------------------------------------------------
        // PRUEBAS DE INSERCION; SUPRESION; Y ROTACIONES
        //---------------------------------------------------------------
        //------------- Inicio -------------------
	    node <int> N[20] ;
	    node<int> * PAux = NULL;

	    //------------- Cargamos valores en los nodes -------------
	    for ( uint32_t  i = 0 ; i < 20 ; i ++ ) N[i].data = i ;

	    cout<<"---------------------------------------------------------\n";
	    cout<<"          INSERTION OF 3 nodes\n";
	    cout<<"---------------------------------------------------------\n";
	    cout<<"Insertion of 3 nodes in V inverted ( 1, 0 ,2)----------------->"<<endl;
	    node<int> *Padre1 = &N[0] ;
	    N[0].N = 2 ;
	    N[0].set_black();
	    branch <int> H1( &Padre1)  ;
	    H1.insert_node ( &N[1], 0 ) ;
	    N[0].N = 3 ;
	    H1.insert_node ( &N[2] ,1) ;
	    cout<<H1<<endl;

	    cout<<"Insertion of 3 nodes left aligned ( 5 , 4 , 3)---------------->"<<endl;
	    node<int> *Padre2 = &N[3] ;
	    branch <int> H2(& Padre2)  ;
	    N[3].N = 2 ;
	    N[3].set_black() ;
	    H2.insert_node ( &N[4], 0 ) ;
	    N[3].N = 3 ;
	    N[4].N = 2 ;
	    H2.insert_node ( &N[5] ,2) ;
	    cout<<H2<<endl;

	    cout<<"Insertion of 3 nodes right aligned (6,7,8)---------------->"<<endl;
	    node<int> *Padre3 = &N[6] ;
	    branch <int> H3( &Padre3)  ;
	    N[6].N = 2;
	    N[6].set_black() ;
	    H3.insert_node ( &N[7], 1 ) ;
	    N[6].N = 3;
	    N[7].N = 2 ;
	    H3.insert_node ( &N[8] ,5) ;
	    cout<<H3<<endl;

	    cout<<"Insertion of 3 nodes not aligned to the left( 10 ,11, 9 )---------------->"<<endl;
	    node<int> *Padre4 = &N[9] ;
	    branch <int> H4( &Padre4)  ;
	    N[9].N = 2 ;
	    H4.insert_node ( &N[10], 0 ) ;
	    N[10].N = 2 ;
	    N[9].N = 3 ;
	    H4.insert_node ( &N[11] ,3) ;
	    cout<<H4<<endl;

	    cout<<"Insercion de 3 nodes no alineados a la dcha (12, 14 , 13 )---------------->"<<endl;
	    node<int> *Padre5 = &N[12] ;
	    branch <int> H5( &Padre5)  ;
	    N[12].N = 2 ;
	    H5.insert_node ( &N[13], 1 ) ;
	    N[12].N = 3 ;
	    N[13].N = 2 ;
	    H5.insert_node ( &N[14] ,4) ;
	    cout<<H5<<endl;

	    cout<<"---------------------------------------------------------\n";
	    cout<<"          INSERCIONES DE 4 nodes\n";
	    cout<<"---------------------------------------------------------\n";
	    cout<<"Insercion de 4 nodes (15,1,0,2)-------------------------->\n";
	    N[0].N++ ;
	    N[1].N++ ;
	    H1.insert_node( &N[15] ,2 ) ;
	    cout<<H1<<endl;


	    cout<<"Insercion de 4 nodes (5,16,4,3)-------------------------->\n";
	    N[4].N++ ;
	    N[5].N++ ;
	    H2.insert_node( &N[16] ,3 ) ;
	    cout<<H2<<endl;

	    cout<<"Insercion de 4 nodes (6,7,17,8)-------------------------->\n";
	    N[7].N++ ;
	    N[8].N++ ;
	    H3.insert_node( &N[17] ,4 ) ;
	    cout<<H3<<endl;

	    cout<<"Insercion de 4 nodes (10,11,9,18)-------------------------->\n";
	    N[11].N++ ;
	    N[9].N ++ ;
	    H4.insert_node( &N[18] ,5 ) ;
	    cout<<H4<<endl;

	    cout<<"---------------------------------------------------------\n";
	    cout<<"          DESCONECTAR nodes\n";
	    cout<<"---------------------------------------------------------\n";
        for ( uint32_t  i = 0 ; i < 20 ; i ++ )
        {   N[i].init() ;
            N[i].data = i ;
        };
        //------------------------------------------------------------------
        cout<<"--------------------------------------------------------------\n";
        N[0].init();
        N[1].init();
        N[2].init() ;
        N[0].N = 2 ;
	    N[0].set_black();
	    H1.insert_node ( &N[1], 0 ) ;
	    N[0].N = 3 ;
	    H1.insert_node ( &N[2] ,1) ;

	    cout<<H1<<endl;

	    cout<<"Hoja de 3 nodes->Disconnect cod 2 ->"<<endl;
	    N[0].N = 2 ;
	    if ( H1.disconnect_node( 2, PAux )  != true )  cout<<"HojaVacia \n";
	    else                                           cout<<(* PAux)<<endl<<endl;
	    cout<<H1<<endl;

	    cout<<"Hoja de 2 nodes->Disconnect cod 4 ->"<<endl;
	    N[0].N = 1 ;
	    if ( H1.disconnect_node( 4, PAux )  != true )  cout<<"HojaVacia \n";
	    else                                           cout<<(*PAux)<<endl<<endl;
	    cout<<H1<<endl;

	    //-------------------------------------------------------------------
	    cout<<"--------------------------------------------------------------\n";
	    N[0].init();
	    N[1].init();
	    N[2].init();

        N[0].N = 2 ;
	    N[0].set_black();
	    H1.insert_node ( &N[1], 0 ) ;
	    N[0].N = 3 ;
	    H1.insert_node ( &N[2] ,1) ;
	    cout<<H1<<endl;

	    cout<<"Hoja de 3 nodes->Disconnect cod 4 ->"<<endl;
	    N[0].N = 2 ;
	    if ( H1.disconnect_node( 4, PAux )  != true )  cout<<"HojaVacia \n";
	    else                                           cout<<(*PAux)<<endl<<endl;
	    cout<<H1<<endl;

	    cout<<"Hoja de 2 nodes->Disconnect cod 2 ->"<<endl;
	    N[0].N = 1 ;
	    if ( H1.disconnect_node( 2, PAux )  != true )  cout<<"HojaVacia \n";
	    else                                           cout<<(*PAux)<<endl<<endl;
	    cout<<H1<<endl;

	    //------------------------------------------------------------------------
	    cout<<"--------------------------------------------------------------\n";
	    N[0].init();
	    N[1].init();
	    N[2].init();

        N[0].N = 2 ;
	    N[0].set_black();
	    H1.insert_node ( &N[1], 0 ) ;
	    cout<<H1<<endl;

	    cout<<"Hoja de 2 nodes->Disconnect cod 0 ->"<<endl;
	    N[0].N = 1 ;
	    if ( H1.disconnect_node( 0, PAux )  != true )  cout<<"HojaVacia \n";
	    else                                           cout<<(*PAux)<<endl<<endl;
	    cout<<H1<<endl;

	    cout<<"--------------------------------------------------------------\n";
	    N[0].init();
	    N[1].init();
	    N[2].init();

        N[0].N = 2 ;
	    N[0].set_black();
	    H1.insert_node ( &N[2], 1 ) ;
	    cout<<H1<<endl;

	    cout<<"Hoja de 2 nodes->Disconnect cod 0 ->"<<endl;
	    N[0].N = 1 ;
	    if ( H1.disconnect_node( 0, PAux )  != true )  cout<<"HojaVacia \n";
	    else                                           cout<<(*PAux)<<endl<<endl;
	    cout<<H1<<endl;

	    cout<<"Hoja de 1 node->Disconnect cod 0 ->"<<endl;
	    N[0].N = 1 ;
	    if ( H1.disconnect_node( 0, PAux )  != true )  cout<<"HojaVacia \n";
	    else                                           cout<<(*PAux)<<endl<<endl;
	    cout<<H1<<endl;
/*
	    cout<<endl<<H5<<endl<<endl ;
	    N[12].N-- ;
	    N[14].N-- ;
	    if ( H5.disconnect_node( 2, PAux )  != true )  cout<<"HojaVacia \n";
	    else                                           cout<<(*PAux)<<endl;
	    cout<<endl<<H5<<endl;


	    //H1.insert_node ( &N[3],3 ) ;
	    //cout<<H1<<endl;

        //if (H1.disconnect_node(2 , PAux )  )
        //    cout<<H1<<endl;
        //else cout<<"Desconexion erronea\n";
        //Rotacion dcha
        //H1.RotarDcha() ;
        //cout<<H1 <<endl ;

        //Rotacion a la izda
        //H1.RotarIzda() ;
        //cout<<H1<<endl ;


        //Suprimimos los 4 nodes
//        node<int > *PAux ;
//        unsigned PosPtr ;
//        for ( i  = 0 ; i < 4 ; i ++ )
//            R1.Suprimirnode( 2 , NULL, PAux, PosPtr ) ;
//        cout<<R1;
*/
    }
/*
    {   //---------------------------------------------------------------
        // PRUEBAS DE PROMOCION Nº 1
        //----------------------------------------------------------------
        cout<<"********* PRUEBAS DE PROMOCION  1***********************\n";
        branch <int> RP, RI , RD ;
        node<int> * Padre1 ;
        node<int > N[4] ;
        unsigned i ;
        // Cargamos valores en los nodes
        for ( i = 0 ; i < 4 ; i ++ ) N[i].Valor = i * 100 + 100 ;
        RI.PPadre = &Padre1 ;
        RI.Insertanode ( 2 , &N[0] ) ;
	    RI.Insertanode ( 3 , &N[1] ) ;
	    RI.Insertanode ( 4 , &N[2] ) ;
	    RI.Insertanode ( 4 , &N[3] ) ;
        RP.PPadre = &Padre1 ;
        RP.Promocion ( 2 , RI ) ;
        cout<<"Padre\n";
        cout<<RP<<endl;
        cout<<"branch Izda\n";
        cout<<RI;
        cout <<"branch dcha \n";
        RD = branch<int> ( RP.PNd[2]->Dcha ) ;
        cout<<RD ;
    }
    {   //---------------------------------------------------------------
        // PRUEBAS DE PROMOCION Nº 2
        //----------------------------------------------------------------
        cout<<"********* PRUEBAS DE PROMOCION  2***********************\n" ;
        branch<int> RP, RI ,RM, RD ;
        node<int>* Padre1 ;
        node<int > N[5] ;
        unsigned i ;
        // Cargamos valores en los nodes
        for ( i = 0 ; i < 5 ; i ++ ) N[i].Valor = i * 100 + 100 ;
        RP.PPadre = &Padre1 ;
	    RP.Insertanode ( 2 , &N[3] ) ;

        RI.PPadre = & RP.Ptr(2)  ;
        RI.Insertanode ( 2 , &N[0] ) ;
        RI.Insertanode ( 3 , &N[1] ) ;
	    RI.Insertanode ( 4 , &N[2] ) ;

        RD.PPadre = & RP.Ptr(3) ;
        RD.Insertanode( 2, &N[4] );
        RP.Promocion ( 2 , RI ) ;
        cout<<"Padre\n";
        cout<<RP<<endl;
        cout<<"branch Izda\n";
        cout<<RI;
        cout <<"Ranma dcha \n";
        RM = branch<int> ( RP.Ptr(2));
        cout<<RM ;
        cout<<RD ;
        cout<<"PRUEBA DE COMPACTACION nº 1 \n";
        RP.Compactacion(1, RI, RM );
        cout<<"Padre \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;

    }
    {   //---------------------------------------------------------------
        // PRUEBAS DE COMPACTACION Nº 2
        //---------------------------------------------------------------
        cout<<"********* PRUEBAS DE COMPACTACION  2***********************\n" ;
        branch<int> RP, RI , RD ;
        node<int>* Padre1 ;
        node<int > N[4] ;
        unsigned i ;
        // Cargamos valores en los nodes
        for ( i = 0 ; i < 4 ; i ++ ) N[i].Valor = i * 100 + 100 ;
        RP.PPadre = &Padre1 ;
	    RP.Insertanode ( 2 , &N[1] ) ;

        RI.PPadre = & N[1].Izda  ;
        RI.Insertanode ( 2 , &N[0] ) ;

        RD.PPadre = & N[1].Dcha ;
        RD.Insertanode ( 2 , &N[2] ) ;


        cout<<"PRUEBA DE COMPACTACION nº 2 \n";
        RP.Compactacion(2, RI, RD );
        cout<<"Padre \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;

    }
    {   //--------------------------------------------------------------
        // PRUEBAS DE Traspaso 1
        //--------------------------------------------------------------

        branch<int> RP, RI , RD ;
        node<int>* Padre1 ;
        node<int > N[6] ;
        unsigned i ;
        // Cargamos valores en los nodes
        for ( i = 0 ; i < 6 ; i ++ ) N[i].Valor = i * 100 + 100 ;
        RP.PPadre = &Padre1 ;
	    RP.Insertanode ( 2 , &N[2] ) ;

        RI.PPadre = & N[2].Izda  ;
        RI.Insertanode ( 2 , &N[0] ) ;
        RI.Insertanode ( 3 , &N[1] ) ;

        RD.PPadre = & N[2].Dcha ;
        RD.Insertanode ( 2 , &N[3] ) ;
        RD.Insertanode ( 3 , &N[4] ) ;
        cout<<"********* ANTES DEL TRASPASO 1 ***********************\n" ;
        cout<<"Padre \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;
        cout<<"branch dcha\n";
        cout<<RD<<endl ;
        cout<<"********* PRUEBAS DE TRASPASO 1 ***********************\n" ;
        RP.TraspasoIzda(2, RI, RD );
        cout<<"Padre \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;
        cout<<"branch dcha\n";
        cout<<RD<<endl ;
        cout<<"********* PRUEBAS DE TRASPASO 2 ***********************\n" ;
        RP.TraspasoDcha(2, RI, RD );
        cout<<"Padre \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;
        cout<<"branch dcha\n";
        cout<<RD<<endl ;
    }
*/
return 0 ;
};
