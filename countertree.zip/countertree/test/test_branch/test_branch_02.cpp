///----------------------------------------------------------------------------
// FILE :testbranch_02.cpp
//
// DESCRIPTION : Test program of the class branch
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco Jos� Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <stdlib.h>
#include <boost/countertree/tools/debug_branch.hpp>


using namespace std ;
using namespace cntree::tools;

void Rotacion ( void);
void Galleta ( void) ;
void GalletaInversa ( void) ;

int  main ( void)
{
    Rotacion() ;
    Galleta() ;
    GalletaInversa() ;
    return 0 ;
};
void Rotacion ( void )
{   //------------------------- Inicio ----------------------------------
    node <int> N[15] ;
	node<int>  *Padre = NULL ;

	//------------- Estructura b�sica -------------
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].data = i ;

    cout<<"-----------------------------------------------------------\n";
    cout<<"   RotarleftAlineados y RotarrightAlineados con 2 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[1] ;
    branch<int> H ( &Padre) ;
    N[1].N++ ;
    H.insert_node( &N[0], 0);
    N[1].N++ ;
    H.insert_node ( &N[3], 1) ;

    N[3].set_black() ;
    branch<int> H2 (& N[1].right ) ;
    N[1].N++ ;
    N[3].N++ ;
    H2.insert_node ( &N[4], 1 ) ;
    N[1].N++ ;
    N[3].N++ ;
    H2.insert_node ( &N[2], 0 );

    N[0].set_black() ;
    N[1].set_black() ;
    N[2].set_black() ;
    N[3].set_red() ;
    N[4].set_black() ;
    //ImprimirEstructura ( Padre) ;
    if ( not Colombo<int> ( NULL, Padre, 2 , true, cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    branch<int> R (H);
    cout<<R<<endl;
    R.rotate_left_aligned() ;
    cout<<R<<endl;
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit(1) ;
    };
    R.rotate_right_aligned() ;
    cout<<R<<endl;
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    cout<<"-----------------------------------------------------------\n";
    cout<<"   RotarleftAlineados  con 3 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ )   N[i].init() ;

    Padre = &N[1] ;
    H = branch<int>( &Padre) ;
    N[1].N++ ;
    H.insert_node( &N[0], 0);
    N[1].N++ ;
    H.insert_node ( &N[3], 1) ;
    N[0].set_black() ;
    N[3].set_black() ;
    H2 = branch<int>( &N[1].right ) ;

    N[1].N++ ;
    N[3].N++ ;
    H2.insert_node ( &N[2], 0 );
    N[1].N++ ;
    N[3].N++ ;
    H2.insert_node ( &N[5], 1 ) ;
    N[5].set_black() ;

    branch<int> H3 ( &N[3].right) ;
    N[1].N++ ;
    N[3].N++ ;
    N[5].N++;
    H3.insert_node (&N[4], 0 ) ;
    N[1].N++ ;
    N[3].N++ ;
    N[5].N++;
    H3.insert_node ( &N[6] , 1 ) ;

    N[0].set_black() ;
    N[1].set_black() ;
    N[2].set_black() ;
    N[3].set_red() ;
    N[4].set_black() ;
    N[5].set_red() ;
    N[6].set_black() ;

    R = H;
    cout<<R<<endl;
    R.rotate_left_aligned() ;
    cout<<R<<endl;
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    //ImprimirEstructura(Padre);

    cout<<"-----------------------------------------------------------\n";
    cout<<"   RotarrightAlineados  con 3 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ )  N[i].init() ;

    Padre = &N[5] ;
    N[5].N++ ;
    H.insert_node( &N[3], 0);
    N[5].N++ ;
    H.insert_node ( &N[6], 1) ;

    N[3].set_black() ;
    H2 = branch<int>( &N[5].left ) ;
    N[5].N++ ;
    N[3].N++ ;
    H2.insert_node ( &N[1], 0 );
    N[5].N++ ;
    N[3].N++ ;
    H2.insert_node ( &N[4], 1 ) ;

    N[1].set_black() ;
    H3 = branch<int>( &N[3].left) ;
    N[5].N++ ;
    N[3].N++ ;
    N[1].N++ ;
    H3.insert_node (&N[0], 0 ) ;
    N[5].N++ ;
    N[3].N++ ;
    N[1].N++ ;
    H3.insert_node ( &N[2] , 1 ) ;

    N[0].set_black() ;
    N[1].set_red() ;
    N[2].set_black() ;
    N[3].set_red() ;
    N[4].set_black() ;
    N[5].set_black() ;
    N[6].set_black() ;

    R = H;
    cout<<R<<endl;
    R.rotate_right_aligned() ;
    cout<<R<<endl;
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };

    cout<<"-----------------------------------------------------------\n";
    cout<<"   RotarleftNoAlineados  con 3 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[1] ;
    N[1].N++ ;
    H.insert_node( &N[0], 0);
    N[1].N++ ;
    H.insert_node ( &N[5], 1) ;
    N[5].set_black() ;

    H2 = branch<int>( &N[1].right ) ;
    N[1].N++ ;
    N[5].N++;
    H2.insert_node ( &N[3], 0 );
    N[1].N++ ;
    N[5].N++;
    H2.insert_node ( &N[6], 1 ) ;

    N[3].set_black() ;
    H3 = branch<int> ( &N[5].left) ;
    N[1].N++ ;
    N[5].N++;
    N[3].N++ ;
    H3.insert_node (&N[2], 0 ) ;
    N[1].N++ ;
    N[5].N++;
    N[3].N++ ;
    H3.insert_node ( &N[4] , 1 ) ;

    N[0].set_black() ;
    N[1].set_black() ;
    N[2].set_black() ;
    N[3].set_red() ;
    N[4].set_black() ;
    N[5].set_red() ;
    N[6].set_black() ;

    R = H;
    cout<<R<<endl;
    R.rotate_left_not_aligned() ;
    cout<<R<<endl;
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };

    cout<<"-----------------------------------------------------------\n";
    cout<<"   RotarrightNoAlineados  con 3 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ )  N[i].init() ;

    Padre = &N[5] ;
    N[5].N++ ;
    H.insert_node( &N[1], 0);
    N[5].N++ ;
    H.insert_node ( &N[6], 1) ;

    N[1].set_black() ;
    H2 = branch<int> ( &N[5].left ) ;
    N[5].N++ ;
    N[1].N++;
    H2.insert_node ( &N[0], 0 );
    N[5].N++ ;
    N[1].N++;
    H2.insert_node ( &N[3], 1 ) ;

    N[3].set_black() ;
    H3 = branch<int> ( &N[1].right) ;
    N[5].N++ ;
    N[1].N++;
    N[3].N++;
    H3.insert_node (&N[2], 0 ) ;
    N[5].N++ ;
    N[1].N++;
    N[3].N++;
    H3.insert_node ( &N[4] , 1 ) ;

    N[0].set_black() ;
    N[1].set_red() ;
    N[2].set_black() ;
    N[3].set_red() ;
    N[4].set_black() ;
    N[5].set_black() ;
    N[6].set_black() ;

    R = H;
    cout<<R<<endl;
    R.rotate_right_not_aligned() ;
    cout<<R<<endl;
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
}; //----------------- Fin funcion Rotacion ---------------------

void Galleta ( void )
{   //------------------------------ Inicio -----------------------
    node <int> N[15] ;
	node<int>  *Padre = NULL ;

	//------------- Estructura b�sica -------------
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].data = i ;

    cout<<"-----------------------------------------------------------\n";
    cout<<"   PartirGalleta con 3 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[3] ;
    branch<int> H ( &Padre) ;
    N[3].N++ ;
    H.insert_node( &N[1], 0);
    N[3].N++ ;
    H.insert_node( &N[5], 1);

    N[1].set_black();
    branch<int> H2 ( &N[3].left);
    N[3].N++ ;
    N[1].N++ ;
    H2.insert_node ( &N[0], 0 ) ;
    N[3].N++ ;
    N[1].N++ ;
    H2.insert_node ( &N[2], 1 ) ;

    N[5].set_black() ;
    branch<int> H3 ( & N[3].right)   ;
    N[3].N++ ;
    N[5].N++ ;
    H3.insert_node ( &N[4], 0 )  ;
    N[3].N++ ;
    N[5].N++ ;
    H3.insert_node ( &N[6], 1 )  ;


    N[0].set_black() ;
    N[1].set_red() ;
    N[2].set_black() ;
    N[3].set_black() ;
    N[4].set_black() ;
    N[5].set_red() ;
    N[6].set_black() ;

    branch<int> R (H);
    cout<<R<<endl;
    branch<int>::break_cake ( R);
    if ( not Colombo<int> ( NULL, Padre, 3 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    print_tree_struct(cout, Padre) ;


    cout<<"-----------------------------------------------------------\n";
    cout<<"   PartirGalleta con 4 Nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[5] ;
    N[5].N++;
    H.insert_node( &N[1], 0);
    N[5].N++;
    H.insert_node( &N[7], 1);
    N[7].set_black();
    H2 = branch<int> ( &N[5].right)   ;
    N[5].N++;
    N[7].N++;
    H2.insert_node( &N[6], 0);
    N[5].N++;
    N[7].N++;
    H2.insert_node( &N[8], 1);
    N[1].set_black() ;
    H3 = branch<int> ( & N[5].left);
    N[5].N++;
    N[1].N++;
    H3.insert_node( &N[0], 0 );
    N[5].N++;
    N[1].N++;
    H3.insert_node( &N[3], 1 );
    N[3].set_black() ;
    branch<int> H4 ( &N[1].right);
    N[5].N++;
    N[1].N++;
    N[3].N++ ;
    H4.insert_node( &N[2], 0);
    N[5].N++;
    N[1].N++;
    N[3].N++ ;
    H4.insert_node( &N[4], 1);


    N[0].set_black() ;
    N[1].set_red() ;
    N[2].set_black() ;
    N[3].set_red() ;
    N[4].set_black() ;
    N[5].set_black() ;
    N[6].set_black() ;
    N[7].set_red() ;
    N[8].set_black() ;


    R =H;
    cout<<R<<endl;
    branch<int>::break_cake ( R);
    if ( not Colombo<int> ( NULL, Padre, 3 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    print_tree_struct( cout , Padre);


}; //------------------------------------ Fin funcion Galleta --------------------
void GalletaInversa ( void )
{   //------------------------------ Inicio -----------------------
    node <int> N[15] ;
	node<int>  *Padre = NULL , *PAux = NULL;

	//------------- Estructura b�sica -------------
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].data = i ;

    cout<<"-----------------------------------------------------------\n";
    cout<<"   GalletaInversa con 2 Nodes en HSup\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[3] ;
    branch<int> H ( &Padre) ;
    N[3].N++ ;
    H.insert_node( &N[1], 0);
    N[3].N++ ;
    H.insert_node( &N[4], 1);
    N[1].set_black() ;
    branch<int>H2 ( &N[3].left);
    N[3].N++ ;
    N[1].N++ ;
    H2.insert_node (&N[0], 0 )  ;
    N[3].N++ ;
    N[1].N++ ;
    H2.insert_node (&N[2], 1 )  ;

    N[0].set_black() ;
    N[1].set_red() ;
    N[2].set_black() ;
    N[3].set_black() ;
    N[4].set_black() ;
    branch<int> RSup (H.ppblack);
    branch<int>HInf ( & N[1].right);
    N[3].N-- ;
    N[1].N-- ;
    HInf.disconnect_node(0 , PAux);
    branch<int>::reverse_cake( RSup, HInf, 3);
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    print_tree_struct( cout, Padre);
    branch<int> RAux ( &N[3].left);
    //cout<<RSup<<endl;
    //cout<<RAux<<endl;


    cout<<"-----------------------------------------------------------\n";
    cout<<"   GalletaInversa con 2 Nodes en HSup\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[5] ;
    H = branch<int> ( &Padre) ;
    N[5].N++ ;
    H.insert_node( &N[3], 0);
    N[5].N++ ;
    H.insert_node( &N[6], 1);

    N[3].set_black() ;
    H2 = branch<int>( &N[5].left);
    N[5].N++ ;
    N[3].N++ ;
    H2.insert_node (&N[1], 0 )  ;
    N[5].N++ ;
    N[3].N++ ;
    H2.insert_node (&N[4], 1 )  ;

    N[1].set_black() ;
    branch<int> H3( &N[3].left);
    N[5].N++ ;
    N[3].N++ ;
    N[1].N++ ;
    H3.insert_node ( &N[0], 0 );
    N[5].N++ ;
    N[3].N++ ;
    N[1].N++ ;
    H3.insert_node ( &N[2], 1 );

    N[0].set_red() ;
    N[1].set_black() ;
    N[2].set_red() ;
    N[3].set_red() ;
    N[4].set_black() ;
    N[5].set_black() ;
    N[6].set_black() ;

    RSup = branch<int>(H.ppblack);
    HInf =branch<int>( & N[3].right);
    RAux = branch<int> ( &N[3].left);
    N[3].N-- ;
    N[5].N-- ;
    HInf.disconnect_node( 0 , PAux);

    branch<int>::reverse_cake( RSup, HInf, 3);
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };

    print_tree_struct( cout ,Padre);
    //cout<<RSup<<endl;
    //cout<<RAux<<endl;
    //cout<<HInf<<endl;
};
