//----------------------------------------------------------------
// FICHERO :branch3.cpp
//
// DESCRIPCION : Programa de pruebas de la clase branch
//
// MODULOS / LIBRERIAS NECESARIOS :
//
// FUNCIONES / CLASES :
//
// VARIABLES GLOBALES :
//
// COMPILACION :
//
// OBSERVACIONES :
//
//----------------------------------------------------------------
#define __DEBUG_MODE 2
#include <stdlib.h>
#include <boost/countertree/tools/debug_branch.hpp>


using namespace std ;
using namespace cntree::tools;
int  main ( void)
{
    //----------------------------------------------------------------
    // PRUEBAS DE GALLETAINVERSA
    //----------------------------------------------------------------
    //------------- Inicio -------------------
	node <int> N[15] ;
	node<int>  *Father = NULL ;
    for ( uint32_t i = 0 ; i < 15 ; i ++ )
    {   N[i].init() ;
        N[i].data = i ;
    };
    Father = &N[0] ;
    branch<int> H ( &Father), H2(&Father);
    branch<int> RInf(&Father),RSup(&Father);

	cout<<"-----------------------------------------------------------\n";
    cout<<"                  Caso 01\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Father = &N[3] ;
    H.ppblack = &Father ;
    N[3].set_black() ;
    N[3].N++ ;
    H.insert_node( &N[1], 0);
    N[3].N++ ;
    H.insert_node( &N[4], 1);


    N[1].set_black() ;
    H.ppblack = &N[3].left ;
    N[3].N++ ;
    N[1].N++ ;
    H.insert_node( &N[0], 0);


    N[0].set_black() ;
    N[1].set_red() ;
    N[2].set_black() ;
    N[3].set_black() ;
    N[4].set_black() ;


    print_tree_struct(cout,Father);

    RInf.ppblack=  &N[1].right;
    if(branch<int>::reverse_cake ( RSup, RInf,3)) cout<<"Estable\n";
    else                               cout<<"Inestable\n";
    if ( not Colombo<int> ( NULL, Father, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    print_tree_struct (cout,Father);


	cout<<"-----------------------------------------------------------\n";
    cout<<"                  Caso 02\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Father = &N[5] ;
    H.ppblack = &Father ;
    N[5].set_black() ;

    N[5].N++ ;
    H.insert_node( &N[3], 0);
    N[5].N++ ;
    H.insert_node( &N[6], 1);

    N[3].set_black() ;
    H.ppblack = &N[5].left ;
    N[3].N++ ;
    N[5].N++ ;
    H.insert_node( &N[1], 0);

    N[1].set_black() ;
    H.ppblack = &N[3].left ;
    N[3].N++ ;
    N[5].N++ ;
    N[1].N++;
    H.insert_node( &N[0], 0);
    N[3].N++ ;
    N[5].N++ ;
    N[1].N++;
    H.insert_node( &N[2], 1);

    N[0].set_red() ;
    N[1].set_black() ;
    N[2].set_red() ;
    N[3].set_red() ;
    N[4].set_black() ;
    N[5].set_black() ;
    N[6].set_black() ;
    N[7].set_black() ;
    N[8].set_black() ;


    print_tree_struct(cout,Father);

    RInf.ppblack = &N[3].right;
    if(branch<int>::reverse_cake ( RSup, RInf,3)) cout<<"Estable\n";
    else                               cout<<"Inestable\n";
    if ( not Colombo<int> ( NULL, Father, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    print_tree_struct (cout,Father);


	cout<<"-----------------------------------------------------------\n";
    cout<<"              C A S O     0 3 \n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Father = &N[2] ;
    H.ppblack = &Father ;
    N[2].N++ ;
    H.insert_node( &N[0], 0);


    N[0].set_black() ;
    H.ppblack = &N[2].left ;
    N[2].N++ ;
    N[0].N++;
    H.insert_node ( &N[1], 1) ;


    N[0].set_black() ;
    N[1].set_red() ;
    N[2].set_black() ;


    print_tree_struct(cout,Father);

    RInf.ppblack = &N[2].left;
    if(branch<int>::reverse_cake ( RSup, RInf,1)) cout<<"Estable\n";
    else                               cout<<"Inestable\n";
    if ( not Colombo<int> ( NULL, Father, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    print_tree_struct (cout,Father);


	cout<<"-----------------------------------------------------------\n";
    cout<<"              C A S O     0 4 \n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Father = &N[3] ;
    H.ppblack = &Father ;
    N[3].N++ ;
    H.insert_node( &N[1], 0);

    N[1].set_black() ;
    H.ppblack = &N[3].left ;
    N[1].N++ ;
    N[3].N++;
    H.insert_node ( &N[0], 0) ;

    N[1].N++ ;
    N[3].N++;
    H.insert_node ( &N[2], 1) ;

    N[0].set_red() ;
    N[1].set_black() ;
    N[2].set_red() ;
    N[3].set_black() ;
    print_tree_struct(cout,Father);

    RInf.ppblack = &N[3].left;
    if(branch<int>::reverse_cake ( RSup, RInf,1)) cout<<"Estable\n";
    else                               cout<<"Inestable\n";
    if ( not Colombo<int> ( NULL, Father, 2 , true))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };
    print_tree_struct (cout,Father);

	cout<<"-----------------------------------------------------------\n";
    cout<<"              C A S O     0 5 \n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Father = &N[1] ;
    H.ppblack = &Father ;
    N[1].N++ ;
    H.insert_node( &N[0], 0);
    N[0].set_black() ;

    N[0].set_black() ;
    N[1].set_black() ;

    print_tree_struct(cout,Father);

    RInf.ppblack = &N[1].left;
    if(branch<int>::reverse_cake ( RSup, RInf,1)) cout<<"Estable\n";
    else                                          cout<<"Inestable\n";
    print_tree_struct(cout,Father);

/*
	cout<<"-----------------------------------------------------------\n";
    cout<<"              C A S O     0 6 \n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Father = &N[5] ;
    H.ppblack = &Father ;
    N[5].N++ ;
    H.insert_node( &N[1], 0);
    N[5].N++ ;
    H.insert_node ( &N[6], 1) ;
    N[1].set_black () ;

    H.ppblack = & N[5].left ;

    N[1].N++ ;
    N[5].N++;
    H.insert_node ( &N[3], 1) ;
    N[1].N++ ;
    N[5].N++;
    H.insert_node ( &N[0], 0) ;


    N[3].set_black() ;
    H.ppblack = &N[1].Right ;
    N[1].N++ ;
    N[5].N++;
    N[3].N++;
    H.insert_node ( &N[2], 0) ;

    N[1].N++ ;
    N[3].N++;
    N[5].N++;
    H.insert_node ( &N[4], 1) ;

    N[0].set_black() ;
    N[1].set_black() ;
    N[2].set_black() ;
    N[3].set_red() ;
    N[4].set_black() ;
    N[5].set_black() ;
    N[6].set_black() ;

    print_tree_struct(Father);

    RInf.ppblack = &N[5].left;
    RInf.Capturarnode(RSup);
    print_tree_struct(Father);


	cout<<"-----------------------------------------------------------\n";
    cout<<"              C A S O     0 7 \n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Father = &N[1] ;
    H.ppblack = &Father ;
    N[1].N++ ;
    H.insert_node( &N[0], 0);
    N[1].N++ ;
    H.insert_node ( &N[5], 1) ;

    N[5].set_black () ;
    H.ppblack = & N[1].Right ;
    N[1].N++ ;
    N[5].N++;
    H.insert_node ( &N[3], 0) ;
    N[1].N++ ;
    N[5].N++;
    H.insert_node ( &N[7], 1) ;

    N[3].set_black() ;
    H.ppblack = &N[5].left ;
    N[1].N++ ;
    N[5].N++;
    N[3].N++;
    H.insert_node ( &N[2], 0) ;
    N[1].N++ ;
    N[3].N++;
    N[5].N++;
    H.insert_node ( &N[4], 1) ;

    N[7].set_black() ;
    H.ppblack = &N[5].Right ;
    N[1].N++ ;
    N[5].N++;
    N[7].N++;
    H.insert_node ( &N[6], 0) ;
    N[1].N++ ;
    N[7].N++;
    N[5].N++;
    H.insert_node ( &N[8], 1) ;


    N[0].set_black() ;
    N[1].set_black() ;
    N[2].set_black() ;
    N[3].set_red() ;
    N[4].set_black() ;
    N[5].set_black() ;
    N[6].set_black() ;
    N[7].set_red() ;
    N[8].set_black() ;

    print_tree_struct(Father);

    RInf.ppblack = &N[1].Right;

    RInf.Capturarnode(RSup);
    print_tree_struct(Father);

	cout<<"-----------------------------------------------------------\n";
    cout<<"              C A S O     0 8 \n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Father = &N[7] ;
    H.ppblack = &Father ;
    N[7].N++ ;
    H.insert_node( &N[3], 0);
    N[7].N++ ;
    H.insert_node ( &N[8], 1) ;

    N[3].set_black () ;
    H.ppblack = & N[7].left ;
    N[7].N++ ;
    N[3].N++;
    H.insert_node ( &N[1], 0) ;
    N[7].N++ ;
    N[3].N++;
    H.insert_node ( &N[5], 1) ;

    N[1].set_black() ;
    H.ppblack = &N[3].left ;
    N[1].N++ ;
    N[7].N++;
    N[3].N++;
    H.insert_node ( &N[0], 0) ;
    N[1].N++ ;
    N[3].N++;
    N[7].N++;
    H.insert_node ( &N[2], 1) ;

    N[5].set_black() ;
    H.ppblack = &N[3].Right ;
    N[3].N++ ;
    N[5].N++;
    N[7].N++;
    H.insert_node ( &N[4], 0) ;
    N[3].N++ ;
    N[7].N++;
    N[5].N++;
    H.insert_node ( &N[6], 1) ;


    N[0].set_black() ;
    N[1].set_red() ;
    N[2].set_black() ;
    N[3].set_black() ;
    N[4].set_black() ;
    N[5].set_red() ;
    N[6].set_black() ;
    N[7].set_black() ;
    N[8].set_black() ;

    print_tree_struct(Father);

    RInf.ppblack = &N[7].left;

    RInf.Capturarnode(RSup);
    print_tree_struct(Father);
*/
 /*

    {
        cout<<"-----------------------------------------------------------\n";
        cout<<"   Pruebas de PartirGalleta con 4 nodos\n";
        cout<<"-----------------------------------------------------------\n";
        for ( uint32_t i = 0 ; i < 15 ; i ++ )
        {   N[i].init() ;
            N[i].Data = i ;
        };
        Father = &N[5] ;
        branch<int> H (& Father) ;
        H.insert_node( &N[1], 0);
        H.insert_node ( &N[7], 1) ;

        N[1].set_black() ;
        N[7].set_black() ;
        branch<int> H2 (& N[5].left ) ;
        H2.insert_node ( &N[0], 0 );
        H2.insert_node ( &N[3], 1 ) ;

        branch<int>H3 ( &N[5].Right) ;
        H3.insert_node ( &N[6], 0 );
        H3.insert_node ( &N[8], 1 ) ;

        branch<int> H4 (& N[1].Right ) ;
        H4.insert_node( &N[2], 0);
        H4.insert_node (&N[4], 1 ) ;

        N[0].set_black() ; N[0].N = 1 ;
        N[1].set_red()  ; N[1].N = 5 ;
        N[2].set_black() ; N[2].N = 1 ;
        N[3].set_red()  ; N[3].N = 3 ;
        N[4].set_black() ; N[4].N = 1 ;
        N[5].set_black() ; N[5].N = 9 ;
        N[6].set_black() ; N[6].N = 1 ;
        N[7].set_red()  ; N[7].N = 3 ;
        N[8].set_black() ; N[8].N = 1 ;

        cout<<H<<endl;
        branch<int>::PartirGalleta ( H ) ;

        cout<<N[5]<<endl ;
        cout<<N[1]<<endl ;
        cout<<N[7]<<endl<<endl ;
    };

     {
        cout<<"-----------------------------------------------------------\n";
        cout<<"   Pruebas de GalletaInversa con 3 nodos\n";
        cout<<"-----------------------------------------------------------\n";
        for ( uint32_t i = 0 ; i < 15 ; i ++ )
        {   N[i].init() ;
            N[i].Data = i ;
        };
        Pnode<int> PAux = NULL ;
        Father = &N[3] ;
        branch<int> H ( &Father) ;
        H.insert_node( &N[1], 0);
        H.insert_node ( &N[4], 1) ;

        N[1].set_black() ;
        N[4].set_black() ;
        branch<int> H2 ( &N[3].left ) ;
        H2.insert_node ( &N[0], 0 );
        H2.insert_node ( &N[2] , 1 ) ;


        N[0].set_black() ; N[0].N = 1 ;
        N[1].set_red()  ; N[1].N = 2 ;
        N[2].set_black() ; N[2].N = 1 ;
        N[3].set_black() ; N[3].N = 4 ;
        N[4].set_black() ; N[4].N = 1 ;
        branch<int> H3( & N[1].Right );
        cout<<H3<<endl;
        H3.Desconectarnode( 0, PAux ) ;

        cout<<H<<endl;
        branch<int>::GalletaInversa ( H, H3, 3 ) ;

        cout<<H<<endl;
        cout<<H3<<endl;

    };
*/
/*
        {   cout<<"-----------------------------------------------------------\n";
            cout<<"   RotarleftAlineados  con 3 nodos\n";
            cout<<"-----------------------------------------------------------\n";
            for ( uint32_t i = 0 ; i < 15 ; i ++ )
            {   N[i].init() ;
                N[i].Data = i ;
            };
            Father = &N[1] ;
            branch<int> H ( Father) ;
            H.insert_node( &N[0], 0);
            H.insert_node ( &N[3], 1) ;
            N[0].set_black() ;
            N[3].set_black() ;
            branch<int> H2 ( N[1].Right ) ;
            H2.insert_node ( &N[2], 0 );
            H2.insert_node ( &N[5], 1 ) ;
            N[5].set_black() ;
            branch<int> H3 ( N[3].Right) ;
            H3.insert_node (&N[4], 0 ) ;
            H3.insert_node ( &N[6] , 1 ) ;

            N[0].set_black() ;
            N[1].set_black() ;
            N[2].set_black() ;
            N[3].set_red() ;
            N[4].set_black() ;
            N[5].set_red() ;
            N[6].set_black() ;

            branch<int> R (H);
            cout<<R<<endl;
            R.RotarleftAlineados() ;
            cout<<R<<endl;
        };

        {   cout<<"-----------------------------------------------------------\n";
            cout<<"   RotarRightAlineados  con 3 nodos\n";
            cout<<"-----------------------------------------------------------\n";
            for ( uint32_t i = 0 ; i < 15 ; i ++ )
            {   N[i].init() ;
                N[i].Data = i ;
            };
            Father = &N[5] ;
            branch<int> H ( Father) ;
            H.insert_node( &N[3], 0);
            H.insert_node ( &N[6], 1) ;
            N[3].set_black() ;
            branch<int> H2 ( N[5].left ) ;
            H2.insert_node ( &N[1], 0 );
            H2.insert_node ( &N[4], 1 ) ;
            N[1].set_black() ;
            branch<int> H3 ( N[3].left) ;
            H3.insert_node (&N[0], 0 ) ;
            H3.insert_node ( &N[2] , 1 ) ;

            N[0].set_black() ;
            N[1].set_red() ;
            N[2].set_black() ;
            N[3].set_red() ;
            N[4].set_black() ;
            N[5].set_black() ;
            N[6].set_black() ;

            branch<int> R (H);
            cout<<R<<endl;
            R.RotarRightAlineados() ;
            cout<<R<<endl;
        };

        {   cout<<"-----------------------------------------------------------\n";
            cout<<"   RotarleftNoAlineados  con 3 nodos\n";
            cout<<"-----------------------------------------------------------\n";
            for ( uint32_t i = 0 ; i < 15 ; i ++ )
            {   N[i].init() ;
                N[i].Data = i ;
            };
            Father = &N[1] ;
            branch<int> H ( Father) ;
            H.insert_node( &N[0], 0);
            H.insert_node ( &N[5], 1) ;
            N[5].set_black() ;
            branch<int> H2 ( N[1].Right ) ;
            H2.insert_node ( &N[3], 0 );
            H2.insert_node ( &N[6], 1 ) ;
            N[3].set_black() ;
            branch<int> H3 ( N[5].left) ;
            H3.insert_node (&N[2], 0 ) ;
            H3.insert_node ( &N[4] , 1 ) ;

            N[0].set_black() ;
            N[1].set_black() ;
            N[2].set_black() ;
            N[3].set_red() ;
            N[4].set_black() ;
            N[5].set_red() ;
            N[6].set_black() ;

            branch<int> R (H);
            cout<<R<<endl;
            R.RotarleftNoAlineados() ;
            cout<<R<<endl;
        };
        {   cout<<"-----------------------------------------------------------\n";
            cout<<"   RotarRightNoAlineados  con 3 nodos\n";
            cout<<"-----------------------------------------------------------\n";
            for ( uint32_t i = 0 ; i < 15 ; i ++ )
            {   N[i].init() ;
                N[i].Data = i ;
            };
            Father = &N[5] ;
            branch<int> H ( Father) ;
            H.insert_node( &N[1], 0);
            H.insert_node ( &N[6], 1) ;
            N[1].set_black() ;
            branch<int> H2 ( N[5].left ) ;
            H2.insert_node ( &N[0], 0 );
            H2.insert_node ( &N[3], 1 ) ;
            N[3].set_black() ;
            branch<int> H3 ( N[1].Right) ;
            H3.insert_node (&N[2], 0 ) ;
            H3.insert_node ( &N[4] , 1 ) ;

            N[0].set_black() ;
            N[1].set_red() ;
            N[2].set_black() ;
            N[3].set_red() ;
            N[4].set_black() ;
            N[5].set_black() ;
            N[6].set_black() ;

            branch<int> R (H);
            cout<<R<<endl;
            R.RotarRightNoAlineados() ;
            cout<<R<<endl;
        };


    }
*/
/*

	    // Insertamos los 4 primeros nodos en R1
	    R1.PFather = &Father ;
	    R1.Insertanode ( 2 , &N[0] ) ;
	    R1.Insertanode ( 3 , &N[1] ) ;
	    R1.Insertanode ( 4 , &N[2] ) ;
	    R1.Insertanode ( 4 , &N[3] ) ;
	    cout <<"4 nodes insertados \n";
	    cout <<R1<<endl ;
        //Rotacion a la izda
        R1.Rotacionleft() ;
        cout<<R1<<endl ;
        //Rotacion dcha
        R1.RotacionRight() ;
        cout<<R1 <<endl ;
        //Suprimimos los 4 nodos
        node<int > *PAux ;
        unsigned PosPtr ;
        for ( i  = 0 ; i < 4 ; i ++ )
            R1.Suprimirnode( 2 , NULL, PAux, PosPtr ) ;
        cout<<R1;
    }
    {   //---------------------------------------------------------------
        // PRUEBAS DE PROMOCION N� 1
        //---------------------------------------------------------------
        cout<<"********* PRUEBAS DE PROMOCION  1***********************\n";
        branch <int> RP, RI , RD ;
        node<int> * Father1 ;
        node<int > N[4] ;
        unsigned i ;
        // Cargamos valores en los nodos
        for ( i = 0 ; i < 4 ; i ++ ) N[i].Valor = i * 100 + 100 ;
        RI.PFather = &Father1 ;
        RI.Insertanode ( 2 , &N[0] ) ;
	    RI.Insertanode ( 3 , &N[1] ) ;
	    RI.Insertanode ( 4 , &N[2] ) ;
	    RI.Insertanode ( 4 , &N[3] ) ;
        RP.PFather = &Father1 ;
        RP.Promocion ( 2 , RI ) ;
        cout<<"Father\n";
        cout<<RP<<endl;
        cout<<"branch left\n";
        cout<<RI;
        cout <<"branch dcha \n";
        RD = branch<int> ( RP.PNd[2]->Right ) ;
        cout<<RD ;
    }
    {   //---------------------------------------------------------------
        // PRUEBAS DE PROMOCION N� 2
        //---------------------------------------------------------------
        cout<<"********* PRUEBAS DE PROMOCION  2***********************\n" ;
        branch<int> RP, RI ,RM, RD ;
        node<int>* Father1 ;
        node<int > N[5] ;
        unsigned i ;
        // Cargamos valores en los nodos
        for ( i = 0 ; i < 5 ; i ++ ) N[i].Valor = i * 100 + 100 ;
        RP.PFather = &Father1 ;
	    RP.Insertanode ( 2 , &N[3] ) ;

        RI.PFather = & RP.Ptr(2)  ;
        RI.Insertanode ( 2 , &N[0] ) ;
        RI.Insertanode ( 3 , &N[1] ) ;
	    RI.Insertanode ( 4 , &N[2] ) ;

        RD.PFather = & RP.Ptr(3) ;
        RD.Insertanode( 2, &N[4] );
        RP.Promocion ( 2 , RI ) ;
        cout<<"Father\n";
        cout<<RP<<endl;
        cout<<"branch left\n";
        cout<<RI;
        cout <<"Ranma dcha \n";
        RM = branch<int> ( RP.Ptr(2));
        cout<<RM ;
        cout<<RD ;
        cout<<"PRUEBA DE COMPACTACION n� 1 \n";
        RP.Compactacion(1, RI, RM );
        cout<<"Father \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;

    }
    {   //---------------------------------------------------------------
        // PRUEBAS DE COMPACTACION N� 2
        //----------------------------------------------------------------
        cout<<"********* PRUEBAS DE COMPACTACION  2***********************\n" ;
        branch<int> RP, RI , RD ;
        node<int>* Father1 ;
        node<int > N[4] ;
        unsigned i ;
        // Cargamos valores en los nodos
        for ( i = 0 ; i < 4 ; i ++ ) N[i].Valor = i * 100 + 100 ;
        RP.PFather = &Father1 ;
	    RP.Insertanode ( 2 , &N[1] ) ;

        RI.PFather = & N[1].left  ;
        RI.Insertanode ( 2 , &N[0] ) ;

        RD.PFather = & N[1].Right ;
        RD.Insertanode ( 2 , &N[2] ) ;


        cout<<"PRUEBA DE COMPACTACION n� 2 \n";
        RP.Compactacion(2, RI, RD );
        cout<<"Father \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;

    }
    {   //---------------------------------------------------------------
        // PRUEBAS DE Traspaso 1
        //---------------------------------------------------------------

        branch<int> RP, RI , RD ;
        node<int>* Father1 ;
        node<int > N[6] ;
        unsigned i ;
        // Cargamos valores en los nodos
        for ( i = 0 ; i < 6 ; i ++ ) N[i].Valor = i * 100 + 100 ;
        RP.PFather = &Father1 ;
	    RP.Insertanode ( 2 , &N[2] ) ;

        RI.PFather = & N[2].left  ;
        RI.Insertanode ( 2 , &N[0] ) ;
        RI.Insertanode ( 3 , &N[1] ) ;

        RD.PFather = & N[2].Right ;
        RD.Insertanode ( 2 , &N[3] ) ;
        RD.Insertanode ( 3 , &N[4] ) ;
        cout<<"********* ANTES DEL TRASPASO 1 ***********************\n" ;
        cout<<"Father \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;
        cout<<"branch dcha\n";
        cout<<RD<<endl ;
        cout<<"********* PRUEBAS DE TRASPASO 1 ***********************\n" ;
        RP.Traspasoleft(2, RI, RD );
        cout<<"Father \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;
        cout<<"branch dcha\n";
        cout<<RD<<endl ;
        cout<<"********* PRUEBAS DE TRASPASO 2 ***********************\n" ;
        RP.TraspasoRight(2, RI, RD );
        cout<<"Father \n";
        cout<<RP<<endl ;
        cout <<"branch izda\n";
        cout<<RI<<endl ;
        cout<<"branch dcha\n";
        cout<<RD<<endl ;
    }
*/
        return 0 ;

};
