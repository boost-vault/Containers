///----------------------------------------------------------------------------
// FILE : testIterator_01.cpp
//
// DESCRIPTION : Test program of the class iterator
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <boost/countertree/tools/iterator.hpp>
#include <boost/countertree/tools/debug_node.hpp>
#include <iterator>


using std::cout ;
using std::endl ;
namespace bct = cntree::tools ;
bct::node <int> N[15] ;

int main ( void )
{   //------------------------ Inicio ----------------------------------
	bct::node<int>  *Father = NULL ;
    uint32_t i ;

    struct MyBasicTree:public bct::basic_tree<int>
    {   //---------------------- Begin -----------------------------
        size_type size(void)const{ return 9 ;};

        bct::node<int> * get_first ( void)  {return &N[0];} ;
        const bct::node<int> * get_first ( void) const {return &N[0];} ;

        bct::node<int> * get_last  ( void) {return &N[8];} ;
        const bct::node<int> * get_last  ( void) const {return &N[8];} ;
    } MBT ;



    for ( i = 0 ; i < 15 ; i ++ )
    {   N[i].init() ;
        N[i].data = i ;
    };

    cout<<"-----------------------------------------------------------\n";
    cout<<"                  Caso 02\n";
    cout<<"-----------------------------------------------------------\n";

    Father = &N[5] ;
    N[5].up = NULL ;
    N[5].N = 9 ;
    N[5].set_black();

    N[5].left = &N[3] ;
    N[3].up = &N[5] ;
    N[3].N = 5 ;
    N[3].set_red();

    N[3].left = &N[1] ;
    N[1].up = &N[3] ;
    N[1].N = 3 ;
    N[1].set_black();

    N[1].left = & N[0] ;
    N[0].up = &N[1] ;
    N[0].N = 1 ;
    N[0].set_red();

    N[1].right= & N[2] ;
    N[2].up = &N[1] ;
    N[2].N = 1 ;
    N[2].set_red() ;

    N[3].right = &N[4] ;
    N[4].up = &N[3] ;
    N[4].N = 1 ;
    N[4].set_black();

    N[5].right = &N[7] ;
    N[7].up = & N[5] ;
    N[7].N = 3 ;
    N[7].set_black() ;

    N[7].left = &N[6] ;
    N[6].up = &N[7] ;
    N[6].N = 1 ;
    N[6].set_red();

    N[7].right = & N[8] ;
    N[8].up = &N[7] ;
    N[8].N = 1 ;
    N[8].set_red();


    print_tree_struct(cout,Father);
    if (not  bct::Colombo<int>( NULL,Father,2,false,cout))
        cout<<"Error \n";


    //==============================================================
    //                    C U R S O R
    //===============================================================
    {   bct::iterator <int> CIni= bct::iterator<int> ( &N[0],&MBT);
        bct::iterator <int> C1(CIni);

        bct::const_iterator<int> CEnd, CREnd ;
        CEnd = bct::iterator<int>::end(CIni) ;
        CREnd = bct::iterator<int>::rend(CIni);
        //C1 = iterator<int>::end(C1) -1 ;
        C1 = C1 -1 ;
        //-------------------------------------------------------
        // Recorido de uno en uno hacia adelante
        //------------------------------------------------------
        cout<<"Recorrido de uno en uno hacia adelante ----->\n";
        for (C1=CIni ;C1 != CEnd; C1++)
        {   if ( C1.pos() != *C1) cout<<"Error gordo \n\n";
            cout<<( *C1)<<"  ";
        };
        cout<<endl<<endl ;
        //-------------------------------------------------------
        // Recorrido de dos en dos hacia adelante
        //------------------------------------------------------
        cout<<"Recorrido de dos en dos hacia adelante -------->\n";
        for (C1=CIni;C1 != CEnd; C1+= 2)
        {   cout<< *C1<<"  ";
        };
        cout<<endl<<endl ;
        //--------------------------------------------------------
        // Recorrido de uno en uno hacia atras
        //--------------------------------------------------------
        cout<<"Recorrido de uno en uno hacia atras ----->\n";
        for (C1=CIni+8 ;C1 != CREnd; C1--)
        {   cout<< *C1<<"  ";
        };
        cout<<endl<<endl ;
        //-------------------------------------------------------
        // Recorido de dos en dos hacia atras
        //------------------------------------------------------
        cout<<"Recorrido de dos en dos hacia atras -------->\n";
        for (C1=CIni+8;C1 != CREnd; C1-= 2)
        {   cout<< *C1<<"  ";
        };
        cout<<endl<<endl ;

        //============================================================
        //
        //              L A B O R A T O R I O
        //
        //============================================================
        bct::iterator <int> Alfa ( &N[0],&MBT), Beta (Alfa );

        Alfa = bct::iterator<int>::begin(Beta) + 12 ;
        cout<<( std::distance (Beta ,Alfa))<<endl;
        if ( Alfa == bct::iterator<int>::end(Beta)) cout<<"Iterators iguales \n";
        else                     cout<<"Iterators distintos\n";
        Alfa -= 2 ;
        cout<<(*Alfa)<<endl;
        Alfa = Beta ;
        std::advance(Alfa , 9 );
        if ( Alfa == bct::iterator<int>::end(Beta)) cout<<"Iterators iguales \n";
        else                     cout<<"Iterators distintos\n";

    };


    //==============================================================
    //                    C O N S T C U R S O R
    //===============================================================
    {   bct::const_iterator <int> C2,C2Ini, C2End, C2REnd;
        C2Ini = bct::iterator<int> ( &N[0],&MBT);
        C2End = bct::const_iterator <int>::end(C2Ini) ;
        C2REnd = bct::const_iterator <int>::rend(C2Ini);
        cout<<C2End.pos()<<endl;
        //-------------------------------------------------------
        // Recorido de uno en uno hacia adelante
        //------------------------------------------------------
        cout<<"Recorrido de uno en uno hacia adelante ----->\n";
        for (C2= C2Ini ; C2 != C2End; C2++)
        {   cout<< (*C2)<<"  ";
        };
        cout<<endl<<endl ;
        //-------------------------------------------------------
        // Recorido de dos en dos hacia adelante
        //------------------------------------------------------
        cout<<"Recorrido de dos en dos hacia adelante -------->\n";
        for (C2= C2Ini ;C2 != C2End; C2+= 2)
        {   cout<< (*C2)<<"  ";
        };
        cout<<endl<<endl ;
        //--------------------------------------------------------
        // Recorrido de uno en uno hacia atras
        //--------------------------------------------------------
        cout<<"Recorrido de uno en uno hacia atras ----->\n";
        for (C2=C2Ini +8 ;C2 != C2REnd; C2--)
        {   cout<< *C2<<"  ";
        };
        cout<<endl<<endl ;
        //-------------------------------------------------------
        // Recorido de dos en dos hacia atras
        //------------------------------------------------------
        cout<<"Recorrido de dos en dos hacia atras -------->\n";
        for (C2= C2Ini+8;C2 != C2REnd; C2-= 2)
        {   cout<< *C2<<"  ";
        };
        cout<<endl<<endl ;
        //constiterator<int> C2 ;

        //============================================================
        //
        //              L A B O R A T O R I O
        //
        //============================================================
        bct::const_iterator <int> Alfa ( &N[0],&MBT), Beta (Alfa );

        Alfa = bct::const_iterator <int>::begin(Beta) + 12 ;
        cout<<( std::distance (Beta ,Alfa))<<endl;
        if ( Alfa == bct::const_iterator <int>::end(Beta)) cout<<"Iterators iguales \n";
        else                     cout<<"Iterators distintos\n";
        Alfa -= 2 ;
        cout<<(*Alfa)<<endl;
        Alfa = Beta ;
        std::advance(Alfa , 9 );
        if ( Alfa == bct::const_iterator <int>::end(Beta)) cout<<"Iterators iguales \n";
        else                     cout<<"Iterators distintos\n";
    };
    return 0 ;

} ;
