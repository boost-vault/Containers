///----------------------------------------------------------------------------
// FILE : testIterator_02.cpp
//
// DESCRIPTION : Test program of the class iterator
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <boost/countertree/tools/iterator.hpp>
#include <boost/countertree/tools/debug_node.hpp>


using cntree::tools::node  ;
using cntree::tools::iterator ;
using cntree::tools::const_iterator ;
using cntree::tools::basic_tree ;
using cntree::tools::Colombo ;
using std::ostream ;
using std::cout ;
using std::endl ;


node <int> N[15] ;


ostream  & operator << ( ostream &salida , const iterator<int> & I)
{   salida <<"[ "<<I.ptr_basic_tree()<<" , "<< I.ptr();
    if ( I.ptr_basic_tree() != NULL) salida<<"  Pos:"<<I.pos();
    salida<<"] ";
    return salida ;
};
ostream  & operator << ( ostream &salida , const const_iterator<int> & I)
{   salida <<"[ "<<I.ptr_basic_tree()<<" , "<< I.ptr();
    if ( I.ptr_basic_tree() != NULL) salida<<"  Pos:"<<I.pos();
    salida<<"] ";
    return salida ;
};

int main ( void )
{   //------------------------ Inicio ----------------------------------
	node<int>  *Father = NULL ;
    uint32_t i ;

    struct MyBasicTree:public basic_tree<int>
    {   //---------------------- Begin -----------------------------
        size_type size(void)const{ return 9 ;};

        node<int> * get_first ( void)  {return &N[0];} ;
        const node<int> * get_first ( void) const {return &N[0];} ;

        node<int> * get_last  ( void) {return &N[8];} ;
        const node<int> * get_last  ( void) const {return &N[8];} ;
    } MBT ;



    for ( i = 0 ; i < 15 ; i ++ )
    {   N[i].init() ;
        N[i].data = i ;
    };

    cout<<"-----------------------------------------------------------\n";
    cout<<"                  Caso 02\n";
    cout<<"-----------------------------------------------------------\n";

    Father = &N[5] ;
    N[5].up = NULL ;
    N[5].N = 9 ;
    N[5].set_black();

    N[5].left = &N[3] ;
    N[3].up = &N[5] ;
    N[3].N = 5 ;
    N[3].set_red();

    N[3].left = &N[1] ;
    N[1].up = &N[3] ;
    N[1].N = 3 ;
    N[1].set_black();

    N[1].left = & N[0] ;
    N[0].up = &N[1] ;
    N[0].N = 1 ;
    N[0].set_red();

    N[1].right= & N[2] ;
    N[2].up = &N[1] ;
    N[2].N = 1 ;
    N[2].set_red() ;

    N[3].right = &N[4] ;
    N[4].up = &N[3] ;
    N[4].N = 1 ;
    N[4].set_black();

    N[5].right = &N[7] ;
    N[7].up = & N[5] ;
    N[7].N = 3 ;
    N[7].set_black() ;

    N[7].left = &N[6] ;
    N[6].up = &N[7] ;
    N[6].N = 1 ;
    N[6].set_red();

    N[7].right = & N[8] ;
    N[8].up = &N[7] ;
    N[8].N = 1 ;
    N[8].set_red();


    print_tree_struct(cout,Father);
    if (not  Colombo<int>( NULL,Father,2,false,cout))
        cout<<"Error \n";


    //==============================================================
    //                    C U R S O R
    //===============================================================
    {   iterator <int> C1 = iterator<int>::begin ( &MBT);
        iterator <int> CBegin(C1);
        cout<<C1<<"   "<<CBegin<<endl;
        iterator<int> CRBegin ( iterator<int>::rbegin (CBegin));
        iterator<int> CEnd    ( iterator<int>::end    (CBegin));
        iterator<int> CREnd   ( iterator<int>::rend   (CBegin));
        C1 = CEnd -2 ;

        //-------------------------------------------------------
        // Recorido de uno en uno hacia adelante
        //------------------------------------------------------
        cout<<"Recorrido de uno en uno hacia adelante ----->\n";
        for (C1=CBegin ;C1 < CEnd; C1++)
        {   if ( C1.pos() != *C1) cout<<"Error gordo \n\n";
            cout<<( *C1)<<"  ";
        };
        cout<<endl<<endl ;

        cout<<"Recorrido de uno en uno hacia adelante ----->\n";
        for (C1=CREnd ;C1 != (CBegin+8); )
        {   cout<<( *(++C1))<<"  ";
        };
        cout<<endl<<endl ;

        //-------------------------------------------------------
        // Recorido de dos en dos hacia adelante
        //------------------------------------------------------
        cout<<"Recorrido de dos en dos hacia adelante -------->\n";
        for (C1=CBegin;C1 != CEnd; C1+= 2)
        {   cout<< *C1<<"  ";
        };
        cout<<endl<<endl ;


        //--------------------------------------------------------
        // Recorrido de uno en uno hacia atras
        //--------------------------------------------------------
        cout<<"Recorrido de uno en uno hacia atras ----->\n";
        for (C1=CBegin+8 ;C1 > CREnd; C1--)
        {   cout<< *C1<<"  ";
        };
        cout<<endl<<endl ;

        cout<<"Recorrido de uno en uno hacia atras ----->\n";
        for (C1=CEnd ;( C1-( CEnd - 9 )) != 0 ; )
        {   cout<< *(--C1)<<"  ";
        };
        cout<<endl<<endl ;
        //-------------------------------------------------------
        // Recorido de dos en dos hacia atras
        //------------------------------------------------------
        cout<<"Recorrido de dos en dos hacia atras -------->\n";
        for (C1=CBegin+8;C1 != CREnd; C1-= 2)
        {   cout<< *C1<<"  ";
        };
        cout<<endl<<endl ;

        //============================================================
        //
        //              L A B O R A T O R I O
        //
        //============================================================
        iterator <int> Alfa ( &N[0],&MBT), Beta (Alfa );

        Alfa = iterator <int>::begin(Beta) + 12 ;
        cout<<( std::distance (Beta ,Alfa))<<endl;
        if ( Alfa == iterator <int>::end(Beta)) cout<<"Iterators iguales \n";
        else                     cout<<"Iterators distintos\n";
        Alfa -= 2 ;
        cout<<(*Alfa)<<endl;
        Alfa = Beta ;
        std::advance(Alfa , 9 );
        if ( Alfa == iterator <int>::end(Beta)) cout<<"Iterators iguales \n";
        else                     cout<<"Iterators distintos\n";

        struct MEmptyBasicTree:public basic_tree<int>
        {   //---------------------- Begin -----------------------------
            size_type size(void)const{ return 0 ;};

            node<int> * get_first ( void)  {return NULL;} ;
            const node<int> * get_first ( void) const {return NULL;} ;

            node<int> * get_last  ( void) {return NULL;} ;
            const node<int> * get_last  ( void) const {return NULL;} ;
        } EBT ;

        iterator<int> Delta (NULL, &EBT);
        cout<<"Delta "<<Delta<<endl;
        iterator<int> DBegin ( iterator<int>::begin(Delta));
        iterator<int> DEnd   ( iterator<int>::end(Delta));
        iterator<int> DRBegin( iterator<int>::rbegin(Delta));
        iterator<int> DREnd  ( iterator<int>::rend(Delta));
        cout<<"begin, end "<<DBegin<<"  "<<DEnd<<endl;
        cout<<"rbegin , rend "<<DRBegin<<"  "<<DREnd<<endl;
    };


    //==============================================================
    //                    C O N S T C U R S O R
    //===============================================================
    {   const_iterator <int> C1 = iterator<int> ( &N[0],&MBT);
        const_iterator <int> CBegin(C1);
        cout<<C1<<"   "<<CBegin<<endl;

        const_iterator<int> CRBegin (const_iterator<int>::rbegin(CBegin)) ;
        const_iterator<int> CEnd    (const_iterator<int>::end(CBegin)) ;
        const_iterator<int> CREnd   (const_iterator<int>::rend(CBegin));
        //-------------------------------------------------------
        // Recorido de uno en uno hacia adelante
        //------------------------------------------------------
        cout<<"Recorrido de uno en uno hacia adelante ----->\n";
        for (C1=CBegin ;C1 < CEnd; C1++)
        {   if ( C1.pos() != *C1) cout<<"Error gordo \n\n";
            cout<<( *C1)<<"  ";
        };
        cout<<endl<<endl ;

        cout<<"Recorrido de uno en uno hacia adelante ----->\n";
        for (C1=CREnd ;C1 != (CBegin+8); )
        {   cout<<( *(++C1))<<"  ";
        };
        cout<<endl<<endl ;

        //-------------------------------------------------------
        // Recorido de dos en dos hacia adelante
        //------------------------------------------------------
        cout<<"Recorrido de dos en dos hacia adelante -------->\n";
        for (C1=CBegin;C1 != CEnd; C1+= 2)
        {   cout<< *C1<<"  ";
        };
        cout<<endl<<endl ;


        //--------------------------------------------------------
        // Recorrido de uno en uno hacia atras
        //--------------------------------------------------------
        cout<<"Recorrido de uno en uno hacia atras ----->\n";
        for (C1=CBegin+8 ;C1 > CREnd; C1--)
        {   cout<< *C1<<"  ";
        };
        cout<<endl<<endl ;

        cout<<"Recorrido de uno en uno hacia atras ----->\n";
        for (C1=CEnd ;( C1 -(CEnd -9 )) != 0 ; )
        {   cout<< *(--C1)<<"  ";
        };
        cout<<endl<<endl ;
        //-------------------------------------------------------
        // Recorido de dos en dos hacia atras
        //------------------------------------------------------
        cout<<"Recorrido de dos en dos hacia atras -------->\n";
        for (C1=CBegin+8;C1 != CREnd; C1-= 2)
        {   cout<< *C1<<"  ";
        };
        cout<<endl<<endl ;

        //============================================================
        //
        //              L A B O R A T O R I O
        //
        //============================================================
        const_iterator <int> Alfa ( &N[0],&MBT), Beta (Alfa );

        Alfa = const_iterator<int>::begin(Beta) + 12 ;
        cout<<( std::distance (Beta ,Alfa))<<endl;
        if ( Alfa == const_iterator<int>::end(Beta)) cout<<"Iterators iguales \n";
        else                     cout<<"Iterators distintos\n";
        Alfa -= 2 ;
        cout<<(*Alfa)<<endl;
        Alfa = Beta ;
        std::advance(Alfa , 9 );
        if ( Alfa == const_iterator<int>::end(Beta)) cout<<"Iterators iguales \n";
        else                     cout<<"Iterators distintos\n";

        struct MEmptyBasicTree:public basic_tree<int>
        {   //---------------------- Begin -----------------------------
            size_type size(void)const{ return 0 ;};

            node<int> * get_first ( void)  {return NULL;} ;
            const node<int> * get_first ( void) const {return NULL;} ;

            node<int> * get_last  ( void) {return NULL;} ;
            const node<int> * get_last  ( void) const {return NULL;} ;
        } EBT ;

        const_iterator<int> Delta (NULL, &EBT);
        cout<<"Delta "<<Delta<<endl;
        const_iterator<int> DBegin ( const_iterator<int>::begin(Delta));
        const_iterator<int> DEnd   ( const_iterator<int>::end(Delta));
        const_iterator<int> DRBegin( const_iterator<int>::rbegin(Delta));
        const_iterator<int> DREnd  ( const_iterator<int>::rend(Delta));
        cout<<"begin, end "<<DBegin<<"  "<<DEnd<<endl;
        cout<<"rbegin , rend "<<DRBegin<<"  "<<DREnd<<endl;
    };

    return 0 ;

} ;
