///----------------------------------------------------------------------------
// FILE : test_map_02.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#include <iostream>
#include <stdlib.h>
#include <boost/countertree/map.hpp>

typedef std::pair<const int, double> PID ;

std::ostream & operator << ( std::ostream &salida, const PID &P)
{   salida<<"("<<P.first<<" , "<<P.second<<") ";
    return salida ;
};

int  main ( void)
{   //-------------------------- begin--------------------
    cntree::map<int, double> M1;
    for ( int i = 1000 ; i < 3000 ; i+= 2) M1.insert (PID(i, rand()));

    cntree::map<int,double>::iterator Gamma, Beta  ;
    Gamma = M1.lower_bound( 2000);
    Beta = M1.end() - 50 ;

    for ( int i = Gamma.pos() ; i < Beta.pos() ; ++i)
        std::cout<<M1.at(i)<<std::endl;
    return 0 ;
};

