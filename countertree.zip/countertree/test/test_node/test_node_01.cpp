///----------------------------------------------------------------------------
// FILE : test_node_01.cpp
//
// DESCRIPTION : Test program of the class node
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define  __DEBUG_MODE 2
#include <iostream>
#include <boost/countertree/tools/debug_node.hpp>

using namespace std ;
using namespace cntree::tools;

int  main ( void)
{	//------------- Inicio -----------------
	node<int> N1(3) ,N2(5),N3(N1);
	cout<<"N1(3) ,N2(5),N3(N1) ------------->"<<endl;
	cout<<N1<<endl<<N2<<endl<<N3<<endl;
	N3.data = 7;
	N2.set_red() ;
	cout<<"Color test ( true, false, false , true true"<<endl;
	cout<<(N1.is_black() ) <<"  "<<(N1.is_red() );
	cout<<(N2.is_black() ) <<"  "<<(N2.is_red() ) <<"  " ;
	N2.set_black() ;
	cout<<(N2.is_black() ) <<endl<<endl ;

    // Pruebas con Pnode y constPnode
    cout<<"Pointer and const pointer tests ( 3, 3 , 7 , 7 )\n";
	node<int> *p1( &N1), *p3(&N3) , *p2 ( NULL);
	const node<int> *cp1( & N1 ) , *cp3 ( & N3) ;
	cout<<( *p1)<<endl<<(*cp1)<<endl<<( *p3) <<endl<<( *cp3)<<endl<<endl;
    p2 = p1 ;

    N1.up = NULL ;
	N1.right = &N2 ;
	N2.up = &N1 ;
	N2.left = &N3 ;
	N3.up = & N2 ;
	N1.N = 3 ;
	N2.N = 2 ;
	cout<<N1<<endl<<N2<<endl<<N3<<endl<<endl;

	cout<<"Previous and next test ------------------------->"<<endl;
	cout<<N3<<endl;
	p1 = N3.previous() ;
	cout<<( *p1) <<endl;
	p1 = p1->next() ;
	cout<<( *p1) <<endl<<endl;

	cout<<"Shift test ----------------------------->"<<endl;
	cout<<N1<<endl ;
	p1 =N1.shift(2) ;
	cout<<(*p1)<<endl;
	p1 = p1->shift ( -2) ;
	cout<<(*p1)<<endl<<endl;


	node <int> N[15] ;
	node<int>  *Padre = NULL ;
    for ( uint32_t i = 0 ; i < 15 ; i ++ )
    {   N[i].init() ;
        N[i].data = i ;
    };

   	cout<<"-----------------------------------------------------------\n";
    cout<<"             swap_contiguous_left\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[2] ;
    N[2].N= 5 ;
    N[2].left = &N[1] ;
    N[1].up  = &N[2] ;
    N[2].right = &N[4] ;
    N[4].up  = &N[2] ;

    N[1].N = 2 ;
    N[1].left = &N[0] ;
    N[0].up  = &N[1] ;
    N[4].N = 2 ;
    N[4].left = &N[3] ;
    N[3].up  = &N[4] ;


    N[0].set_red();
    N[1].set_black() ;
    N[2].set_black() ;
    N[3].set_red() ;
    N[4].set_black() ;

    if ( not Colombo<int> ( NULL , Padre , 2 , true, cout))
    {   cout<<"Error in the struct\n\n";
        return 1 ;
    };
    print_tree_struct(cout,Padre);
    node<int>::swap_contiguous_left(&Padre);
    if ( not Colombo<int> ( NULL , Padre , 2 , true,cout))
    {   cout<<"Error in the struct\n\n";
        return 1 ;
    };
    print_tree_struct( cout,Padre);


   	cout<<"-----------------------------------------------------------\n";
    cout<<"                  swap_node\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[3] ;
    N[3].set_black() ;
    N[3].N= 5 ;
    N[3].left = &N[1] ;
    N[1].up  = &N[3] ;
    N[3].right = &N[4] ;
    N[4].up  = &N[3] ;

    N[1].set_red() ;
    N[1].N = 3 ;
    N[1].left = &N[0] ;
    N[0].up  = &N[1] ;
    N[1].right = &N[2] ;
    N[2].up  = &N[1] ;
    N[0].set_black();
    N[2].set_black() ;
    N[4].set_black() ;

    node<int> **PPup = &Padre , **PPInf = &N[1].right ;
    if ( not Colombo<int> ( NULL , Padre , 2 , true,cout))
    {   cout<<"Error in the struct\n\n";
        return 1 ;
    };

    print_tree_struct(cout,Padre);
    //cout<<"PPup :"<<**PPup<<endl<<"PPInf :"<<**PPInf<<endl;
    node<int>::swap_node(PPup, PPInf);
    print_tree_struct(cout,Padre);
    if ( not Colombo<int> ( NULL , Padre , 2 , true,cout))
    {   cout<<"Error in the struct\n\n";
        return 1 ;
    };

/*
	p1 = &N1 ;
	p3 = &N3 ;


	Intercambiar (p1,N2.left);
	cout<<"Intercambio N1 , N3 N3->right->N2->left->N1\n";
	cout<<" p1 : "<<p1<<endl ;
	cout<<N1<<N2<<N3 <<endl;
	cout<<"Intercambio N2 , N3   N2->right->N3->left->N1\n";
	Intercambiar (p3,N3.right);
	cout<<" p3 : "<<p3<<endl ;

	cout<<N1<<N2<<N3 <<endl;

*/
    return 0 ;
};
