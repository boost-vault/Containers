///----------------------------------------------------------------------------
// FILE : test_node_02.cpp
//
// DESCRIPTION : Test program of the class node
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <boost/countertree/tools/debug_node.hpp>

using namespace cntree::tools;
using namespace std;

int main ( void )
{   //------------------------ Inicio ----------------------------------

    //------------- Inicio -------------------
	node <int> N[15] ;
	node<int>  *Father = NULL ;
    int32_t i ;

    for ( i = 0 ; i < 15 ; i ++ )
    {   N[i].init() ;
        N[i].data = i ;
    };
;

	cout<<"-----------------------------------------------------------\n";
    cout<<"                  Caso 02\n";
    cout<<"-----------------------------------------------------------\n";

    Father = &N[5] ;
    N[5].up = NULL ;
    N[5].N = 9 ;
    N[5].set_black();

    N[5].left = &N[3] ;
    N[3].up = &N[5] ;
    N[3].N = 5 ;
    N[3].set_red();

    N[3].left = &N[1] ;
    N[1].up = &N[3] ;
    N[1].N = 3 ;
    N[1].set_black();

    N[1].left = & N[0] ;
    N[0].up = &N[1] ;
    N[0].N = 1 ;
    N[0].set_red();

    N[1].right= & N[2] ;
    N[2].up = &N[1] ;
    N[2].N = 1 ;
    N[2].set_red() ;

    N[3].right = &N[4] ;
    N[4].up = &N[3] ;
    N[4].N = 1 ;
    N[4].set_black();

    N[5].right = &N[7] ;
    N[7].up = & N[5] ;
    N[7].N = 3 ;
    N[7].set_black() ;

    N[7].left = &N[6] ;
    N[6].up = &N[7] ;
    N[6].N = 1 ;
    N[6].set_red();

    N[7].right = & N[8] ;
    N[8].up = &N[7] ;
    N[8].N = 1 ;
    N[8].set_red();

    cout<<"is_black is_red ( 1, 0 ) ->"<<N[5].is_black()<<"  "<<N[5].is_red()<<endl;
    cout<<"is_black is_red ( 0, 1 ) ->"<<N[6].is_black()<<"  "<<N[6].is_red()<<endl;
    cout<<"n_left n_right (5 , 3 ) ->"<<N[5].n_left()<<"  "<<N[5].n_right()<<endl;
    cout<<"nd (5 , 3 ) ->"<<node<int>::nd(N[5].left)<<"  "<<node<int>::nd (N[5].right)<<endl;
    print_tree_struct(cout,Father);
    if (not  Colombo<int>( NULL,Father,2,false,cout))
        cout<<"Error \n";
    //==============================================================
    //                    C U R S O R
    //===============================================================

    node<int> *Alfa;

    //-------------------------------------------------------
    // Recorido de uno en uno hacia adelante
    //------------------------------------------------------
    cout<<"Recorrido de uno en uno hacia adelante ----->\n";

    for ( i = 0,Alfa = &N[0] ; Alfa != NULL; Alfa = Alfa->next(), i++)
    {   cout<<Alfa->data<<"  ";
        if ( Alfa->get_pos() != i)
            cout<<"Error en la posicion del iterator   \n";
    };
    cout<<endl<<endl ;
    //-------------------------------------------------------
    // Recorido de dos en dos hacia adelante
    //------------------------------------------------------
    cout<<"Recorrido de dos en dos hacia adelante -------->\n";
    for ( Alfa=&N[0];Alfa != NULL; Alfa = Alfa->shift(2))
    {   cout<<Alfa->data<<"  ";
    };
    cout<<endl<<endl ;
    //--------------------------------------------------------
    // Recorrido de uno en uno hacia atras
    //--------------------------------------------------------
    cout<<"Recorrido de uno en uno hacia atras ----->\n";
    for ( Alfa = &N[8] ; Alfa != NULL ;Alfa = Alfa->previous() )
    {   cout<<Alfa->data<<"  ";
    };
    cout<<endl<<endl ;
    //-------------------------------------------------------
    // Recorido de dos en dos hacia atras
    //------------------------------------------------------
    cout<<"Recorrido de dos en dos hacia atras -------->\n";
    for ( Alfa = &N[8] ; Alfa != NULL ;Alfa = Alfa->shift(-2) )
    {   cout<<Alfa->data<<"  ";
    };
    cout<<endl<<endl;
    Alfa = &N[0] ;
    cout<< (Alfa =Alfa->shift(6))->data<<endl;
    cout<< ( Alfa = Alfa->shift(-2) )->data<<"   ";
    cout<<(Alfa->get_pos())<<endl;



    //==============================================================
    //                    C U R S O R
    //===============================================================

    node<int> *Beta;
    //-------------------------------------------------------
    // Recorido de uno en uno hacia adelante
    //------------------------------------------------------
    cout<<"Recorrido de uno en uno hacia adelante ----->\n";
    for ( Beta = &N[0] ; Beta != NULL; Beta = Beta->next())
    {   cout<<Beta->data<<"  ";
    };
    cout<<endl<<endl ;
    //-------------------------------------------------------
    // Recorido de dos en dos hacia adelante
    //------------------------------------------------------
    cout<<"Recorrido de dos en dos hacia adelante -------->\n";
    for ( Beta=&N[0];Beta != NULL; Beta = Beta->shift(2))
    {   cout<<Beta->data<<"  ";
    };
    cout<<endl<<endl ;
    //--------------------------------------------------------
    // Recorrido de uno en uno hacia atras
    //--------------------------------------------------------
    cout<<"Recorrido de uno en uno hacia atras ----->\n";
    for ( Beta = &N[8] ; Beta != NULL ;Beta = Beta->previous() )
    {   cout<<Beta->data<<"  ";
    };
    cout<<endl<<endl ;
    //-------------------------------------------------------
    // Recorido de dos en dos hacia atras
    //------------------------------------------------------
    cout<<"Recorrido de dos en dos hacia atras -------->\n";
    for ( Beta = &N[8] ; Beta != NULL ;Beta = Beta->shift(-2) )
    {   cout<<Beta->data<<"  ";
    };
    cout<<endl<<endl;
    Beta = &N[0] ;
    cout<< (Beta =Beta->shift(6))->data<<endl;
    cout<< ( Beta = Beta->shift(-2) )->data<<"   ";
    cout<<(Beta->get_pos())<<endl;

    return 0 ;
} ;
