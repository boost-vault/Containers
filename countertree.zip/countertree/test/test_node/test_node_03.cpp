///----------------------------------------------------------------------------
// FILE :test_node_03.cpp
//
// DESCRIPTION : Test program of the class branch
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco Jos� Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <stdlib.h>
#include <boost/countertree/tools/debug_node.hpp>


using namespace std ;
using namespace cntree::tools;

int  main ( void)
{   //------------------------- Inicio ----------------------------------
    node <int> N[15] ;
	node<int>  *Padre = NULL ;

	//------------- Estructura b�sica -------------
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].data = i ;

    cout<<"-----------------------------------------------------------\n";
    cout<<"   RotarleftAlineados y RotarrightAlineados con 2 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[1] ;
    N[1].set_black();
    N[1].N = 5 ;

    N[1].left = &N[0] ;
    N[0].up = &N[1] ;
    N[0].set_black() ;
    N[0].N = 1 ;

    N[1].right = &N[3] ;
    N[3].up = &N[1] ;
    N[3].set_red() ;
    N[3].N = 3 ;

    N[3].left = &N[2] ;
    N[2].up =&N[3] ;
    N[2].set_black() ;
    N[2].N = 1 ;

    N[3].right = &N[4] ;
    N[4].up = &N[3] ;
    N[4].set_black() ;
    N[4].N = 1 ;

    //ImprimirEstructura ( Padre) ;
    if ( not Colombo<int> ( NULL, Padre, 2 , true, cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };

    print_tree_struct( cout , Padre);
    node<int>::rotate_left_aligned( & Padre) ;
    print_tree_struct( cout , Padre);
    //if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    //{   cout<<"Error en la ESTRUCTURA \n\n";
    //    exit(1) ;
    //};
    node<int>::rotate_right_aligned(&Padre) ;
    print_tree_struct( cout , Padre);
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };

    cout<<"-----------------------------------------------------------\n";
    cout<<"   RotarleftAlineados  con 3 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ )   N[i].init() ;
    Padre = &N[1] ;
    N[1].set_black();
    N[1].N = 7 ;

    N[1].left = &N[0] ;
    N[0].up = &N[1] ;
    N[0].set_black() ;
    N[0].N = 1 ;

    N[1].right = &N[3] ;
    N[3].up = &N[1] ;
    N[3].set_red() ;
    N[3].N = 5 ;

    N[3].left = &N[2] ;
    N[2].up =&N[3] ;
    N[2].set_black() ;
    N[2].N = 1 ;

    N[3].right = &N[5] ;
    N[5].up = &N[3] ;
    N[5].set_red() ;
    N[5].N = 3 ;

    N[5].left = &N[4] ;
    N[4].up = &N[5] ;
    N[4].set_black();
    N[4].N = 1 ;

    N[5].right = & N[6] ;
    N[6].up = &N[5] ;
    N[6].set_black();
    N[6].N = 1 ;


    print_tree_struct( cout , Padre);
    node<int>::rotate_left_aligned( &Padre) ;
    print_tree_struct( cout , Padre);
    //if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    //{   cout<<"Error en la ESTRUCTURA \n\n";
    //    exit (1);
    //};
    //ImprimirEstructura(Padre);

    cout<<"-----------------------------------------------------------\n";
    cout<<"   RotarrightAlineados  con 3 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ )  N[i].init() ;

    Padre = &N[5] ;
    N[5].set_black();
    N[5].N = 7 ;

    N[5].left = &N[3] ;
    N[3].up = &N[5] ;
    N[3].set_red() ;
    N[3].N = 5 ;

    N[5].right = &N[6] ;
    N[6].up = &N[5] ;
    N[6].set_black();
    N[6].N = 1 ;

    N[3].left = &N[1] ;
    N[1].up = &N[3] ;
    N[1].set_red() ;
    N[1].N = 3 ;

    N[3].right = &N[4] ;
    N[4].up = &N[3] ;
    N[4].set_black();
    N[4].N = 1 ;

    N[1].left = &N[0] ;
    N[0].up = &N[1] ;
    N[0].set_black() ;
    N[0].N = 1 ;

    N[1].right = &N[2] ;
    N[2].up = &N[1] ;
    N[2].set_black() ;
    N[2].N = 1 ;

    print_tree_struct( cout , Padre);
    node<int>::rotate_right_aligned(&Padre) ;
    print_tree_struct( cout , Padre);


    cout<<"-----------------------------------------------------------\n";
    cout<<"   RotarleftNoAlineados  con 3 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ ) N[i].init() ;

    Padre = &N[1] ;
    N[1].set_black();
    N[1].N = 7 ;

    N[1].left = &N[0] ;
    N[0].up = &N[1] ;
    N[0].set_black() ;
    N[0].N = 1 ;

    N[1].right = &N[5] ;
    N[5].up = &N[1] ;
    N[5].set_red() ;
    N[5].N = 5 ;

    N[5].left = &N[3] ;
    N[3].up = &N[5] ;
    N[3].set_red() ;
    N[3].N = 3 ;

    N[3].left = &N[2] ;
    N[2].up =&N[3] ;
    N[2].set_black() ;
    N[2].N = 1 ;

    N[3].right = &N[4] ;
    N[4].up = &N[3] ;
    N[4].set_black();
    N[4].N = 1 ;

    N[5].right = & N[6] ;
    N[6].up = &N[5] ;
    N[6].set_black();
    N[6].N = 1 ;

    print_tree_struct( cout , Padre);
    node<int>::rotate_left_not_aligned(&Padre) ;
    print_tree_struct( cout , Padre);


    cout<<"-----------------------------------------------------------\n";
    cout<<"   rotate_right_not_aligned  with 3 nodes\n";
    cout<<"-----------------------------------------------------------\n";
    for ( uint32_t i = 0 ; i < 15 ; i ++ )  N[i].init() ;

    Padre = &N[5] ;
    N[5].set_black();
    N[5].N = 7 ;

    N[5].left = &N[1] ;
    N[1].up = &N[5] ;
    N[1].set_red() ;
    N[1].N = 5 ;

    N[5].right = &N[6] ;
    N[6].up = &N[5] ;
    N[6].set_black();
    N[6].N = 1 ;

    N[1].left = &N[0] ;
    N[0].up = &N[1] ;
    N[0].set_black() ;
    N[0].N = 1 ;

    N[1].right = &N[3] ;
    N[3].up = &N[1] ;
    N[3].set_red() ;
    N[3].N = 3 ;

    N[3].right = &N[4] ;
    N[4].up = &N[3] ;
    N[4].set_black();
    N[4].N = 1 ;


    N[3].left = &N[2] ;
    N[2].up = &N[3] ;
    N[2].set_black() ;
    N[2].N = 1 ;


    print_tree_struct( cout , Padre);
    node<int>::rotate_right_not_aligned(&Padre) ;
    print_tree_struct( cout , Padre);
    if ( not Colombo<int> ( NULL, Padre, 2 , true,cout))
    {   cout<<"Error en la ESTRUCTURA \n\n";
        exit (1);
    };

}; //----------------- Fin funcion Rotacion ---------------------
