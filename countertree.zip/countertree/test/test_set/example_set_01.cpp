///----------------------------------------------------------------------------
// FILE : TestSet_01.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#include <stdlib.h>
#include <boost/countertree/set.hpp>
#include <iostream>

int main ( void )
{   //------------------------ begin --------------------
    cntree::set<int> A ;
    for ( int i = 0 ; i< 100 ; ++i)  A.insert(i);
    cntree::set<int>::iterator Alfa, Beta ;

    Alfa = A.lower_bound( 45 );
    Beta = A.end() - 10 ;
    std::cout<<"Alfa.pos() --->"<<Alfa.pos();
    std::cout<<"  Beta.pos()--->"<<Beta.pos()<<std::endl;
    for ( int i = Alfa.pos() ; i < Beta.pos() ; ++i)
        std::cout<<A.at(i)<<" , ";
    std::cout<<std::endl;
    return 0 ;
};
