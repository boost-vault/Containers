///----------------------------------------------------------------------------
// FILE : test_sorted_vector_tree_01.cpp
//
// DESCRIPTION : Test program of the class sorted_vector_tree
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <iostream>
#include <stdlib.h>
#include <boost/countertree/sorted_vector_tree.hpp>
#include <boost/countertree/tools/debug_sorted_vector_tree.hpp>

using std::cout ;
using std::endl ;
using cntree::sorted_vector_tree;


int  main ( void)
{   //---------------------- Variables----------------------------
    sorted_vector_tree<int> M1 ;

    //------------------------ Inicio -----------------------------
    cout<<"Objetos M1, M2 creados : OK "<<endl ;
    cout<<"Insercion (M1 size:7 1000, 1001,1002,1003,1004,1005,1006)"<<endl ;
    M1.insert_value(  1003 ) ;
    if ( not M1.check( ) )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    cout<<M1<<endl;
    M1.insert_value(  1001 ) ;
    if ( not M1.check( ) )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_value(  1005) ;
    if ( not M1.check( ) )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_value(  1000) ;
    if ( not M1.check( ) )
    {   cout<<"error en M1\n" ;
        return 0;
    };

    M1.insert_value(  1002) ;
    if ( not M1.check( ) )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_value(  1004) ;
    if ( not M1.check( ) )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_value( 1006) ;
    if ( not M1.check( ) )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    cout<<M1<<endl;;
    cntree::sorted_vector_tree<int>  M2(M1);
    if ( not M2.check( ) )
    {   cout<<"error en M2\n" ;
        return 0;
    };
    M2.clear() ;
    cout<<"Asignacion (M2 size:7 1000, 1001,1002,1003,1004,1005,1006)\n";

    M2 = M1 ;
    if ( not M2.check( ) )
    {   cout<<"error en M2\n" ;
        return 0;
    };
    cout<<M2<<endl;

    cout<<"Pruebas de supresion \n";
    cout<<"Suprimir 6 ";
    M1.erase_pos(6) ;
    if ( M1.check( ) ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };
    cout<<"Suprimir 0 ";
    M1.erase_pos(0) ;
    if ( M1.check( ) ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };
    cout<<"Suprimir 0 ";
    M1.erase_pos(0) ;
    if ( M1.check( ) ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };
    cout<<"Suprimir 3 ";
    M1.erase_pos(3) ;
    if ( M1.check( ) ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };
    cout<<"Suprimir 1";
    M1.erase_pos(1) ;
    if ( M1.check( ) ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };
    cout<<"Suprimir 1 ";
    M1.erase_pos(1) ;
    if ( M1.check( ) ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };
    cout<<"Suprimir 0 ";
    M1.erase_pos(0) ;
    if ( M1.check( ) ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.swap(M2);
    cout<<M1<<endl<<M2<<endl ;

    //Segunda prueba
    cout<<"Prueba insertar y suprimir al inicio y al final de la estructura\n";
    cout<<"( 14 , 15 , 16 , 17 , 18 , 19, 20 , 21 , 22 , 23 )\n";
    M2.clear() ;
    M1.clear() ;
    if (not M1.check()  or not M2.check())
    {   cout<<"error \n" ;
        return 0;
    };

    return 0 ;
};


