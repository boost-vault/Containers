///----------------------------------------------------------------------------
// FILE : test_sorted_vector_tree_02.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco Jos� Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <iostream>
#include <stdlib.h>

#include <boost/countertree/tools/debug_sorted_vector_tree.hpp>


using std::cout;
using std::endl;

void  Imprimir ( const cntree::sorted_vector_tree<int> & M );
int SinRepeticion ( void);
int ConRepeticion( void) ;

int  main ( void)
{
    cout<<"\nARbolVal sin repeticiones\n";
    SinRepeticion();
    cout<<"\nARbolVal con repeticiones\n";
    ConRepeticion() ;
    return 0 ;
};

int SinRepeticion ( void)
{   //---------------------- Variables----------------------------
    cntree::sorted_vector_tree<int> M1;
    int i  ;

    //-------------------------------------------------------------
    //     insert_value_unique, operator []
    //------------------------ Inicio -----------------------------
    cout<<"Objeto M1 creado : OK "<<endl ;
    for ( i = 1000 ; i < 3000 ; i+= 2)
    {   M1.insert_value ( i  );
        M1.insert_value ( i );
        //M1.insert_value_unique ( i  );
        //M1.insert_value_unique ( i );
    };

    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };

    cout<<"Examen de contenidos ( operator[] ) : " ;
    for ( i = 0 ; i < 1000 ; i ++ )
    {   if ( M1[i] != (1000 + i*2) )
        {   cout<<"error en M1\n" ;
            return 0;
        };
    };
    cout<<"OK\n";

    //----------------------------------------------------------------
    //                      find
    //----------------------------------------------------------------

    cout<<"find test --------------------------------->\n";

    // -------- Loop for find existent elements -------------------
    cntree::sorted_vector_tree<int>::const_iterator Gamma ;
    for ( i = 0 ; i < M1.size() ; ++i)
    {   Gamma = M1.find( 1000+ i * 2);
        if ( Gamma == M1.end() or (*Gamma)!= (1000+i*2))
            cout<<"Error en la busqueda de elementos que existen\n";
    };

    //--------- Loop for to find  non existent elements  ----------------
    for ( i = 0 ; i < M1.size() ; ++i)
    {   Gamma = M1.find( 1001+ i * 2);
        if ( Gamma != M1.end() )
            cout<<"Error en la busqueda de elementos que no existen\n";
    };

    //----- find first, last, lower than first, greater than last --------
    Gamma = M1.find(1000);
    if ( Gamma == M1.end() or Gamma != M1.begin())
        cout<<"Error en la busqueda del primero\n";

    Gamma = M1.find(2998);
    if ( Gamma == M1.end() or Gamma != M1.rbegin())
        cout<<"Error en la busqueda del ultimo\n";

    Gamma = M1.find(999);
    if ( Gamma != M1.end() )
        cout<<"Error en la busqueda del menor que el primero\n";

    Gamma = M1.find(2999);
    if ( Gamma != M1.end() )
        cout<<"Error en la busqueda del mayor que el ultimo\n";

    //-------------------------------------------------------------------
    //                      lower_bound
    //-------------------------------------------------------------------
    cout<<"Pruebas de lower_bound----------------------------->\n";

    //---- lower_bound to all existent elements ----------------------
    for ( i = 0 ; i < M1.size() ; ++i)
    {   Gamma = M1.lower_bound( 1000+ i * 2);
        if ( Gamma == M1.end() or (*Gamma)!= (1000+i*2))
            cout<<"Error en la busqueda de elementos que existen\n";
    };

    //--- lower_bound to non existent elements ---------------------------
    for ( i = 0 ; i < M1.size() ; ++i)
    {   Gamma = M1.lower_bound( 999+ i * 2);
        if ( Gamma == M1.end() or (*Gamma) != (1000+i*2))
            cout<<"Error en lower_bound de elementos que no existen\n";
    };

    //-- lower_bound : first, last, less than first, greater than last ----
    Gamma = M1.lower_bound(1000);
    if ( Gamma != M1.begin() or Gamma != M1.begin())
        cout<<"Error en la busqueda del primero\n";

    Gamma = M1.lower_bound(2998);
    if ( Gamma == M1.end() or Gamma != M1.rbegin())
        cout<<"Error en la busqueda del ultimo\n";

    Gamma = M1.lower_bound(999);
    if ( Gamma != M1.begin() or Gamma != M1.begin())
        cout<<"Error en la busqueda del primero\n";

    Gamma = M1.lower_bound(2999);
    if ( Gamma != M1.end() )
        cout<<"Error en la busqueda del mayor que el ultimo\n";



    //----------------------------------------------------------------------
    //                      upper_bound
    //----------------------------------------------------------------------
    cout<<"Pruebas de upper_bound ---------------------------------->\n";

    //------- loop for existent elements ------------------------------
    for ( i = 0 ; i  <999 ; ++i)
    {   Gamma = M1.upper_bound ( 1000 + i *2);
        if ( Gamma == M1.end() or ( *(Gamma -1) != ( 1000 + i * 2)))
            cout<<"Error upper_bound existent elements\n";
    };

    // --------- loop for non existent elements ---
    for ( i = 0 ; i  <1000 ; ++i)
    {   Gamma = M1.upper_bound ( 999 + i *2);
        if ( Gamma == M1.end() or ( (*Gamma)  != ( 1000 + i * 2)))
            cout<<"Error upper_bound noexistent elements\n";
    };

    Gamma = M1.upper_bound ( 1000);
    if ( (*Gamma) != 1002)
        cout<<"Error upper_bound  to the first element \n";

    Gamma = M1.upper_bound ( 2998);
    if ( Gamma != M1.end() )
        cout<<"Error upper_bound  to the last element \n";

    Gamma = M1.upper_bound ( 999);
    if ( Gamma != M1.begin())
        cout<<"Error upper_bound  to less than the first element \n";

    Gamma = M1.upper_bound ( 3000);
    if ( Gamma != M1.end() )
        cout<<"Error upper_bound  to greater than the last element \n";

    //------------------------------------------------------------------
    //                     equal_range
    //-------------------------------------------------------------------
    cout<<"equal_range --------------------------------------------->\n" ;

    std::pair < cntree::tools::iterator<int>, cntree::tools::iterator<int> > PI ;

    //--------------- loop for existent elements ---------------------------
    for ( i = 0 ; i < 1000 ; i ++ )
    {   PI = M1.equal_range(1000 + i *2 );
        if ((PI.second.pos() - PI.first.pos() ) != 1 or PI.first.pos() != i)
        {   cout<<"Error equal_range existent elements\n";
        };
    };

    //------------- loop for non existent elements -------------------------
    for ( i = 0 ; i < 1000 ; i ++ )
    {   PI = M1.equal_range(999 + i *2 );
        if ((PI.second.pos() != PI.first.pos() ) or PI.first.pos() != i)
        {   cout<<"Error equal_range non existent elements\n";
        };
    };


    cout<<"OK\n";

    return 0 ;
};

int ConRepeticion ( void)
{   //---------------------- Variables----------------------------
    cntree::sorted_vector_tree<int> M1;
    int i  ;
    cntree::tools::iterator <int> Alfa , Beta ;
    //------------------------ Inicio -----------------------------
    cout<<"Objeto M1 creado : OK "<<endl ;
    for ( i = 0 ; i < 1000 ; i ++)
    {   M1.insert_value ( 1000+ i *2 );
        M1.insert_value ( 1000+ i *2 );
        M1.insert_value ( 1000+ i *2 );

        //M1.insert_value ( 1000+ i *2 );
        //M1.insert_value ( 1000+ i *2 );
        //M1.insert_value ( 1000+ i *2 );
    };
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    // Lazo para examinar los contenidos
    cout<<"Examen de contenidos ( operator[] ) : \n" ;
    for ( i = 0 ; i < 1000 ; i ++ )
    {   if ( M1[i*3] != (1000 + i*2)    or
             M1[i*3 +1] != (1000 + i*2) or
             M1[i* 3 +2] != (1000 + i*2)   )
        {   cout<<"error en M1\n" ;
            return 0;
        };
    };

    //----------------------------------------------------------------
    //                      find
    //----------------------------------------------------------------

    cout<<"find test --------------------------------->\n";

    // -------- Loop for find existent elements -------------------
    cntree::sorted_vector_tree<int>::const_iterator Gamma ;
    for ( i = 0 ; i < 1000 ; ++i)
    {   Gamma = M1.find( 1000+ i * 2);
        if ( Gamma == M1.end() or (*Gamma)!= (1000+i*2) or
            (*(Gamma++))!= (1000+i*2) or (*(Gamma++))!= (1000+i*2))
            cout<<"Error en la busqueda de elementos que existen\n";
    };

    //--------- Loop for to find  non existent elements  ----------------
    for ( i = 0 ; i < 1000 ; ++i)
    {   Gamma = M1.find( 1001+ i * 2);
        if ( Gamma != M1.end() )
            cout<<"Error en la busqueda de elementos que no existen\n";
    };

    //----- find first, last, lower than first, greater than last --------
    Gamma = M1.find(1000);
    if ( Gamma == M1.end() or Gamma != M1.begin())
        cout<<"Error en la busqueda del primero\n";

    Gamma = M1.find(2998);
    if ( Gamma == M1.end() or Gamma != (M1.rbegin() -2))
        cout<<"Error en la busqueda del ultimo\n";

    Gamma = M1.find(999);
    if ( Gamma != M1.end() )
        cout<<"Error en la busqueda del menor que el primero\n";

    Gamma = M1.find(2999);
    if ( Gamma != M1.end() )
        cout<<"Error en la busqueda del mayor que el ultimo\n";

    //-------------------------------------------------------------------
    //                      lower_bound
    //-------------------------------------------------------------------
    cout<<"Pruebas de lower_bound----------------------------->\n";

    //---- lower_bound to all existent elements ----------------------
    for ( i = 0 ; i < 1000 ; ++i)
    {   Gamma = M1.lower_bound( 1000+ i * 2);
        if ( Gamma == M1.end() or (*Gamma)!= (1000+i*2) or
            (*(Gamma++))!= (1000+i*2) or (*(Gamma++))!= (1000+i*2))
            cout<<"Error en la busqueda de elementos que existen\n";
    };

    //--- lower_bound to non existent elements ---------------------------
    for ( i = 0 ; i < 1000 ; ++i)
    {   Gamma = M1.lower_bound( 999+ i * 2);
        if ( Gamma == M1.end() or (*Gamma)!= (1000+i*2) or
             (*(Gamma++))!= (1000+i*2) or (*(Gamma++))!= (1000+i*2))
            cout<<"Error en lower_bound de elementos que no existen\n";
    };

    //-- lower_bound : first, last, less than first, greater than last ----
    Gamma = M1.lower_bound(1000);
    if ( Gamma != M1.begin() or Gamma != M1.begin())
        cout<<"Error en la busqueda del primero\n";

    Gamma = M1.lower_bound(2998);
    if ( Gamma == M1.end() or Gamma != (M1.rbegin() -2))
        cout<<"Error en la busqueda del ultimo\n";

    Gamma = M1.lower_bound(999);
    if ( Gamma != M1.begin() or Gamma != M1.begin())
        cout<<"Error en la busqueda del primero\n";

    Gamma = M1.lower_bound(2999);
    if ( Gamma != M1.end() )
        cout<<"Error en la busqueda del mayor que el ultimo\n";



    //----------------------------------------------------------------------
    //                      upper_bound
    //----------------------------------------------------------------------
    cout<<"Pruebas de upper_bound ---------------------------------->\n";

    //------- loop for existent elements ------------------------------
    for ( i = 0 ; i  <999 ; ++i)
    {   Gamma = M1.upper_bound ( 1000 + i *2);
        if ( Gamma == M1.end() or ( *(Gamma -1) != ( 1000 + i * 2)))
            cout<<"Error upper_bound existent elements\n";
    };

    // --------- loop for non existent elements ---
    for ( i = 0 ; i  <1000 ; ++i)
    {   Gamma = M1.upper_bound ( 999 + i *2);
        if ( Gamma == M1.end() or ( (*Gamma)  != ( 1000 + i * 2)))
            cout<<"Error upper_bound noexistent elements\n";
    };

    Gamma = M1.upper_bound ( 1000);
    if ( (*Gamma) != 1002)
        cout<<"Error upper_bound  to the first element \n";

    Gamma = M1.upper_bound ( 2998);
    if ( Gamma != M1.end() )
        cout<<"Error upper_bound  to the last element \n";

    Gamma = M1.upper_bound ( 999);
    if ( Gamma != M1.begin())
        cout<<"Error upper_bound  to less than the first element \n";

    Gamma = M1.upper_bound ( 3000);
    if ( Gamma != M1.end() )
        cout<<"Error upper_bound  to greater than the last element \n";

    //------------------------------------------------------------------
    //                     equal_range
    //-------------------------------------------------------------------
    cout<<"equal_range --------------------------------------------->\n" ;

    std::pair < cntree::tools::iterator<int>, cntree::tools::iterator<int> > PI ;

    //--------------- loop for existent elements ---------------------------
    for ( i = 0 ; i < 1000 ; i ++ )
    {   PI = M1.equal_range(1000 + i *2 );
        if ((PI.second.pos() - PI.first.pos() ) != 3 or PI.first.pos() != i*3)
        {   cout<<"Error equal_range existent elements\n";
        };
    };

    //------------- loop for non existent elements -------------------------
    for ( i = 0 ; i < 1000 ; i ++ )
    {   PI = M1.equal_range(999 + i *2 );
        if ((PI.second.pos() != PI.first.pos() ) or PI.first.pos() != i*3)
        {   cout<<"Error equal_range non existent elements\n";
        };
    };


    cout<<"OK\n";
    return 0 ;
};

/*
int ConRepeticion ( void)
{   //---------------------- Variables----------------------------
    sorted_vector_tree<int> M1;
    int i  ;
    iterator <int> Alfa , Beta ;
    //------------------------ Inicio -----------------------------
    cout<<"Objeto M1 creado : OK "<<endl ;
    for ( i = 0 ; i < 1000 ; i ++)
    {   M1.insert_value ( 1000+ i *2 );
        M1.insert_value ( 1000+ i *2 );
        M1.insert_value ( 1000+ i *2 );
    };
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    // Lazo para examinar los contenidos
    cout<<"Examen de contenidos ( operator[] ) : " ;
    for ( i = 0 ; i < 1000 ; i ++ )
    {   if ( M1[i*3] != (1000 + i*2)    or
             M1[i*3 +1] != (1000 + i*2) or
             M1[i* 3 +2] != (1000 + i*2)   )
        {   cout<<"error en M1\n" ;
            return 0;
        };
    };
    cout<<"OK\n";
    // Lazo para encontrar todos los elementos insertados
    cout<<"Prueba BuscaIgualPrimero y BuscaIgualUltimo :" ;
    std::pair < iterator<int>, iterator<int> > PI ;
    for ( i = 0 ; i < 1000 ; i ++ )
    {   PI = M1.equal_range(1000 + i *2 );
        //N1 = M1.BuscaIgualPrimero ( 1000 + i *2 );
        //N2 = M1.BuscaIgualUltimo ( 1000 + i *2 );
        //if ( N1 != N2 OR N1 != i)
        if ( PI.first.pos() == PI.second.pos() or PI.first.pos() != i*3)
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";

    // Lazo para no encontrar ningun elemento insertado
    cout<<"Prueba de busqueda de elementos inexistentes :" ;
    for ( i = 0 ; i < 1000 ; i ++ )
    {   Alfa  = M1.find ( 1001 + i *2 );
        if ( Alfa != M1.end())
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";

    // Lazo para buscar mayor
    cout<<"Prueba de b�squeda de elementos mayores :" ;
    for ( i = 0 ; i < 1000  ; i++ )
    {   Alfa = M1.upper_bound ( 999 + i*2 );
        Beta = M1.upper_bound ( 1000 + i *2 ) ;
        if ( Alfa.pos() != i*3 or Beta.pos() != (i* 3+3 ) )
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";

    // Lazo para buscar menor
    cout<<"Prueba de busqueda de elementos menores :" ;
    for ( i = 0 ; i < 1000  ; i++ )
    {   Alfa= M1.lower_bound( 1001 + i*2 );
        Beta= M1.lower_bound( 1002 + i *2 ) ;
        if ( Alfa.pos() != i*3+3 or Beta.pos() != (i*3 +3 ) )
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";

    //Imprimir ( M1 ) ;

    return 0 ;
};
*/
void Imprimir ( const cntree::sorted_vector_tree<int> & M )
{   cout<<"size : "<<M.size()<<'\n' ;
    for ( int i = 0 ; i < M.size() ; i ++ )
        cout<<M[i]<<"\t" ;
    cout<<endl ;
};

