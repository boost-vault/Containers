///----------------------------------------------------------------------------
// FILE : test_sorted_vector_tree_03.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco Jos� Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <iostream>
#include <stdlib.h>

#include <boost/countertree/tools/debug_sorted_vector_tree.hpp>
#include <boost/countertree/sorted_vector_tree.hpp>


using std::cout ;
using std::endl ;
using cntree::sorted_vector_tree;


int  main ( void)
{   //---------------------------------------------------------------
    //    F U N C I O N E S
    //-----------------------------------------------------------
    void Imprimir ( const sorted_vector_tree<int> & M );
    int SinRepeticion ( void);
    int ConRepeticion( void) ;

    cout<<"\nArbolVal sin repeticiones\n";
    SinRepeticion();

    cout<<"\nArbolVal con repeticiones\n";
    ConRepeticion() ;

    return 0 ;
};
int  SinRepeticion ( void)
{   //---------------------- Variables----------------------------
    sorted_vector_tree<int> M1;

    void Imprimir ( const sorted_vector_tree<int> & M );
    cntree::tools::size_type i ;
    sorted_vector_tree<int>::const_iterator alfa,N1 , N2 ;

    //------------------------ Inicio -----------------------------
    cout<<"Objeto M1 creado : OK "<<endl ;
    for ( i = 0 ; i < 1000 ; i ++)
    {   M1.insert_value_unique( 1000+ i *2 );
    };

    //---------------------------------------------------------------
    //  a ver si
    if ( not M1.check())
    {   cout<<"error en M1\n" ;
        return 0;
    };
    // Lazo para examinar los contenidos
    cout<<"Examen de contenidos ( operator[] ) : " ;
    for ( i = 0 , N1 = M1.begin(); N1 != M1.end() ; ++N1, i++)
    {   if ( *N1 != (1000 + i*2) )
        {   cout<<"error en M1\n" ;
            return 0;
        };
    };
    cout<<"OK\n";
    // Lazo para encontrar todos los elementos insertados
    cout<<"Prueba CursorIgualPrimero y CursorIgualUltimo :" ;
    for ( i = 0 ; i < 1000 ; i ++ )
    {   N1 = M1.lower_bound( 1000 + i *2 );
        N2 = M1.upper_bound( 1000 + i *2 );

        if ( N1 == N2 or
             N1.pos() != i)
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";

    // Lazo para no encontrar ningun elemento insertado
    cout<<"Prueba de busqueda de elementos inexistentes :" ;
    for ( i = 0 ; i < 1000 ; i ++ )
    {   N1 = M1.lower_bound( 1001 + i *2 );
        N2 = M1.upper_bound( 1001 + i *2 );
        if ( N1 != N2 or N1 != M1.end())
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";
    // Lazo para buscar mayor
    cout<<"Prueba de b�squeda de elementos mayores :" ;
    for ( i = 0 ; i < 1000  ; i++ )
    {   N1 = M1.upper_bound( 999 + i*2 );
        N2 = M1.upper_bound( 1000 + i *2 ) ;
        if ( N1.pos() != i or N2.pos() != (i+1 ) )
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";
    // Lazo para buscar menor
    cout<<"Prueba de busqueda de elementos menores :" ;
    for ( i = 0 ; i < 1000  ; i++ )
    {   N1 = M1.lower_bound( 1001 + i*2 );
        N2 = M1.lower_bound( 1002 + i *2 ) ;
        if ( N1.pos() != i or N2.pos() != i  )
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";

    //Imprimir ( M1 ) ;

    return 0 ;
};
int  ConRepeticion ( void)
{   //---------------------- Funciones -------------------------
    void Imprimir ( const sorted_vector_tree<int> & M );

    //---------------------- Variables----------------------------
    sorted_vector_tree<int> M1;
    sorted_vector_tree<int>::const_iterator alfa,N1 , N2 ;
    int i ;

    //------------------------ Inicio -----------------------------
    cout<<"Objeto M1 creado : OK "<<endl ;
    for ( i = 0 ; i < 1000 ; i ++)
    {   M1.insert_value( 1000+ i *2 );
        M1.insert_value( 1000+ i *2 );
        M1.insert_value( 1000+ i *2 );
    };

    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    // Lazo para examinar los contenidos
    cout<<"Examen de contenidos ( operator[] ) : " ;
    for ( i = 0 , N1 = M1.begin(); N1 != M1.end() ; N1+=3, i++)
    {   if ( *N1 != (1000 + i*2)     or
             *(N1+1) != (1000 + i*2) or
             *(N1+2) != (1000 + i*2)     )
        {   cout<<"error en M1\n" ;
            return 0;
        };
    };
    cout<<"OK\n";
    // Lazo para encontrar todos los elementos insertados
    cout<<"Prueba CursorIgualPrimero y CursorIgualUltimo :" ;
    for ( i = 0 ; i < 1000 ; i ++ )
    {   N1 = M1.find ( 1000 + i *2 );

        if ( M1.count ( 1000 + i *2 ) != 3 or N1.pos() != i*3)
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";

    // Lazo para no encontrar ningun elemento insertado
    cout<<"Prueba de busqueda de elementos inexistentes :" ;
    for ( i = 0 ; i < 1000 ; i ++ )
    {   N1 = M1.lower_bound( 1001 + i *2 );
        N2 = M1.upper_bound( 1001 + i *2 );
        if ( N1 != N2 or N1 != M1.end())
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";
    // Lazo para buscar mayor
    cout<<"Prueba de b�squeda de elementos mayores :" ;
    for ( i = 0 ; i < 1000  ; i++ )
    {   N1 = M1.upper_bound( 999 + i*2 );
        N2 = M1.upper_bound(1000 + i *2 ) ;
        if ( N1.pos() != i*3 or N2.pos() != (i*3+3 ) )
        {   cout<<"Error en la busqueda \n";
            return 0 ;
        };
    };
    cout<<"OK\n";


    //Imprimir ( M1 ) ;

    return 0 ;
};
void Imprimir ( const sorted_vector_tree<int> & M )
{   cout<<"size : "<<M.size()<<'\n' ;
    for ( int i = 0 ; i < M.size() ; i ++ )
        cout<<M[i]<<"\t" ;
    cout<<endl ;
};

