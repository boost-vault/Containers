///----------------------------------------------------------------------------
// FILE : test_sorted_vector_tree_04.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <iostream>
#include <stdlib.h>

#include <boost/countertree/sorted_vector_tree.hpp>


using cntree::sorted_vector_tree;

int  main ( void)
{   sorted_vector_tree<unsigned> A ;
    int i ;
    for ( i = 0 ; i < 1000; i ++)
        A.insert_value( rand() % 15000 ) ;

    sorted_vector_tree<unsigned>::iterator Alfa , Beta ;
    //for ( i = 0 ; i < A.size() ; i ++) std::cout<<A[i]<<"   ";
    Alfa = A.lower_bound( 100 ) ;
    Beta = A.upper_bound(10000) ;
    std::cout<<"Hay "<<(Beta -Alfa)<<" elementos entre 100 y 10000, ambos inclusive\n";
    for ( i = Alfa.pos() ; i < Beta.pos() ; i ++ )
        std::cout<<A[i]<<"\t";
    return 0 ;
};
