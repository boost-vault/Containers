///----------------------------------------------------------------------------
// FILE : test_sorted_vector_tree_06.cpp
//
// DESCRIPTION : This program is for to compare the speed of the std::set
//  with the util::sorted_vector_tree
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 0
#include <iostream>
#include <stdlib.h>
#include <set>
#include <time.h>

#include <boost/countertree/sorted_vector_tree.hpp>

#define NELEM 1000000

using namespace cntree ;
using std::cout ;
using std::endl;


int A[NELEM];

void Prueba ( void ) ;
int  main ( void)
{   //---------------------- Variables----------------------------
    int i;

    //------------------------ Inicio -----------------------------
    cout<<"Busquedas de "<< NELEM<<" elementos"<<endl<<endl ;
    cout<<"Elementos ordenados ascendentemente\n";

    for ( i = 0 ; i < NELEM ; i ++) A[i] = NELEM +i ;
    Prueba() ;

    cout<<"Elementos aleatorios pocas repeticiones\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = ((rand()%65000) *(rand() %65000) + (rand()%65000)) ;
    Prueba() ;

    cout<<"Elementos aleatorios muchas repeticiones\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = ((rand()%65000) *(rand() %65000) + (rand()%65000))  % (NELEM/2);
    Prueba() ;

    cout<<"Elementos aleatorios muchisimas repeticiones\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = rand() %10000;
    Prueba() ;

    cout<<"Elementos iguales\n";
    for ( i = 0 ; i < NELEM  ; i ++) A[i] = NELEM;
    Prueba() ;
    return 0 ;
};

void Prueba ( void )
{   //----------------------------- Inicio ------------------------
    double duracion ;
	clock_t start, finish;
    int i, k;

    {   cout<<"Prueba con la estructura set de STL \n";
        std::set <int, std::less <int> > S1 ;
        for (  i = 0 ; i < NELEM; i ++ ) S1.insert ( A[i] );
        start = clock();
        for (  k = 0 ; k < 10 ; k ++)
        {   std::set <int, std::less <int> >::iterator Alfa ;
            for ( i = 0 ; i < NELEM ; ++i)
            {   Alfa = S1.lower_bound( A[i]);
                if ( *Alfa != A[i])
                    cout<<"Error en la busqueda \n";
            };
        };
        finish = clock() ;
        duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"El tiempo empleado es de :"<<duracion<<" segundos\n";
    };

    {   // Prueba con la estructura arbol
        cout<<"Prueba con la estructura sorted_vector_tree ( set)\n";
        sorted_vector_tree<int> M1 ;
        for ( i = 0 ; i < NELEM; i ++ )M1.insert_value_unique ( A[i] );
        start = clock();
        for ( k = 0 ; k < 10 ; k ++)
        {   sorted_vector_tree<int>::iterator Alfa ;
            for ( i = 0 ; i < NELEM ; ++i)
            {   Alfa = M1.lower_bound ( A[i]);
                if ( *Alfa != A[i])
                    cout<<"Error en la busqueda \n";
            };
        };
        finish = clock() ;
        duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"El tiempo empleado es de :"<<duracion<<" segundos\n";



    };
    {   cout<<"Prueba con la estructura multiset de STL \n";
        std::multiset <int, std::less <int> > S1 ;
        for (  i = 0 ; i < NELEM; i ++ ) S1.insert ( A[i] );
        start = clock();
        for (  k = 0 ; k < 10 ; k ++)
        {   std::multiset <int, std::less <int> >::iterator Alfa ;
            for ( i = 0 ; i < NELEM ; ++i)
            {   Alfa = S1.lower_bound ( A[i]);
                if ( *Alfa != A[i])
                    cout<<"Error en la busqueda \n";
            };
        };
        finish = clock() ;
        duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"El tiempo empleado es de :"<<duracion<<" segundos\n";
    };
    {   // Prueba con la estructura arbol
        cout<<"Prueba con la estructura sorted_vector_tree (multiset)\n";
        sorted_vector_tree<int> M1 ;
        for ( i = 0 ; i < NELEM; i ++ )M1.insert_value ( A[i] );

        start = clock();
        for ( k = 0 ; k < 10 ; k ++)
        {   sorted_vector_tree<int>::iterator Alfa ;
            for ( i = 0 ; i < NELEM ; ++i)
            {   Alfa = M1.lower_bound ( A[i]);
                if ( *Alfa != A[i])
                    cout<<"Error en la busqueda \n";
            };
        };
        finish = clock() ;
        duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"El tiempo empleado es de :"<<duracion<<" segundos\n";

    };


    cout<<"---------------------------------------------------\n\n";
};

