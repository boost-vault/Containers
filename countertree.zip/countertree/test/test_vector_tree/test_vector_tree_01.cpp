///----------------------------------------------------------------------------
// FILE : test_vector_tree_01.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2

#include <iostream>
#include <stdlib.h>
#include <boost/countertree/tools/debug_vector_tree.hpp>


using std::cout ;
using std::endl;


int main (void)
{   //------------------------ Inicio -----------------------------
    cntree::vector_tree<uint32_t> A ;

    bool Correcto;
    A.insert_pos( 9, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };

    A.insert_pos( 8, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    A.insert_pos( 7, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    A.insert_pos( 6, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    A.insert_pos( 5, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    A.insert_pos( 4, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    A.insert_pos( 3, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    A.insert_pos( 2, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    A.insert_pos( 1, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    A.insert_pos( 0, 0 ) ;
    Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    A.Imprimir();
    cout<< A<<endl<<endl;
    cntree::vector_tree<uint32_t> B ( A.begin(), A.end());
    B.Imprimir();
    Correcto = B.check() ;
    if ( not Correcto)
    {   cout<<"Error en la creacion\n";
        return 1 ;
    };
    cout<< B<<endl<<endl;

    cntree::vector_tree <uint32_t> C ( (cntree::tools::size_type)10, (uint32_t)7 );
    Correcto = C.check() ;
    if ( not Correcto)
    {   cout<<"Error en la creacion\n";
        return 1 ;
    };
    cout<< C<<endl<<endl;
    cntree::vector_tree<uint32_t> D( A);
    Correcto = D.check() ;
    if ( not Correcto)
    {   cout<<"Error en la creacion\n";
        return 1 ;
    };
    D.resize (5) ;
    D.resize(10);
    Correcto = D.check() ;
    if ( not Correcto)
    {   cout<<"Error en la creacion\n";
        return 1 ;
    };
    cout<< D<<endl<<endl;
    D.assign( A.begin() , A.end());
        Correcto = A.check() ;
    if ( not Correcto)
    {   cout<<"Error en la insercion\n";
        return 1 ;
    };
    cout<< A<<endl<<endl;
    for ( int32_t i = 0 ; i<A.size() ; i ++)
        cout<< A[i]<<"  ";
    cout<<endl<<endl;

    for ( int32_t i = 0 ; i<A.size() ; i ++)
        cout<<( A.at(i))<<"  ";

    cout<<endl<<endl;
    cout<<A.front() <<"   "<<A.back()<<endl;
    //-------------------------------------------------------------------
    //                      Pruebas de supresion
    //--------------------------------------------------------------------
    cntree::tools::iterator<uint32_t> PAux  ;
    for ( uint32_t i = 0 ; i < 10 ; i ++ )
    {   PAux = A.find_pos( 0);
        A.erase (PAux);
        Correcto = A.check() ;
        if ( not Correcto)
        {   cout<<"Error en la supresion\n";
            return 1 ;
        };
    };
    cout<<A<<endl;
    return 0 ;
};
