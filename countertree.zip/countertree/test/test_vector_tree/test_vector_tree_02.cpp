///----------------------------------------------------------------------------
// FILE : test_vector_tree_02.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <iostream>
#include <stdlib.h>

#include <boost/countertree/tools/debug_vector_tree.hpp>


using namespace cntree ;
using namespace std;

int  main ( void)
{   //---------------------- Variables----------------------------
    vector_tree<int> M1 , M2;


    //------------------------ Inicio -----------------------------
    cout<<"Objetos M1, M2 creados : OK "<<endl ;
    cout<<"Insercion (M1 size:7 1000, 1001,1002,1003,1004,1005,1006)"<<endl ;
    M1.insert_pos(  1003 , 0) ;
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_pos(  1001 , 0) ;
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_pos(  1005,2) ;
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_pos(  1000,0) ;
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_pos(  1002,2) ;
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_pos(  1004,4) ;
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    M1.insert_pos( 1006,6) ;
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };
    cout<<M1<<endl;
/*
    cout<<"Asignacion (M2 size:7 1000, 1001,1002,1003,1004,1005,1006)\n";
    M2 = M1 ;
    if (not M2.check() )
    {   cout<<"error en M2\n" ;
        return 0;
    };
    cout<<M2<<endl;
*/
    cout<<"Pruebas de supresion \n";
    if (not M1.check() )
    {   cout<<"error en M1\n" ;
        return 0;
    };

    cout<<"Suprimir 6 ";
    M1.erase_pos(6) ;
    if (M1.check() ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };

    cout<<"Suprimir 0 ";
    M1.erase_pos(0) ;
    if ( M1.check() ) cout<<M1<<endl ;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };

    cout<<"Suprimir 0 ";
    M1.erase_pos(0) ;
    if ( M1.check() ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };

    cout<<"Suprimir 3 ";
    M1.erase_pos(3) ;
    if ( M1.check() ) cout<< M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };


    cout<<"Suprimir 1";
    M1.erase_pos(1) ;
    if ( M1.check() ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };

    cout<<"Suprimir 1 ";
    M1.erase_pos(1) ;
    if ( M1.check() ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };

    cout<<"Suprimir 0 ";
    M1.erase_pos(0) ;
    if ( M1.check() ) cout<<M1<<endl;
    else
    {   cout<<"error en M1\n" ;
        return 0;
    };

    //Segunda prueba
    cout<<"Prueba insertar y suprimir al inicio y al final de la estructura\n";
    cout<<"( 14 , 15 , 16 , 17 , 18 , 19, 20 , 21 , 22 , 23 )\n";
    M2.clear() ;
    M1.clear() ;
    if ( not M1.check() or not M2.check() )
    {   cout<<"error \n" ;
        return 0;
    };
    unsigned i;
    for ( i = 0 ; i < 10; i ++ )
    {   M2.push_front( 10 + 9 -i  );
        if (not M2.check() )
        {   cout<<"error \n" ;
            return 0;
        };
    };
    for ( i = 0 ; i < 10; i ++ )
    {   M2.push_back ( 20 + i  );
        if (not M2.check() )
        {   cout<<"error \n" ;
            return 0;
        };

    };
    for ( i = 0 ; i < 4; i ++ )
    {   M2.pop_front( );
        if (not M2.check() )
        {   cout<<"error \n" ;
            return 0;
        };

    };
    for ( i = 0 ; i < 6; i ++ )
    {   M2.pop_back ( );
        if (not M2.check() )
        {   cout<<"error \n" ;
            return 0;
        };

    };
    if (not M2.check() )
    {   cout<<"error en M2, i: "<<endl ;
        cout<<M2<<endl;
        return 0;
    };
    cout <<M2 <<endl ;

    // Tercera prueba
    M1.clear() ;
    M1.push_front (100);
    M1.push_back(0 );
    M1.insert ( M1.begin() +1, 50);

    M1.insert ( M1.begin(), (vector_tree<int>::size_type)10 , 1000);

    M1.insert ( M1.begin()+ 10, M2.begin() , M2.end());
    cout<<M1<<endl;


    return 0 ;
};



