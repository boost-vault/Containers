///----------------------------------------------------------------------------
// FILE : test_vector_tree_03.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2

#include <iostream>
#include <stdlib.h>

#include <boost/countertree/tools/debug_vector_tree.hpp>


using namespace cntree ;
using  std::cout;
using  std::endl;


int InsercionBinaria ( const vector_tree<int> &A , int Valor) ;
int BusquedaBinaria ( const vector_tree<int> &A , int Valor);

int  main ( void)
{   //---------------------- Variables----------------------------
    int Numero [1000];


    //------------------------ Inicio -----------------------------

    int Aux[1000] ;
    unsigned i ;
    cout<<"Generacion of 1000 numeros aleatorios :";
    for (  i = 0 ; i < 1000; i ++ )
        Numero[i] = rand() % 100000 ;
    cout<<"OK"<<endl ;

    vector_tree<int> M1 ;
    cout<<"Insercion of 1000 numeros aleatorios en M1 : \n" ;
    for ( i = 0 ; i < 1000; i ++ )
    {   cout<<Numero[i]<<"  ";
        M1.insert_pos ( Numero[i] ,  InsercionBinaria ( M1, Numero[i] ) );
        if (not M1.check () )
        {   cout<<i<<"   "<<"Fallo en la insercion\n" ;
            return 0;
        };
    };

    // copiamos la matriz numero en Aux y ordenamos Aux
    for ( i = 0 ; i < 1000 ; i ++) Aux[i] = Numero[i] ;

    // Ordenacion de Aux por le metodo del intercambio, lento pero simple
    cout<<"Ordenacion por el metodo del intercambio\n";
    bool SW;
    do
    {   SW = false ;
        for ( i = 0 ; i < 999 ; i ++ )
        {   if ( Aux[i] > Aux [i+1] )
            {   int pp = Aux[i] ;
                Aux[i] = Aux[i+1] ;
                Aux[i+1] = pp ;
                SW = true ;
            };
        };
    }while ( SW );
    // comparamos la secuencia del vector_treePos con la de Aux
    cout<<"Comparacion de secuencias \n";
    for ( i = 0; i < 1000 ; i ++ )
    {   if ( M1[i] != Aux[i] )
        {   cout<<"Error en la secuencia \n";
            return 0;
        };
    };
    //Supresion de los valores del vector_tree
    cout<<"Supresion de los 1000 elementos \n";
    for ( i = 0 ; i < 1000 ; i ++ )
    {   M1.erase_pos ( BusquedaBinaria ( M1,Numero[i] ) ) ;
        if (not M1.check())
        {   cout<<"Fallo en la supresion\n" ;
            return 0;
        };
    };
    if ( not M1.check() )
    {   cout<<"Fallo en la estructura\n" ;
        return 0;
    };

    return 0 ;
};



int InsercionBinaria ( const vector_tree<int> &A , int Valor)
{   if ( A.size() == 0 ) return 0 ;
    int li = -1,ls = A.size(), p;
    while ( (ls -li) > 1 )
    {   p= ( ls +li) /2 ;
        if ( A[p] > Valor ) ls = p ;
        else                li = p ;
    };
    return ls ;
};
int BusquedaBinaria ( const vector_tree<int> &A , int Valor)
{   if ( A.size() == 0 ) return -1 ;
    int li = 0, ls = A.size() -1, p ;
    while ( ls > li)
    {   p = (li + ls +1) /2 ;
        if ( A[p] > Valor) ls = p -1 ;
        else               li = p ;
    };
    if ( A[ls] == Valor ) return ls ;
    else                  return -1 ;
};
