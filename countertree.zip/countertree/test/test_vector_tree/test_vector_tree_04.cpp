///----------------------------------------------------------------------------
// FILE : test_vector_tree_04.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco José Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 2
#include <iostream>
#include <stdlib.h>

#include <boost/countertree/tools/debug_vector_tree.hpp>


using namespace cntree;
using std::cout ;
using std::endl;



void Imprimir ( const vector_tree<int> &A)
{   //------------------------ Inicio -------------------------
    cout<<"---------------------------------------------------------\n";
    vector_tree<int>::const_iterator C1 ;
    for (C1 = A.begin() ; C1 != A.end() ; C1++)
        cout<<(*C1)<<"  ";
    cout<<endl ;
    cout<<"---------------------------------------------------------\n";
};

int main ( void)
{   //---------------------- Variables----------------------------
    vector_tree<int> M1, M2, M3 ;
    int i ;

    //------------------------ Inicio -----------------------------
    for ( i = 0 ; i < 50 ; i++ )
    {   M1.push_back (i +1000) ;
        M2.push_front ((49 -i) +2000 );
        M3.push_back (i +3000 );
    };
    if (not M1.check() or not M2.check() or not M3.check() )
    {   cout<<"Fallo en la estructura\n" ;
        return 1;
    };

    cout<<" M1 [1000 - 1049]"<<endl ;
    Imprimir ( M1  ) ;
    cout<<" M2 [2000 - 2049]"<<endl ;
    Imprimir ( M2 ) ;
    cout<<" M3 [3000 - 3049]"<<endl ;
    Imprimir ( M3 ) ;

    M1.erase_pos ( 0, 49) ;
    M2.erase_pos ( 0, 49) ;
    M3.erase_pos ( 0, 49) ;
    if (not M1.check() or not M2.check() or not M3.check() )
    {   cout<<"Fallo en la estructura\n" ;
        return 1;
    };

    for ( i = 0 ; i < 10 ; i++ )
    {   M1.push_back ( i +100 );
        M2.push_back ( i +200 );
        M3.push_back ( i +300 );
    };
    if (not M1.check() or not M2.check() or not M3.check() )
    {   cout<<"Fallo en la estructura\n" ;
        return 1;
    };

    M1.erase_pos( 1,5);
    M1.push_back( 111) ;
    cout<<"M1 (100, 106,107,108,109,111)"<<endl ;
    Imprimir ( M1 ) ;

    M2.erase_pos (M2.size() -1 , M2.size() -1) ;
    M2.push_back(222) ;
    cout<<"M2(200,201,202,203,204,205,206,207,208,222)"<<endl ;
    Imprimir ( M2 ) ;

    M1.erase_pos ( 2, 5 ) ;
    M2.erase_pos(2,7) ;
    if (not M1.check() or not M2.check() )
    {   cout<<"Fallo en la estructura\n" ;
        return 1;
    };

    for ( i = 0 ; i < M2.size() ; i ++ )
    {   M1.push_back ( M2[i] ) ;
    };
    cout<<"M1(100,106,200,201,208,222)"<<endl ;
    Imprimir ( M1 ) ;
    if ( not M1.check() )
    {   cout<<"Fallo en la estructura\n" ;
        return 1;
    };

    // La prueba de la paciencia
    cout<<" Insercion de un millon de elementos"<<endl ;
    M1.clear() ;

    // Insercion de un millon de elementos
    for ( i = 0 ; i < 1000000; i++ )
    {   M1.push_back( i) ;
        if ((i%1000) == 0)
        {   cout<<i<<" - ";
            if ( not M1.check() )
            {   cout<<"Fallo en la estructura\n" ;
                return 1;
            };
        };
    };
    cout<<endl<<endl ;
    // Supresion de elementos
    cout<<"Supresion de 999990 elementos \n" ;
    for ( i = 0 ; i < 1000000; i += 100000)
    {   M1.erase_pos ( (900001 - i),  (999999 -i) );
        cout<<i<<endl;
        if ( not M1.check() )
        {   cout<<"Fallo en la estructura\n" ;
            return 1;
        };

    };

    Imprimir ( M1 ) ;

    return 0 ;
};



