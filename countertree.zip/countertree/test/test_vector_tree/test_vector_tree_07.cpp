///----------------------------------------------------------------------------
// FILE : test_vector_tree_07.cpp
//
// DESCRIPTION :
//
// MODIFICATIONS (AUTHOR,DATE,REASON) :
//  Copyright (c) 2010 Francisco Jos� Tapia (fjtapia@gmail.com )
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// NOTES :
//-----------------------------------------------------------------------------
#define __DEBUG_MODE 0
#include <iostream>
#include <time.h>
#include <stdlib.h>

#include <vector>
#include <deque>
#include <stack>
#include <set>

#include <boost/countertree/vector_tree.hpp>

#define NELEM 10000
using namespace cntree ;
using  std::set ;
using std::deque;
using std::cout;
using std::endl;

int   main ( void)
{   //---------------------- Variables----------------------------
    double duracion ;
	clock_t start, finish;
    int i , A[NELEM];
    int  min , nivel ;

    // Set STL de 100 elementos
    typedef set <int,std::less<int> > Tree_100 ;
    Tree_100 S1 ;

    for ( i = 0; i < 100 ; i ++ ) S1.insert ( i ) ;

    //------------------------ Inicio -----------------------------
    // Carga de los numeros aleatorios en A
    for ( i =0 ; i < NELEM ; i ++ ) A[i] = rand() ;

    // Examen de la desviacion m�xima
    min = 100 ;
    nivel = 0 ;
    for ( i = 0; i < NELEM ; i ++ )
    {   if ( (A[i] & 1)   == 0 )  nivel++;
        else
        {   nivel--;
            if ( nivel < min )
            {   A[i] &= 1 ;
                nivel += 2 ;
            };
        };
    };

    //******************************************************************
    //
    //    C O M P A R A T I V A S   C O N    D E Q U E
    //
    //******************************************************************
    {   //----------------------------------------------------------------
        // Inserci�n y supresion de NELEM elementos simples ( enteros)
        // con estructuras con muchos datos en posiciones aleatorias
        //----------------------------------------------------------------
        cout<<"-----------------------------------------------------\n";
        cout<<" Insercion y supresion en posiciones aleatorias \n";
        cout<<" Elementos complejos ( set de 100 elementos)\n";
        cout<<" Estructuras con muchos elementos (NELEM/2) \n";
        cout<<"-----------------------------------------------------\n";

        //----------- Definicion de los datos------------------------
        vector_tree <Tree_100> AP ;

        for ( i = 0 ; i < NELEM/2 ; i ++ ) AP.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( A[i] % 2==0)
                AP.insert_pos (S1,A[i] % AP.size()) ;
            else
                AP.erase_pos (A[i] % AP.size()) ;
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"vector_treePos - Tiempo empleado :"<<duracion<<" segundos\n";
        AP.clear() ;

        deque<Tree_100 > S ;
        for ( i = 0 ; i < NELEM/2 ; i ++ ) S.push_back(S1) ;
        start = clock() ;
        for ( i = 0 ; i < NELEM ; i ++ )
        {   if ( A[i] %2==0)
                S.insert ( S.begin() + ( A[i]% S.size() ) , S1 ) ;
            else
                S.erase (S.begin() + ( A[i] % S.size() ) );
        };
        finish = clock() ;
	    duracion = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"deque - Tiempo empleado :"<<duracion<<" segundos\n";

    };
    cout<<"-----------------------------------------------------\n";
    return 0 ;
};
