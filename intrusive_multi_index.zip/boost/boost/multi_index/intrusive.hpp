////////////////////////////////////////////////////////////////////////////////////////////////
// instrusive.hpp

// $Id$

//
// Copyright (C) 2005 Maxim Yegorushkin
//

#ifndef INSTRUSIVE_HPP
#define INSTRUSIVE_HPP

////////////////////////////////////////////////////////////////////////////////////////////////

namespace boost { namespace multi_index {

namespace detail {

struct default_tag;

}

template<class T, class Tag = detail::default_tag>
struct intrusive; // no need for a complete type

namespace detail {

#ifdef BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

// implement it

#else // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

template<class T> struct unwrap { typedef T type; };
template<class T, class U> struct unwrap<intrusive<T, U> > : unwrap<T> {};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

}

}} // namespace boost { namespace multi_index {

////////////////////////////////////////////////////////////////////////////////////////////////

#endif // INSTRUSIVE_HPP


