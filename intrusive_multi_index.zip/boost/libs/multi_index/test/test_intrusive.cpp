////////////////////////////////////////////////////////////////////////////////////////////////
// test_intrusive.cpp

// $Id$

//
// Copyright (C) 2005 Maxim Yegorushkin
//

#include <memory>

#define BOOST_MULTI_INDEX_LIMIT_INDEXED_BY_SIZE 3
#define BOOST_MULTI_INDEX_LIMIT_TAG_SIZE 1
#include <boost/multi_index_container.hpp>
#include <boost/multi_index/identity.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/multi_index/hashed_index.hpp>
#include <boost/multi_index/sequenced_index.hpp>

////////////////////////////////////////////////////////////////////////////////////////////////

using namespace boost::multi_index;

////////////////////////////////////////////////////////////////////////////////////////////////

namespace sample1 {

struct record;

typedef multi_index_container<intrusive<record> > container;

struct record : container::node_type {};

inline bool operator<(record const& a, record const& b) { return &a < &b; }

void insert_sample(container* c)
{
    std::auto_ptr<record> p(new record);
    if(c->insert(*p).second)
        p.release();
}

void erase_sample(container* c, container::iterator pos)
{
    std::auto_ptr<record const> p(&*pos);
    c->erase(pos);
}

} //namespace sample1 {

////////////////////////////////////////////////////////////////////////////////////////////////

namespace sample2 {

struct record;

struct tag1;
struct tag2;

typedef multi_index_container<intrusive<record, tag1> > container1;
typedef multi_index_container<intrusive<record, tag2> > container2;

struct record : container1::node_type, container2::node_type {};

inline bool operator<(record const& a, record const& b) { return &a < &b; }

void insert_sample(container1* c1, container2* c2)
{
    struct guard
    {
        container1* c1; 
        container2* c2;
        std::pair<container1::iterator, bool> i1;
        std::pair<container2::iterator, bool> i2;
        std::auto_ptr<record> p;
        ~guard()
        {
           if(i1.second && i2.second) { p.release(); }
           else { c1->erase(i1.first); c2->erase(i2.first); }
        }
        guard(container1* c1, container2* c2, std::auto_ptr<record> p) 
            : c1(c1), c2(c2), i1(c1->end(), 0), i2(c2->end(), 0), p(p)
        {}
    } guard(c1, c2, std::auto_ptr<record>(new record));

    guard.i1 = c1->insert(*guard.p);
    guard.i2 = c2->insert(*guard.p);
}

void erase_sample(container1* c1, container2* c2, record* r)
{
    c1->erase(c1->make_iterator(r));
    c2->erase(c2->make_iterator(r));
    delete r;
}

} //namespace sample2 {

////////////////////////////////////////////////////////////////////////////////////////////////

// this all is a compile only test now

struct record;
struct record_hash
{
    size_t operator()(record const& r) const;
};

struct tag1;
struct tag2;

typedef multi_index_container<
    intrusive<record, tag1>
    , indexed_by<
            ordered_unique<identity<record> > 
          , hashed_unique<identity<record>, record_hash> 
          , sequenced<>
      >
    > container;

typedef multi_index_container<
    intrusive<record, tag2>
    , indexed_by<
            ordered_unique<identity<record> > 
          , hashed_unique<identity<record>, record_hash> 
      >
    > container2;

struct record : container::node_type, container2::node_type
{
    int n_;
    record(int n) : n_(n) {}
    bool operator<(record const& b) const { return n_ < b.n_; }
    bool operator==(record const& b) const { return n_ == b.n_; }
};

inline size_t record_hash::operator()(record const& r) const { return r.n_; }

////////////////////////////////////////////////////////////////////////////////////////////////

int main()
{
    size_t dummy(0);

    record r(1);

    {
        container c;

        nth_index<container, 0>::type& idx0(c.get<0>());
        idx0.insert(r);
        idx0.erase(r);

        nth_index<container, 1>::type& idx1(c.get<1>());
        idx1.insert(r);
        idx1.erase(r);

        nth_index<container, 2>::type& idx2(c.get<2>());
        nth_index_iterator<container, 2>::type i2(idx2.insert(idx2.end(), r).first);
        idx2.erase(i2);

        dummy += c.size();
    }
    
    {
        container2 c;

        nth_index<container2, 0>::type& idx0(c.get<0>());
        idx0.insert(r);
        idx0.erase(r);

        nth_index<container2, 1>::type& idx1(c.get<1>());
        idx1.insert(r);
        idx1.erase(r);

        dummy += c.size();
    }

    return int(dummy);
}

////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////
